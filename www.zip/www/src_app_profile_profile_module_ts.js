"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_profile_profile_module_ts"],{

/***/ 6829:
/*!***************************************************!*\
  !*** ./src/app/profile/profile-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageRoutingModule": () => (/* binding */ ProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.page */ 2919);




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_0__.ProfilePage
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ 4523:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-routing.module */ 6829);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page */ 2919);







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfilePageRoutingModule
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_1__.ProfilePage]
    })
], ProfilePageModule);



/***/ }),

/***/ 2919:
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePage": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page.html?ngResource */ 8907);
/* harmony import */ var _profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profile.page.scss?ngResource */ 6611);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/camera */ 4241);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Services/global.service */ 1307);









let ProfilePage = class ProfilePage {
  constructor(route, apiCall, router, global) {
    this.route = route;
    this.apiCall = apiCall;
    this.router = router;
    this.global = global;
    this.type = true;
    this.favourite = [{
      id: 1,
      user_img: '../../assets/Rectangle 142.png',
      fav_title: 'Beach Party',
      fav_des: 'Lets swimming together near a beach and play a volly ball with each other .',
      location_img: '../../assets/Rectangle 149.png'
    }, {
      id: 2,
      user_img: '../../assets/Rectangle 143.png',
      fav_title: 'Swimming Together',
      fav_des: 'Lets swimming together near a beach and play a volly ball with each other   .',
      location_img: '../../assets/Rectangle 149.png'
    }];
    this.profile_data = {
      u_id: '',
      name: '',
      img: '',
      bio: '',
      socialize_distance: ''
    };
  }

  ngOnInit() {
    this.getprofile();
  }

  getprofile() {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.global.Uid.subscribe(uid => {
        _this.apiCall.api_getprofile(uid);

        console.log(uid);
        _this.profile_data.u_id = uid;
      });

      _this.global.ProfileInfo.subscribe(res => {
        console.log(res);
        _this.profile_data = res[0];
        document.getElementById('cameraImage').setAttribute('src', _this.profile_data.img);
      });
    })();
  }

  ProfileUpdate() {
    console.log(this.profile_data);
    this.apiCall.api_updateprofile(this.profile_data);
  } //  switch between veiw and eidt profile


  allow() {
    this.type = !this.type;
  } // refer a friend


  refer() {
    console.log('refer');
  } // refer a friend


  log_out() {
    console.log('log out');
  } // nav back to home  


  nav_back() {
    this.route.navigate(['/tabs/tab1']);
  } // get image


  capture_img() {
    var _this2 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.Camera.getPhoto({
        quality: 90,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraResultType.Base64,
        source: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraSource.Prompt
      });
      document.getElementById('cameraImage').setAttribute('src', `data:image/${image.format};base64,` + image.base64String);
      console.log(image.base64String);
      _this2.profile_data.img = image.base64String;
    })();
  }

};

ProfilePage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__.ApicallService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_5__.GlobalService
}];

ProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-profile',
  template: _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProfilePage);


/***/ }),

/***/ 6611:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = ".header {\n  margin-top: 35px;\n  display: flex;\n  align-items: center;\n}\n\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  margin-left: 10px;\n  height: 33px;\n  width: 33px;\n}\n\n.text {\n  margin: 0px;\n  text-align: center;\n  font-size: 18px;\n}\n\n.avatar {\n  height: 118px;\n  width: 118px;\n  margin: 35px auto 0px auto;\n}\n\n.name {\n  text-align: center;\n  font-size: 18px;\n  margin: 15px 0px 0px 0px;\n}\n\n.text2 {\n  text-align: center;\n  font-size: 15px;\n  margin: 8px 0px 0px 0px;\n}\n\n.range {\n  height: 64px;\n  max-width: 300px;\n  margin: auto;\n  margin-top: 33px;\n  border-radius: 10px;\n  box-shadow: 0px 1px 20px 19px whitesmoke;\n}\n\n.range p {\n  margin-left: 20px;\n}\n\n.activity {\n  max-width: 340px;\n  margin: auto;\n  margin-top: 25px;\n}\n\n.text3 {\n  margin: 0px;\n  font-size: 12px;\n}\n\n.text4 {\n  margin: 0px;\n  font-size: 9px;\n}\n\n.view {\n  margin: 34px 10px 0px 10px;\n  display: flex;\n  justify-content: center;\n  width: 100%;\n}\n\n.view ion-col {\n  max-width: 382px !important;\n  min-height: 99px;\n  display: flex;\n  align-items: flex-start;\n  align-content: space-between;\n  justify-content: space-between;\n  margin: 0px 5px 27px 5px;\n  padding: 0;\n  box-shadow: 2px 4px 5px rgba(0, 0, 0, 0.1607843137);\n  border-radius: 10px;\n}\n\n.view ion-col .user_img {\n  border: 2px solid #17A525;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 14px;\n}\n\n.view ion-col .m-1 {\n  margin: 3.5px 3px;\n}\n\n.view ion-col .m-2 {\n  margin: 15px 0px 0px 5px;\n}\n\n.view ion-col .title {\n  font-size: 13px;\n}\n\n.view ion-col .subtitle {\n  font-size: 9px;\n}\n\n.view ion-col .location_img {\n  height: 100%;\n  display: flex;\n}\n\n.refer_logut {\n  height: 60px;\n  max-width: 363px;\n  margin: 15px auto 23px auto;\n  border-radius: 10px;\n  box-shadow: 0px 1px 20px 19px whitesmoke;\n  display: flex;\n  align-items: center;\n  justify-content: space-around;\n}\n\n.refer_logut div {\n  text-align: left;\n  width: 65%;\n}\n\n.refer_logut div p {\n  font-size: 14px;\n  font-weight: 500;\n}\n\n.icon {\n  margin-top: 6px;\n}\n\nion-header ion-toolbar .w-1 {\n  width: 42px;\n}\n\nion-header ion-toolbar p {\n  margin: 0% auto;\n}\n\nion-input {\n  height: 55px;\n  max-width: 336px;\n  border: solid black 1px;\n  margin: auto;\n  border-radius: 50px;\n  font-size: 16px;\n  --padding-start: 20px;\n  --padding-end: 16px;\n  opacity: 1 !important;\n}\n\n.label {\n  font-size: 18px;\n  margin-bottom: 5px;\n  max-width: 324px;\n  border: solid black 1px;\n}\n\n.input1 {\n  font-size: 18px;\n  margin: 29px 0px 0px 0px;\n}\n\n.input2 {\n  font-size: 12px;\n  font-weight: bold;\n  margin: 10px;\n  opacity: 0.6;\n}\n\n.icon {\n  text-align: end;\n}\n\n.texxt {\n  margin: 0px;\n  opacity: 0.6;\n}\n\nion-button {\n  height: 60px;\n  max-width: 327px;\n  margin: auto;\n  color: white;\n  margin-bottom: 34px;\n  font-size: 18px;\n}\n\n.input_title {\n  max-width: 300px;\n  margin: auto auto 9px auto;\n}\n\n.capture_img {\n  width: 29px;\n  height: 29px;\n  transform: translate3d(84px, -35px, 10px);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFBSjs7QUFHQTtFQUNJLG1CQUFBO0VBQ0Esc0NBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBQUo7O0FBR0E7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQUo7O0FBR0E7RUFDSSxhQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FBQUo7O0FBR0E7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSx3QkFBQTtBQUFKOztBQUdBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7QUFBSjs7QUFJQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esd0NBQUE7QUFESjs7QUFHSTtFQUNJLGlCQUFBO0FBRFI7O0FBS0E7RUFDSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUZKOztBQUtBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUFGSjs7QUFLQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0FBRko7O0FBS0E7RUFDSSwwQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7QUFGSjs7QUFNSTtFQUNJLDJCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSw0QkFBQTtFQUNBLDhCQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQUpSOztBQU1RO0VBQ0kseUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBSlo7O0FBT1E7RUFDSSxpQkFBQTtBQUxaOztBQVFRO0VBQ0ksd0JBQUE7QUFOWjs7QUFTUTtFQUVJLGVBQUE7QUFSWjs7QUFXUTtFQUNJLGNBQUE7QUFUWjs7QUFZUTtFQUNJLFlBQUE7RUFDQSxhQUFBO0FBVlo7O0FBa0JBO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLHdDQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsNkJBQUE7QUFmSjs7QUFpQkk7RUFDSSxnQkFBQTtFQUNBLFVBQUE7QUFmUjs7QUFpQlE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUFmWjs7QUFvQkE7RUFDSSxlQUFBO0FBakJKOztBQTZCUTtFQUNJLFdBQUE7QUExQlo7O0FBNkJRO0VBQ0ksZUFBQTtBQTNCWjs7QUFpQ0E7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBRUEscUJBQUE7QUEvQko7O0FBbUNBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQWhDSjs7QUFtQ0E7RUFDSSxlQUFBO0VBQ0Esd0JBQUE7QUFoQ0o7O0FBb0NBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFqQ0o7O0FBb0NBO0VBQ0ksZUFBQTtBQWpDSjs7QUFvQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQWpDSjs7QUFvQ0E7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQWpDSjs7QUFvQ0E7RUFDSSxnQkFBQTtFQUNBLDBCQUFBO0FBakNKOztBQW9DQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUNBQUE7QUFqQ0oiLCJmaWxlIjoicHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvL3ZpZXcgcHJvZmlsZSBjc3NcclxuLmhlYWRlciB7XHJcbiAgICBtYXJnaW4tdG9wOiAzNXB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5iYWNrLWJ1dHRvbiB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDNweCA1cHggNXB4IHdoaXRlc21va2U7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgIGhlaWdodDogMzNweDtcclxuICAgIHdpZHRoOiAzM3B4O1xyXG59XHJcblxyXG4udGV4dCB7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxufVxyXG5cclxuLmF2YXRhciB7XHJcbiAgICBoZWlnaHQ6IDExOHB4O1xyXG4gICAgd2lkdGg6IDExOHB4O1xyXG4gICAgbWFyZ2luOiAzNXB4IGF1dG8gMHB4IGF1dG87XHJcbn1cclxuXHJcbi5uYW1lIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIG1hcmdpbjogMTVweCAwcHggMHB4IDBweDtcclxufVxyXG5cclxuLnRleHQyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIG1hcmdpbjogOHB4IDBweCAwcHggMHB4O1xyXG5cclxufVxyXG5cclxuLnJhbmdlIHtcclxuICAgIGhlaWdodDogNjRweDtcclxuICAgIG1heC13aWR0aDogMzAwcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAzM3B4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxcHggMjBweCAxOXB4IHdoaXRlc21va2U7XHJcblxyXG4gICAgcCB7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5hY3Rpdml0eSB7XHJcbiAgICBtYXgtd2lkdGg6IDM0MHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxufVxyXG5cclxuLnRleHQzIHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcblxyXG4udGV4dDQge1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgICBmb250LXNpemU6IDlweDtcclxufVxyXG5cclxuLnZpZXcge1xyXG4gICAgbWFyZ2luOiAzNHB4IDEwcHggMHB4IDEwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuXHJcblxyXG5cclxuICAgIGlvbi1jb2wge1xyXG4gICAgICAgIG1heC13aWR0aDogMzgycHggIWltcG9ydGFudDtcclxuICAgICAgICBtaW4taGVpZ2h0OiA5OXB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICAgICAgYWxpZ24tY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgbWFyZ2luOiAwcHggNXB4IDI3cHggNXB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgYm94LXNoYWRvdzogMnB4IDRweCA1cHggIzAwMDAwMDI5O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblxyXG4gICAgICAgIC51c2VyX2ltZyB7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICMxN0E1MjU7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxNHB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLm0tMSB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMy41cHggM3B4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLm0tMiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMTVweCAwcHggMHB4IDVweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC50aXRsZSB7XHJcblxyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc3VidGl0bGUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDlweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5sb2NhdGlvbl9pbWcge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcblxyXG59XHJcblxyXG4ucmVmZXJfbG9ndXQge1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgbWF4LXdpZHRoOiAzNjNweDtcclxuICAgIG1hcmdpbjogMTVweCBhdXRvIDIzcHggYXV0bztcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMXB4IDIwcHggMTlweCB3aGl0ZXNtb2tlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcclxuXHJcbiAgICBkaXYge1xyXG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgd2lkdGg6IDY1JTtcclxuXHJcbiAgICAgICAgcCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi5pY29uIHtcclxuICAgIG1hcmdpbi10b3A6IDZweDtcclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcbi8vIGVkaXQgcHJvZmlsZSBjc3NcclxuaW9uLWhlYWRlciB7XHJcblxyXG4gICAgaW9uLXRvb2xiYXIge1xyXG5cclxuICAgICAgICAudy0xIHtcclxuICAgICAgICAgICAgd2lkdGg6IDQycHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAwJSBhdXRvO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcbmlvbi1pbnB1dCB7XHJcbiAgICBoZWlnaHQ6IDU1cHg7XHJcbiAgICBtYXgtd2lkdGg6IDMzNnB4O1xyXG4gICAgYm9yZGVyOiBzb2xpZCBibGFjayAxcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAyMHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDogMTZweDtcclxuXHJcbiAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XHJcblxyXG59XHJcblxyXG4ubGFiZWwge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgbWF4LXdpZHRoOiAzMjRweDtcclxuICAgIGJvcmRlcjogc29saWQgYmxhY2sgMXB4O1xyXG59XHJcblxyXG4uaW5wdXQxIHtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIG1hcmdpbjogMjlweCAwcHggMHB4IDBweDtcclxuXHJcbn1cclxuXHJcbi5pbnB1dDIge1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBtYXJnaW46IDEwcHg7XHJcbiAgICBvcGFjaXR5OiAwLjY7XHJcbn1cclxuXHJcbi5pY29uIHtcclxuICAgIHRleHQtYWxpZ246IGVuZDtcclxufVxyXG5cclxuLnRleHh0IHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgb3BhY2l0eTogMC42O1xyXG59XHJcblxyXG5pb24tYnV0dG9uIHtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIG1heC13aWR0aDogMzI3cHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAzNHB4O1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcblxyXG4uaW5wdXRfdGl0bGUge1xyXG4gICAgbWF4LXdpZHRoOiAzMDBweDtcclxuICAgIG1hcmdpbjogYXV0byBhdXRvIDlweCBhdXRvO1xyXG59XHJcblxyXG4uY2FwdHVyZV9pbWcge1xyXG4gICAgd2lkdGg6IDI5cHg7XHJcbiAgICBoZWlnaHQ6IDI5cHg7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDg0cHgsIC0zNXB4LCAxMHB4KTtcclxufSJdfQ== */";

/***/ }),

/***/ 8907:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n\r\n  <!-- see -->\r\n  <div *ngIf=\"this.type === true \">\r\n\r\n    <ion-row class=\"header\">\r\n      <ion-col size=\"1.8\">\r\n        <div class=\"back-button\" (click)=\"nav_back()\"> \r\n          <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n        </div>\r\n      </ion-col>\r\n      <ion-col size=\"8.4\">\r\n        <p class=\"text\"><b>Profile</b></p>\r\n      </ion-col>\r\n      <ion-col size=\"1.8\">\r\n        <p class=\"text\" (click)=\"allow()\"><b>Edit</b></p>\r\n      </ion-col>\r\n    </ion-row>\r\n \r\n     <!-- user image -->\r\n    <ion-avatar class=\"avatar\">\r\n      <img src=\"{{profile_data.img}}\" alt=\"\">\r\n    </ion-avatar>\r\n\r\n\r\n    <!-- user name and Bio -->\r\n    <h1 class=\"name\"><b>{{profile_data.name}}</b></h1>\r\n    <p class=\"text2\">{{profile_data.bio}}</p>\r\n\r\n    <!-- social range -->\r\n    <ion-row class=\"range\">\r\n      <ion-col size=\"8\">\r\n        <p>Social range</p>\r\n      </ion-col>\r\n      <ion-col size=\"4\" class=\"col2\">\r\n        <!-- social range value -->\r\n        <p><b>{{profile_data.socialize_distance}}</b></p>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"activity\">\r\n      <ion-col size=\"9\">\r\n        <p><b>Favourite activities</b></p>\r\n      </ion-col>\r\n      <ion-col size=\"3\">\r\n        <p>See All</p>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- favorite activities -->\r\n    <ion-row class=\"view\">\r\n      <ion-col size=\"12\" size-md=\"4\" *ngFor=\"let data of favourite\">\r\n\r\n        <div class=\"user_img m-2\">\r\n          <img src=\"{{this.data.user_img}}\" alt=\"\">\r\n        </div>\r\n\r\n        <div class=\"m-2\">\r\n          <p class=\"title m-1\"><b>{{this.data.fav_title}}</b></p>\r\n          <p class=\"subtitle m-1\">{{this.data.fav_des}}</p>\r\n          <p class=\"subtitle m-1\"><b>view it</b></p>\r\n        </div>\r\n\r\n        <div class=\"location_img\">\r\n          <img src=\"{{this.data.location_img}}\" alt=\"\">\r\n        </div>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- refer a friend -->\r\n    <ion-row class=\"refer_logut\" (click)=\"refer()\">\r\n\r\n      <ion-icon class=\"icon\" name=\"arrow-undo\" size=\"large\"></ion-icon>\r\n\r\n      <div>\r\n        <p>Refer a friend</p>\r\n      </div>\r\n\r\n      <ion-icon class=\"icon\" name=\"chevron-forward\" size=\"large\"></ion-icon>\r\n\r\n    </ion-row>\r\n\r\n    <!-- Log out -->\r\n    <ion-row class=\"refer_logut\" (click)=\"log_out()\">\r\n\r\n      <ion-icon class=\"icon\" name=\"log-out\" size=\"large\"></ion-icon>\r\n\r\n\r\n      <div>\r\n        <p>Log out</p>\r\n      </div>\r\n\r\n\r\n      <ion-icon class=\"icon\" name=\"chevron-forward\" size=\"large\"></ion-icon>\r\n\r\n\r\n    </ion-row>\r\n\r\n\r\n  </div>\r\n\r\n\r\n  <!-- Edit -->\r\n  <div *ngIf=\"this.type === false \">\r\n    <ion-header class=\"ion-no-border\">\r\n      <ion-toolbar>\r\n  \r\n          <div slot=\"start\" class=\"back-button\" (click)=\"allow()\">\r\n            <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n          </div>\r\n          <div>\r\n            <p class=\"text\"><b>Edit Profile</b></p>\r\n          </div>\r\n\r\n          <div slot=\"end\" class=\"w-1\"></div>\r\n\r\n      </ion-toolbar>\r\n\r\n    </ion-header>\r\n\r\n    <!-- get  -->\r\n    <ion-avatar class=\"avatar\">\r\n      <img id=\"cameraImage\" alt=\"\">\r\n      <!-- get img buttton  -->\r\n      <div class=\"capture_img\" (click)=\"capture_img()\" >\r\n        <img src=\"./../../assets/edit_img.png\" alt=\"\">\r\n      </div>\r\n    </ion-avatar>\r\n    <!-- Name -->\r\n    <ion-row class=\"input_title\">\r\n      <p class=\"input1\"><b>Name</b></p>\r\n    </ion-row>\r\n    <!-- Enter Name -->\r\n    <ion-input type=\"text\" placeholder=\"William\" [(ngModel)]=\"profile_data.name\"></ion-input>\r\n\r\n    <!-- Bio -->\r\n    <ion-row class=\"input_title\">\r\n      <p class=\"input1\"><b>Bio</b></p>\r\n    </ion-row>\r\n    <!-- enter Bio -->\r\n    <ion-input type=\"text\" placeholder=\"Keep enjoying more!\" [(ngModel)]=\"profile_data.bio\"></ion-input>\r\n\r\n    <!-- distance -->\r\n    <ion-row class=\"input_title\">\r\n      <p  class=\"input1\"><b>Socialize Distance</b></p>\r\n    </ion-row>\r\n    <!-- enter distance -->\r\n    <ion-input type=\"text\" placeholder=\"200m\" [(ngModel)]=\"profile_data.socialize_distance\" ></ion-input>\r\n\r\n    <!-- range -->\r\n    <ion-row class=\"input_title\">\r\n      <div style=\"    display: flex;\r\n      align-items: center;\">\r\n        <img src=\"./../../assets/Vector.png\" alt=\"\" srcset=\"\">\r\n      </div>\r\n      <p class=\"input2 m-1\">Set between 100m and 30km</p>\r\n    </ion-row>\r\n\r\n    <!-- Submit button -->\r\n    <ion-button shape=\"round\" expand=\"full\" (click)=\"ProfileUpdate()\">\r\n      <b>Save</b>\r\n    </ion-button>\r\n\r\n  </div>\r\n\r\n\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_profile_profile_module_ts.js.map