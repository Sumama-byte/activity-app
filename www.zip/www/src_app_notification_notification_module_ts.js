"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_notification_notification_module_ts"],{

/***/ 9753:
/*!*************************************************************!*\
  !*** ./src/app/notification/notification-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPageRoutingModule": () => (/* binding */ NotificationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification.page */ 3320);




const routes = [
    {
        path: '',
        component: _notification_page__WEBPACK_IMPORTED_MODULE_0__.NotificationPage
    }
];
let NotificationPageRoutingModule = class NotificationPageRoutingModule {
};
NotificationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NotificationPageRoutingModule);



/***/ }),

/***/ 2154:
/*!*****************************************************!*\
  !*** ./src/app/notification/notification.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPageModule": () => (/* binding */ NotificationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _notification_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./notification-routing.module */ 9753);
/* harmony import */ var _notification_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification.page */ 3320);







let NotificationPageModule = class NotificationPageModule {
};
NotificationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _notification_routing_module__WEBPACK_IMPORTED_MODULE_0__.NotificationPageRoutingModule
        ],
        declarations: [_notification_page__WEBPACK_IMPORTED_MODULE_1__.NotificationPage]
    })
], NotificationPageModule);



/***/ }),

/***/ 3320:
/*!***************************************************!*\
  !*** ./src/app/notification/notification.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NotificationPage": () => (/* binding */ NotificationPage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./notification.page.html?ngResource */ 5224);
/* harmony import */ var _notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./notification.page.scss?ngResource */ 8521);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);








let NotificationPage = class NotificationPage {
  constructor(route, global, apicall) {
    this.route = route;
    this.global = global;
    this.apicall = apicall;
  }

  ngOnInit() {
    this.getAllActivity();
  }

  getAllActivity() {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.apicall.api_getallActivitybylocation();

      _this.global.Storallactivity.subscribe(res => {
        _this.notificationsActivity = res;
      });
    })();
  } // go to home / tab1 page


  nav_back() {
    this.route.navigate(['/tabs/tab1']);
  } // go to filter/ tab 3 page


  funnel() {
    this.route.navigate(['/tabs/tab3']);
  } //show details


  show_details(data) {
    console.log(data);
    this.route.navigate(['/activity-details'], {
      state: {
        data: data
      }
    });
  }

};

NotificationPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

NotificationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-notification',
  template: _notification_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_notification_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], NotificationPage);


/***/ }),

/***/ 8521:
/*!****************************************************************!*\
  !*** ./src/app/notification/notification.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar .head_align {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\nion-header ion-toolbar .back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  height: 33px;\n  width: 33px;\n  margin-left: 15px;\n}\nion-header ion-toolbar ion-icon {\n  margin-right: 15px;\n}\nion-row {\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  position: absolute;\n  top: 10px;\n  padding: 5px;\n}\nion-row ion-col {\n  max-width: 382px !important;\n  min-height: 99px;\n  display: flex;\n  align-items: flex-start;\n  align-content: space-between;\n  justify-content: space-between;\n  margin: 0px 5px 27px 5px;\n  padding: 0;\n  box-shadow: 2px 4px 5px rgba(0, 0, 0, 0.1607843137);\n  border-radius: 10px;\n}\nion-row ion-col .user_img {\n  border: 2px solid #17A525;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 14px;\n  padding: 1px;\n  width: 50px;\n  height: 50px;\n  margin: 15px 0px 0px 5px;\n}\nion-row ion-col .user_img .userimg {\n  height: 100%;\n  width: 100%;\n  border-radius: 14px;\n}\nion-row ion-col .m-1 {\n  margin: 3.5px 3px;\n}\nion-row ion-col .m-2 {\n  margin: 15px 0px 0px 5px;\n}\nion-row ion-col .title {\n  font-size: 13px;\n}\nion-row ion-col .subtitle {\n  font-size: 9px;\n}\nion-row ion-col .short_des {\n  width: 215px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\nion-row ion-col .location_img {\n  width: 86px;\n  height: 99px;\n  display: flex;\n}\nion-row ion-col .location_img .a {\n  height: 100%;\n  width: 100%;\n  object-fit: cover;\n  object-position: -52px 0px;\n  border-radius: 0px 10px 10px 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vdGlmaWNhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSVE7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtBQUhaO0FBTVE7RUFDSSxtQkFBQTtFQUNBLHNDQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtBQUpaO0FBT1E7RUFDSSxrQkFBQTtBQUxaO0FBWUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtBQVRKO0FBV0k7RUFDSSwyQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHdCQUFBO0VBQ0EsVUFBQTtFQUNBLG1EQUFBO0VBQ0EsbUJBQUE7QUFUUjtBQVdRO0VBQ0kseUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esd0JBQUE7QUFUWjtBQVVZO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQVJoQjtBQVlRO0VBQ0ksaUJBQUE7QUFWWjtBQWFRO0VBQ0ksd0JBQUE7QUFYWjtBQWNRO0VBRUksZUFBQTtBQWJaO0FBZ0JRO0VBQ0ksY0FBQTtBQWRaO0FBaUJRO0VBQ0ksWUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQWZaO0FBa0JRO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FBaEJaO0FBa0JZO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0NBQUE7QUFoQmhCIiwiZmlsZSI6Im5vdGlmaWNhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuXHJcbiAgICBpb24tdG9vbGJhciB7XHJcblxyXG4gICAgICAgIC5oZWFkX2FsaWduIHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmJhY2stYnV0dG9uIHtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogMnB4IDNweCA1cHggNXB4IHdoaXRlc21va2U7XHJcbiAgICAgICAgICAgIGhlaWdodDogMzNweDtcclxuICAgICAgICAgICAgd2lkdGg6IDMzcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuXHJcbmlvbi1yb3cge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDEwcHg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcblxyXG4gICAgaW9uLWNvbCB7XHJcbiAgICAgICAgbWF4LXdpZHRoOiAzODJweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IDk5cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAgICAgICBhbGlnbi1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBtYXJnaW46IDBweCA1cHggMjdweCA1cHg7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBib3gtc2hhZG93OiAycHggNHB4IDVweCAjMDAwMDAwMjk7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuXHJcbiAgICAgICAgLnVzZXJfaW1nIHtcclxuICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzE3QTUyNTtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDFweDtcclxuICAgICAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogNTBweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAxNXB4IDBweCAwcHggNXB4O1xyXG4gICAgICAgICAgICAudXNlcmltZ3tcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLm0tMSB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMy41cHggM3B4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLm0tMiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMTVweCAwcHggMHB4IDVweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC50aXRsZSB7XHJcblxyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuc3VidGl0bGUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDlweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zaG9ydF9kZXN7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyMTVweDtcclxuICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAubG9jYXRpb25faW1ne1xyXG4gICAgICAgICAgICB3aWR0aDogODZweDtcclxuICAgICAgICAgICAgaGVpZ2h0OiA5OXB4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgICAgICAgICAgLmF7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTsgICAgXHJcbiAgICAgICAgICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICAgICAgICAgIG9iamVjdC1wb3NpdGlvbjogLTUycHggMHB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMHB4IDEwcHggMTBweCAwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59Il19 */";

/***/ }),

/***/ 5224:
/*!****************************************************************!*\
  !*** ./src/app/notification/notification.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\r\n  <ion-toolbar>\r\n    <div class=\"head_align\">\r\n      \r\n      <div class=\"back-button\" (click)=\"nav_back()\">\r\n        <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n      </div>\r\n      \r\n      <p class=\"text\"><b>Notification</b></p>\r\n        <div (click)=\"funnel()\">\r\n          <b><ion-icon name=\"funnel-outline\"></ion-icon></b>\r\n        </div>\r\n\r\n    </div>\r\n\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n \r\n<ion-content>\r\n  \r\n <!-- Notification data -->\r\n <ion-row>\r\n  <ion-col size=\"12\" size-md=\"4\" *ngFor=\"let data of notificationsActivity\" (click)=\"show_details(data)\">\r\n\r\n    <div class=\"user_img\">\r\n      <img class=\"userimg\" src=\"{{this.data.profile_img}}\" alt=\"\">\r\n    </div>\r\n\r\n    <div class=\"m-2\">\r\n      <p class=\"title m-1\"><b>{{this.data.activity_name}}</b></p>\r\n      <p class=\"subtitle short_des m-1\">{{this.data.description}}</p>\r\n      <p class=\"subtitle m-1\"><b>view it</b></p>\r\n    </div>\r\n\r\n    <div class=\"location_img\">\r\n      <img class=\"a\" src=\"{{this.data.a_image}}\" alt=\"\">\r\n    </div>\r\n\r\n  </ion-col>\r\n</ion-row>\r\n\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_notification_notification_module_ts.js.map