"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_create-activity_create-activity_module_ts"],{

/***/ 1031:
/*!*******************************************************************!*\
  !*** ./src/app/create-activity/create-activity-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateActivityPageRoutingModule": () => (/* binding */ CreateActivityPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _create_activity_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./create-activity.page */ 4016);




const routes = [
    {
        path: '',
        component: _create_activity_page__WEBPACK_IMPORTED_MODULE_0__.CreateActivityPage
    }
];
let CreateActivityPageRoutingModule = class CreateActivityPageRoutingModule {
};
CreateActivityPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CreateActivityPageRoutingModule);



/***/ }),

/***/ 9785:
/*!***********************************************************!*\
  !*** ./src/app/create-activity/create-activity.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateActivityPageModule": () => (/* binding */ CreateActivityPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _create_activity_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./create-activity-routing.module */ 1031);
/* harmony import */ var _create_activity_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-activity.page */ 4016);







let CreateActivityPageModule = class CreateActivityPageModule {
};
CreateActivityPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _create_activity_routing_module__WEBPACK_IMPORTED_MODULE_0__.CreateActivityPageRoutingModule
        ],
        declarations: [_create_activity_page__WEBPACK_IMPORTED_MODULE_1__.CreateActivityPage]
    })
], CreateActivityPageModule);



/***/ }),

/***/ 4016:
/*!*********************************************************!*\
  !*** ./src/app/create-activity/create-activity.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CreateActivityPage": () => (/* binding */ CreateActivityPage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _create_activity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./create-activity.page.html?ngResource */ 2089);
/* harmony import */ var _create_activity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-activity.page.scss?ngResource */ 2312);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/camera */ 4241);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Services/global.service */ 1307);










let CreateActivityPage = class CreateActivityPage {
  constructor(route, apiCall, loadingController, apicall, global) {
    this.route = route;
    this.apiCall = apiCall;
    this.loadingController = loadingController;
    this.apicall = apicall;
    this.global = global;
    this.tabID = 1;
    this.activityData = {
      u_id: '',
      activity_name: '',
      location: '',
      description: '',
      max_atendes: '',
      social_range: '',
      date: '',
      start_time: '',
      end_time: '',
      a_image: '',
      visibilty: ''
    };
    this.Togglevaluee = 'public';
    this.YourActivity = {
      u_id: ''
    };
  }

  ngOnInit() {
    this.getprofile();

    if (history.state.data !== undefined) {
      this.activityData = history.state.data;
      console.log(this.activityData);
    }
  }

  submit_activity_data() {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      if (history.state.data !== undefined) {
        console.log("data Update");
        console.log(_this.activityData);
        _this.activityData.visibilty = _this.Togglevaluee;
        yield _this.apiCall.api_updateActivity(_this.activityData);
        yield _this.apiCall.api_getActivity(_this.YourActivity.u_id);
        _this.activityData = {
          u_id: '',
          activity_name: '',
          location: '',
          description: '',
          max_atendes: '',
          social_range: '',
          date: '',
          start_time: '',
          end_time: '',
          a_image: '',
          visibilty: ''
        };

        _this.route.navigate(['/tabs/tab2']);
      } else {
        console.log(_this.activityData);
        _this.activityData.visibilty = _this.Togglevaluee;
        yield _this.apiCall.api_postActivity(_this.activityData);
        _this.activityData = {
          u_id: '',
          activity_name: '',
          location: '',
          description: '',
          max_atendes: '',
          social_range: '',
          date: '',
          start_time: '',
          end_time: '',
          a_image: '',
          visibilty: ''
        };
      }
    })();
  }

  getprofile() {
    var _this2 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.global.Uid.subscribe(uid => {
        //  this.apiCall.api_getprofile(uid);
        console.log(uid);
        _this2.activityData.u_id = uid;
        _this2.YourActivity.u_id = uid;
      });

      _this2.global.Getactivity.subscribe(res => {
        console.log(res);
        _this2.profile = res;
      });
    })();
  }

  go_back() {
    this.route.navigate(['/tabs/tab1']);
    this.tabID = 1;
  }

  go_form_one() {
    this.tabID = 1;
  }

  presentLoading() {
    console.log(this.tabID);
    this.tabID = 2;
    console.log(this.tabID);
  }

  changeToggle($event) {
    var _this3 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log($event.detail.checked);
      console.log($event.detail.value);

      if ($event.detail.checked == true) {
        _this3.Togglevaluee = 'private';
        console.log(_this3.activityData.visibilty);
      } else {
        _this3.Togglevaluee = 'public';
        console.log(_this3.activityData.visibilty);
      }
    })();
  }

  capture_img() {
    var _this4 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.Camera.getPhoto({
        quality: 90,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraResultType.Base64,
        source: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraSource.Prompt
      }); // document.getElementById('cameraImage').setAttribute('src', `data:image/${image.format};base64,`+image.base64String );

      console.log(image.base64String);
      _this4.activityData.a_image = image.base64String;
    })();
  }

};

CreateActivityPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__.ApicallService
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.LoadingController
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__.ApicallService
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_5__.GlobalService
}];

CreateActivityPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
  selector: 'app-create-activity',
  template: _create_activity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_create_activity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], CreateActivityPage);


/***/ }),

/***/ 2312:
/*!**********************************************************************!*\
  !*** ./src/app/create-activity/create-activity.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = ".header {\n  margin-top: 20px;\n  display: flex;\n  align-items: center;\n}\n\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  margin-left: 15px;\n  height: 33px;\n  width: 33px;\n}\n\n.text {\n  margin: 0px;\n  text-align: center;\n  font-size: 18px;\n}\n\nion-input {\n  height: 64px;\n  max-width: 324px;\n  border: solid rgba(0, 0, 0, 0.3098039216) 1px;\n  margin: auto;\n  border-radius: 6px;\n  font-size: 16px;\n  --padding-start: 20px;\n  --padding-end:16px;\n  opacity: 1 !important;\n}\n\n.input-text {\n  max-width: 320px;\n  margin: auto;\n}\n\n.input-text3 {\n  max-width: 320px;\n  margin: auto;\n  margin-top: 35px;\n}\n\n.start {\n  max-width: 325px;\n  margin: auto;\n  margin-top: 10px;\n}\n\n.input {\n  font-size: 18px;\n  margin-top: 16px;\n}\n\n.input-description {\n  height: 122px;\n  max-width: 324px;\n  border: solid rgba(0, 0, 0, 0.3098039216) 1px;\n  margin: auto;\n  border-radius: 6px;\n  font-size: 16px;\n  --padding-start: 20px;\n  --padding-end:16px;\n  opacity: 1 !important;\n}\n\n.upload {\n  font-size: 18px;\n  margin-top: 12px;\n}\n\n.upload-pic {\n  height: 127px;\n  max-width: 331px;\n  border-radius: 21px;\n  border: dashed 1px black;\n  margin: auto;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.col-start {\n  border: solid rgba(0, 0, 0, 0.3098039216) 1px;\n  border-radius: 6px;\n  height: 55px;\n  width: 150px;\n}\n\n.col-end {\n  border: solid 1px rgba(0, 0, 0, 0.3098039216);\n  border-radius: 6px;\n  height: 55px;\n  width: 150px;\n}\n\n.main_content_div {\n  padding: 16px;\n}\n\n.main_content_div ion-label {\n  display: block;\n}\n\n.main_content_div .stepper_div {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 16px;\n}\n\n.main_content_div .stepper_div .round_div_uncomplete {\n  height: 10px;\n  width: 10px;\n  min-width: 10px;\n  margin: 10px;\n  border-radius: 14px;\n  border: 1px solid var(--ion-color-primary);\n  background: white;\n}\n\n.main_content_div .stepper_div .round_div_completed {\n  height: 7px;\n  width: 15px;\n  min-width: 15px;\n  margin: 10px;\n  border-radius: 14px;\n  border: 1px solid var(--ion-color-primary);\n  background: var(--ion-color-primary);\n}\n\nion-button {\n  margin-top: 10px;\n  margin-bottom: 20px;\n  --color: white;\n  text-transform: none;\n}\n\nion-toggle {\n  --background-checked: rgb(131, 131, 131) ;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZS1hY3Rpdml0eS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQUNKOztBQUNBO0VBQ0ksbUJBQUE7RUFDQSxzQ0FBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFFSjs7QUFBQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFHSjs7QUFEQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDZDQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFFQSxxQkFBQTtBQUdKOztBQUFBO0VBQ0ksZ0JBQUE7RUFBaUIsWUFBQTtBQUlyQjs7QUFGQTtFQUNJLGdCQUFBO0VBQWlCLFlBQUE7RUFBYSxnQkFBQTtBQU9sQzs7QUFMQTtFQUNJLGdCQUFBO0VBQWdCLFlBQUE7RUFBYSxnQkFBQTtBQVVqQzs7QUFQQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQVVKOztBQVJBO0VBQ0ksYUFBQTtFQUNBLGdCQUFBO0VBQ0EsNkNBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUVBLHFCQUFBO0FBVUo7O0FBUEE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUFVSjs7QUFSQTtFQUNJLGFBQUE7RUFBYyxnQkFBQTtFQUFpQixtQkFBQTtFQUFvQix3QkFBQTtFQUF5QixZQUFBO0VBQzVFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBZUo7O0FBYkE7RUFDSSw2Q0FBQTtFQUE4QixrQkFBQTtFQUFtQixZQUFBO0VBQWEsWUFBQTtBQW1CbEU7O0FBakJBO0VBQ0ksNkNBQUE7RUFBK0Isa0JBQUE7RUFBbUIsWUFBQTtFQUFhLFlBQUE7QUF1Qm5FOztBQXBCQTtFQUNJLGFBQUE7QUF1Qko7O0FBckJJO0VBQ0ksY0FBQTtBQXVCUjs7QUFwQkk7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7QUFzQlI7O0FBcEJRO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsMENBQUE7RUFDQSxpQkFBQTtBQXNCWjs7QUFwQlE7RUFDSSxXQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSwwQ0FBQTtFQUNBLG9DQUFBO0FBc0JaOztBQWhCQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7QUFtQko7O0FBaEJBO0VBQ0kseUNBQUE7QUFtQkoiLCJmaWxlIjoiY3JlYXRlLWFjdGl2aXR5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmJhY2stYnV0dG9ue1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgIGJveC1zaGFkb3c6IDJweCAzcHggNXB4IDVweCB3aGl0ZXNtb2tlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcbiAgICBoZWlnaHQ6IDMzcHg7XHJcbiAgICB3aWR0aDogMzNweDtcclxufVxyXG4udGV4dHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcbmlvbi1pbnB1dHtcclxuICAgIGhlaWdodDogNjRweDtcclxuICAgIG1heC13aWR0aDogMzI0cHg7XHJcbiAgICBib3JkZXI6IHNvbGlkICMwMDAwMDA0ZiAxcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDIwcHg7XHJcbiAgICAtLXBhZGRpbmctZW5kOjE2cHg7XHJcbiAgICAgXHJcbiAgICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XHJcbiAgICAgXHJcbn1cclxuLmlucHV0LXRleHR7XHJcbiAgICBtYXgtd2lkdGg6IDMyMHB4O21hcmdpbjogYXV0bztcclxufVxyXG4uaW5wdXQtdGV4dDN7XHJcbiAgICBtYXgtd2lkdGg6IDMyMHB4O21hcmdpbjogYXV0bzttYXJnaW4tdG9wOiAzNXB4O1xyXG59XHJcbi5zdGFydHtcclxuICAgIG1heC13aWR0aDozMjVweDttYXJnaW46IGF1dG87bWFyZ2luLXRvcDogMTBweDsgXHJcbn1cclxuIFxyXG4uaW5wdXR7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG59XHJcbi5pbnB1dC1kZXNjcmlwdGlvbntcclxuICAgIGhlaWdodDogMTIycHg7XHJcbiAgICBtYXgtd2lkdGg6IDMyNHB4O1xyXG4gICAgYm9yZGVyOiBzb2xpZCAjMDAwMDAwNGYgMXB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAyMHB4O1xyXG4gICAgLS1wYWRkaW5nLWVuZDoxNnB4O1xyXG4gICAgIFxyXG4gICAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xyXG4gICAgIFxyXG59XHJcbi51cGxvYWR7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG59XHJcbi51cGxvYWQtcGlje1xyXG4gICAgaGVpZ2h0OiAxMjdweDttYXgtd2lkdGg6IDMzMXB4O2JvcmRlci1yYWRpdXM6MjFweCA7Ym9yZGVyOiBkYXNoZWQgMXB4IGJsYWNrO21hcmdpbjogYXV0bztcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuLmNvbC1zdGFydHtcclxuICAgIGJvcmRlcjogc29saWQgIzAwMDAwMDRmIDFweCA7IGJvcmRlci1yYWRpdXM6IDZweDtoZWlnaHQ6IDU1cHg7d2lkdGg6IDE1MHB4O1xyXG59XHJcbi5jb2wtZW5ke1xyXG4gICAgYm9yZGVyOiBzb2xpZCAgMXB4ICMwMDAwMDA0ZiA7IGJvcmRlci1yYWRpdXM6IDZweDtoZWlnaHQ6IDU1cHg7d2lkdGg6IDE1MHB4O1xyXG59XHJcbiBcclxuLm1haW5fY29udGVudF9kaXYge1xyXG4gICAgcGFkZGluZzogMTZweDtcclxuICBcclxuICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB9XHJcbiAgXHJcbiAgICAuc3RlcHBlcl9kaXYge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBwYWRkaW5nOiAxNnB4O1xyXG5cclxuICAgICAgICAucm91bmRfZGl2X3VuY29tcGxldGUge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMHB4O1xyXG4gICAgICAgICAgICBtaW4td2lkdGg6IDEwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbjoxMHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxNHB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6d2hpdGU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yb3VuZF9kaXZfY29tcGxldGVkIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiA3cHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxNXB4O1xyXG4gICAgICAgICAgICBtaW4td2lkdGg6IDE1cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbjoxMHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxNHB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgICB9XHJcbiAgICAgICBcclxuICAgIH1cclxuICBcclxufVxyXG5pb24tYnV0dG9ue1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIG1hcmdpbi1ib3R0b206MjBweDtcclxuICAgIC0tY29sb3I6IHdoaXRlO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbiBcclxufVxyXG5pb24tdG9nZ2xle1xyXG4gICAgLS1iYWNrZ3JvdW5kLWNoZWNrZWQ6IHJnYigxMzEsIDEzMSwgMTMxKSA7XHJcbn0iXX0= */";

/***/ }),

/***/ 2089:
/*!**********************************************************************!*\
  !*** ./src/app/create-activity/create-activity.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n\r\n  <div class=\"main_content_div\">\r\n\r\n\r\n    <div *ngIf=\"tabID == 1\">\r\n     \r\n      <!-- header -->\r\n      <ion-row class=\"header\">\r\n        <ion-col size=\"1.8\">\r\n          <div class=\"back-button\" (click)=\"go_back()\">\r\n            <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n          </div>\r\n        </ion-col>\r\n        <ion-col size=\"8.2\">\r\n          <p class=\"text\"><b>Create Activity</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"1.8\">\r\n          <p class=\"text\"><b></b></p>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <!-- indicator bullets -->\r\n      <div class=\"stepper_div\">\r\n        <div [ngClass]=\"tabID == 1 ? 'round_div_completed' : 'round_div_uncomplete'\"></div>\r\n  \r\n        <div [ngClass]=\"tabID == 2 ? 'round_div_completed' : 'round_div_uncomplete'\"></div>\r\n      </div>\r\n\r\n      <!-- Name of activity -->\r\n      <ion-row class=\"input-text\">\r\n        <p class=\"input\"><b>Name of Activity</b></p>\r\n      </ion-row>\r\n      <ion-input [(ngModel)]=\"activityData.activity_name\"></ion-input>\r\n\r\n      <!-- Activity location -->\r\n      <ion-row class=\"input-text\">\r\n        <p class=\"input\"><b> Location</b></p>\r\n      </ion-row>\r\n      <ion-input [(ngModel)]=\"activityData.location\"></ion-input>\r\n\r\n      <!-- activity description -->\r\n      <ion-row class=\"input-text\">\r\n        <p class=\"input\"><b> Short Description</b></p>\r\n      </ion-row>\r\n      <ion-input class=\"input-description\" [(ngModel)]=\"activityData.description\"></ion-input>\r\n\r\n      <!-- Number od attendes -->\r\n      <ion-row class=\"input-text\">\r\n        <p class=\"input\"><b>Max number of attendance</b></p>\r\n      </ion-row>\r\n      <ion-input [(ngModel)]=\"activityData.max_atendes\"></ion-input>\r\n\r\n      <ion-row style=\"max-width: 330px;margin: auto;\">\r\n        <ion-col size=\"5\">\r\n          <p style=\"font-size: 12px;\"><b>Activity as private</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"7\" style=\"text-align: end;\">\r\n          <ion-toggle style=\"margin: 4px;\" value={{this.Togglevaluee}} (ionChange)=\"changeToggle($event, data)\"></ion-toggle>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row style=\"width: 330px;margin: auto;display: flex;align-items: center;\">\r\n        <ion-icon name=\"information-circle-outline\"></ion-icon>\r\n        <p style=\"font-size: 10px;margin: 0px 2px ;\">Lorem ipsum dolor sit amet, consectetur Consequuntur.\r\n        </p>\r\n      </ion-row>\r\n\r\n      <!-- next button -->\r\n      <ion-list>\r\n        <ion-button expand=\"block\" shape=\"round\" (click)=\"presentLoading();tabID = 2\">\r\n          Next\r\n        </ion-button>\r\n      </ion-list>\r\n\r\n\r\n\r\n\r\n    </div>\r\n\r\n\r\n\r\n    <div *ngIf=\"tabID == 2\">\r\n\r\n      <!-- header  -->\r\n      <ion-row class=\"header\">\r\n        <ion-col size=\"1.8\">\r\n          <div class=\"back-button\" (click)=\"go_form_one()\">\r\n            <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n          </div>\r\n        </ion-col>\r\n        <ion-col size=\"8.2\">\r\n          <p class=\"text\"><b>Create Activity</b></p>\r\n        </ion-col>\r\n        <ion-col size=\"1.8\">\r\n          <p class=\"text\"><b></b></p>\r\n        </ion-col>\r\n      </ion-row>\r\n       <!-- indicator bullets -->\r\n      <div class=\"stepper_div\">\r\n        <div [ngClass]=\"tabID == 1 ? 'round_div_completed' : 'round_div_uncomplete'\"></div>\r\n  \r\n        <div [ngClass]=\"tabID == 2 ? 'round_div_completed' : 'round_div_uncomplete'\"></div>\r\n      </div>\r\n\r\n\r\n      <!-- Activity range -->\r\n      <ion-row class=\"input-text\">\r\n        <p class=\"input\"><b>Social Range of Activity</b></p>\r\n      </ion-row>\r\n      <ion-input placeholder=\"20m\" type=\"number\" [(ngModel)]=\"activityData.social_range\"></ion-input>\r\n\r\n      <!-- Activity date -->\r\n      <ion-row class=\"input-text\">\r\n        <p class=\"input\"><b>start date/Time</b></p>\r\n      </ion-row>\r\n      <ion-input type=\"date\" [(ngModel)]=\"activityData.date\">  <p style=\"margin: 5px;\">set the date of activity</p> </ion-input>\r\n\r\n     \r\n      <ion-row class=\"start\">\r\n         <!-- Activity start time -->\r\n        <ion-col size=\"12\">\r\n          <ion-input type=\"time\" [(ngModel)]=\"activityData.start_time\">  <p style=\"margin: 5px;\">Start TIme</p> </ion-input>  \r\n        </ion-col>\r\n        \r\n        <!-- Activity end time -->\r\n        <ion-col size=\"12\">\r\n          <ion-input type=\"time\" [(ngModel)]=\"activityData.end_time\">  <p style=\"margin: 5px;\">End Time</p> </ion-input>\r\n        </ion-col>\r\n      </ion-row>\r\n\r\n      <ion-row class=\"input-text3\">\r\n        <p class=\"upload\"><b>upload a picture</b></p>\r\n      </ion-row>\r\n      \r\n      <!-- upload location image -->\r\n      <ion-row class=\"upload-pic\">\r\n        <ion-button (click)=\"capture_img()\">upload</ion-button>\r\n      </ion-row>\r\n\r\n\r\n      <!-- data sumbit button -->\r\n      <ion-button expand=\"block\" shape=\"round\" (click)=\"submit_activity_data()\">\r\n        <span>Create</span>\r\n      </ion-button>\r\n\r\n    </div>\r\n\r\n\r\n  </div>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_create-activity_create-activity_module_ts.js.map