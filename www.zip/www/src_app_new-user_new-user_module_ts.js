"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_new-user_new-user_module_ts"],{

/***/ 6436:
/*!*****************************************************!*\
  !*** ./src/app/new-user/new-user-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewUserPageRoutingModule": () => (/* binding */ NewUserPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _new_user_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-user.page */ 8443);




const routes = [
    {
        path: '',
        component: _new_user_page__WEBPACK_IMPORTED_MODULE_0__.NewUserPage
    }
];
let NewUserPageRoutingModule = class NewUserPageRoutingModule {
};
NewUserPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NewUserPageRoutingModule);



/***/ }),

/***/ 5485:
/*!*********************************************!*\
  !*** ./src/app/new-user/new-user.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewUserPageModule": () => (/* binding */ NewUserPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _new_user_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./new-user-routing.module */ 6436);
/* harmony import */ var _new_user_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-user.page */ 8443);







let NewUserPageModule = class NewUserPageModule {
};
NewUserPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _new_user_routing_module__WEBPACK_IMPORTED_MODULE_0__.NewUserPageRoutingModule
        ],
        declarations: [_new_user_page__WEBPACK_IMPORTED_MODULE_1__.NewUserPage]
    })
], NewUserPageModule);



/***/ }),

/***/ 8443:
/*!*******************************************!*\
  !*** ./src/app/new-user/new-user.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewUserPage": () => (/* binding */ NewUserPage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _new_user_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./new-user.page.html?ngResource */ 3730);
/* harmony import */ var _new_user_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-user.page.scss?ngResource */ 2952);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/camera */ 4241);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Services/global.service */ 1307);









let NewUserPage = class NewUserPage {
  constructor(apiCall, router, global) {
    this.apiCall = apiCall;
    this.router = router;
    this.global = global;
    this.profile_data = {
      u_id: '',
      name: '',
      img: '',
      bio: '',
      socialize_distance: ''
    };
  }

  ngOnInit() {
    this.getprofile();
  }

  submit_profile_data() {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(_this.profile_data);
      yield _this.apiCall.api_postProfile(_this.profile_data);
      _this.profile_data = {
        u_id: '',
        name: '',
        img: '',
        bio: '',
        socialize_distance: ''
      };
      document.getElementById('cameraImage').setAttribute('src', '');
    })();
  }

  getprofile() {
    var _this2 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.global.Uid.subscribe(uid => {
        //  this.apiCall.api_getprofile(uid);
        console.log(uid);
        _this2.profile_data.u_id = uid;
      });

      _this2.global.ProfileInfo.subscribe(res => {
        console.log(res);
        _this2.profile = res;
      });
    })();
  } // get image


  capture_img() {
    var _this3 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.Camera.getPhoto({
        quality: 90,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraResultType.Base64,
        source: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraSource.Prompt
      });
      document.getElementById('cameraImage').setAttribute('src', `data:image/${image.format};base64,` + image.base64String);
      console.log(image.base64String);
      _this3.profile_data.img = image.base64String;
    })();
  }

};

NewUserPage.ctorParameters = () => [{
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__.ApicallService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_5__.GlobalService
}];

NewUserPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-new-user',
  template: _new_user_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_new_user_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], NewUserPage);


/***/ }),

/***/ 2952:
/*!********************************************************!*\
  !*** ./src/app/new-user/new-user.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  margin-top: 35px;\n  display: flex;\n  align-items: center;\n}\n\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  margin-left: 10px;\n  height: 33px;\n  width: 33px;\n}\n\n.text {\n  margin: 0px;\n  text-align: center;\n  font-size: 18px;\n}\n\n.avatar {\n  height: 118px;\n  width: 118px;\n  margin: 35px auto 0px auto;\n  border: 1px solid black;\n}\n\n.name {\n  text-align: center;\n  font-size: 18px;\n  margin: 15px 0px 0px 0px;\n}\n\n.text2 {\n  text-align: center;\n  font-size: 15px;\n  margin: 8px 0px 0px 0px;\n}\n\n.range {\n  height: 64px;\n  max-width: 300px;\n  margin: auto;\n  margin-top: 33px;\n  border-radius: 10px;\n  box-shadow: 0px 1px 20px 19px whitesmoke;\n}\n\n.range p {\n  margin-left: 20px;\n}\n\n.activity {\n  max-width: 340px;\n  margin: auto;\n  margin-top: 25px;\n}\n\n.text3 {\n  margin: 0px;\n  font-size: 12px;\n}\n\n.text4 {\n  margin: 0px;\n  font-size: 9px;\n}\n\n.view {\n  margin: 34px 0px 0px 0px;\n  display: flex;\n  justify-content: center;\n  width: 100%;\n}\n\n.view ion-col {\n  max-width: 382px;\n  min-height: 99px;\n  display: flex;\n  align-items: flex-start;\n  align-content: space-between;\n  justify-content: space-between;\n  margin: 0px 5px 27px 5px;\n  padding: 0;\n  box-shadow: 2px 4px 5px rgba(0, 0, 0, 0.1607843137);\n  border-radius: 10px;\n}\n\n.view ion-col .user_img {\n  border: 2px solid #17A525;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 14px;\n}\n\n.view ion-col .m-1 {\n  margin: 3.5px 3px;\n}\n\n.view ion-col .m-2 {\n  margin: 15px 0px 0px 5px;\n}\n\n.view ion-col .title {\n  font-size: 13px;\n}\n\n.view ion-col .subtitle {\n  font-size: 9px;\n}\n\n.view ion-col .location_img {\n  height: 100%;\n  display: flex;\n}\n\n.refer_logut {\n  height: 60px;\n  max-width: 363px;\n  margin: 15px auto 23px auto;\n  border-radius: 10px;\n  box-shadow: 0px 1px 20px 19px whitesmoke;\n  display: flex;\n  align-items: center;\n  justify-content: space-around;\n}\n\n.refer_logut div {\n  text-align: left;\n  width: 65%;\n}\n\n.refer_logut div p {\n  font-size: 14px;\n  font-weight: 500;\n}\n\n.icon {\n  margin-top: 6px;\n}\n\nion-header ion-toolbar .w-1 {\n  width: 42px;\n}\n\nion-header ion-toolbar p {\n  margin: 0% auto;\n}\n\nion-input {\n  height: 55px;\n  max-width: 336px;\n  border: solid black 1px;\n  margin: auto;\n  border-radius: 50px;\n  font-size: 16px;\n  --padding-start: 20px;\n  --padding-end: 16px;\n  opacity: 1 !important;\n}\n\n.label {\n  font-size: 18px;\n  margin-bottom: 5px;\n  max-width: 324px;\n  border: solid black 1px;\n}\n\n.input1 {\n  font-size: 18px;\n  margin: 29px 0px 0px 0px;\n}\n\n.input2 {\n  font-size: 12px;\n  font-weight: bold;\n  margin: 10px;\n  opacity: 0.6;\n}\n\n.icon {\n  text-align: end;\n}\n\n.texxt {\n  margin: 0px;\n  opacity: 0.6;\n}\n\nion-button {\n  height: 60px;\n  max-width: 327px;\n  margin: auto;\n  color: white;\n  margin-bottom: 34px;\n  font-size: 18px;\n}\n\n.input_title {\n  max-width: 300px;\n  margin: auto auto 9px auto;\n}\n\n.capture_img {\n  width: 29px;\n  height: 29px;\n  transform: translate3d(84px, -35px, 10px);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5ldy11c2VyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBQUo7O0FBR0E7RUFDSSxtQkFBQTtFQUNBLHNDQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQUFKOztBQUdBO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUFKOztBQUdBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtFQUNBLHVCQUFBO0FBQUo7O0FBR0E7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSx3QkFBQTtBQUFKOztBQUdBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7QUFBSjs7QUFJQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esd0NBQUE7QUFESjs7QUFHSTtFQUNJLGlCQUFBO0FBRFI7O0FBS0E7RUFDSSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUZKOztBQUtBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUFGSjs7QUFLQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0FBRko7O0FBS0E7RUFDSSx3QkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7QUFGSjs7QUFNSTtFQUNJLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSw0QkFBQTtFQUNBLDhCQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQUpSOztBQU1RO0VBQ0kseUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBSlo7O0FBT1E7RUFDSSxpQkFBQTtBQUxaOztBQVFRO0VBQ0ksd0JBQUE7QUFOWjs7QUFTUTtFQUVJLGVBQUE7QUFSWjs7QUFXUTtFQUNJLGNBQUE7QUFUWjs7QUFZUTtFQUNJLFlBQUE7RUFDQSxhQUFBO0FBVlo7O0FBa0JBO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLHdDQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsNkJBQUE7QUFmSjs7QUFpQkk7RUFDSSxnQkFBQTtFQUNBLFVBQUE7QUFmUjs7QUFpQlE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUFmWjs7QUFvQkE7RUFDSSxlQUFBO0FBakJKOztBQTZCUTtFQUNJLFdBQUE7QUExQlo7O0FBNkJRO0VBQ0ksZUFBQTtBQTNCWjs7QUFpQ0E7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBRUEscUJBQUE7QUEvQko7O0FBbUNBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQWhDSjs7QUFtQ0E7RUFDSSxlQUFBO0VBQ0Esd0JBQUE7QUFoQ0o7O0FBb0NBO0VBQ0ksZUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFqQ0o7O0FBb0NBO0VBQ0ksZUFBQTtBQWpDSjs7QUFvQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQWpDSjs7QUFvQ0E7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtBQWpDSjs7QUFvQ0E7RUFDSSxnQkFBQTtFQUNBLDBCQUFBO0FBakNKOztBQW9DQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EseUNBQUE7QUFqQ0oiLCJmaWxlIjoibmV3LXVzZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy92aWV3IHByb2ZpbGUgY3NzXHJcbi5oZWFkZXIge1xyXG4gICAgbWFyZ2luLXRvcDogMzVweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uYmFjay1idXR0b24ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgIGJveC1zaGFkb3c6IDJweCAzcHggNXB4IDVweCB3aGl0ZXNtb2tlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICBoZWlnaHQ6IDMzcHg7XHJcbiAgICB3aWR0aDogMzNweDtcclxufVxyXG5cclxuLnRleHQge1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuXHJcbi5hdmF0YXIge1xyXG4gICAgaGVpZ2h0OiAxMThweDtcclxuICAgIHdpZHRoOiAxMThweDtcclxuICAgIG1hcmdpbjogMzVweCBhdXRvIDBweCBhdXRvO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbn1cclxuXHJcbi5uYW1lIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIG1hcmdpbjogMTVweCAwcHggMHB4IDBweDtcclxufVxyXG5cclxuLnRleHQyIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIG1hcmdpbjogOHB4IDBweCAwcHggMHB4O1xyXG5cclxufVxyXG5cclxuLnJhbmdlIHtcclxuICAgIGhlaWdodDogNjRweDtcclxuICAgIG1heC13aWR0aDogMzAwcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAzM3B4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxcHggMjBweCAxOXB4IHdoaXRlc21va2U7XHJcblxyXG4gICAgcCB7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5hY3Rpdml0eSB7XHJcbiAgICBtYXgtd2lkdGg6IDM0MHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDogMjVweDtcclxufVxyXG5cclxuLnRleHQzIHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcblxyXG4udGV4dDQge1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgICBmb250LXNpemU6IDlweDtcclxufVxyXG5cclxuLnZpZXcge1xyXG4gICAgbWFyZ2luOiAzNHB4IDBweCAwcHggMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcblxyXG5cclxuXHJcbiAgICBpb24tY29sIHtcclxuICAgICAgICBtYXgtd2lkdGg6IDM4MnB4O1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IDk5cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAgICAgICBhbGlnbi1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBtYXJnaW46IDBweCA1cHggMjdweCA1cHg7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBib3gtc2hhZG93OiAycHggNHB4IDVweCAjMDAwMDAwMjk7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuXHJcbiAgICAgICAgLnVzZXJfaW1nIHtcclxuICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzE3QTUyNTtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAubS0xIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAzLjVweCAzcHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAubS0yIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAxNXB4IDBweCAwcHggNXB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnRpdGxlIHtcclxuXHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5zdWJ0aXRsZSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogOXB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLmxvY2F0aW9uX2ltZyB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuXHJcbn1cclxuXHJcbi5yZWZlcl9sb2d1dCB7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBtYXgtd2lkdGg6IDM2M3B4O1xyXG4gICAgbWFyZ2luOiAxNXB4IGF1dG8gMjNweCBhdXRvO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxcHggMjBweCAxOXB4IHdoaXRlc21va2U7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG5cclxuICAgIGRpdiB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgICB3aWR0aDogNjUlO1xyXG5cclxuICAgICAgICBwIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmljb24ge1xyXG4gICAgbWFyZ2luLXRvcDogNnB4O1xyXG59XHJcblxyXG5cclxuXHJcblxyXG5cclxuLy8gZWRpdCBwcm9maWxlIGNzc1xyXG5pb24taGVhZGVyIHtcclxuXHJcbiAgICBpb24tdG9vbGJhciB7XHJcblxyXG4gICAgICAgIC53LTEge1xyXG4gICAgICAgICAgICB3aWR0aDogNDJweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHAge1xyXG4gICAgICAgICAgICBtYXJnaW46IDAlIGF1dG87XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5cclxuaW9uLWlucHV0IHtcclxuICAgIGhlaWdodDogNTVweDtcclxuICAgIG1heC13aWR0aDogMzM2cHg7XHJcbiAgICBib3JkZXI6IHNvbGlkIGJsYWNrIDFweDtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDIwcHg7XHJcbiAgICAtLXBhZGRpbmctZW5kOiAxNnB4O1xyXG5cclxuICAgIG9wYWNpdHk6IDEgIWltcG9ydGFudDtcclxuXHJcbn1cclxuXHJcbi5sYWJlbCB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgICBtYXgtd2lkdGg6IDMyNHB4O1xyXG4gICAgYm9yZGVyOiBzb2xpZCBibGFjayAxcHg7XHJcbn1cclxuXHJcbi5pbnB1dDEge1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgbWFyZ2luOiAyOXB4IDBweCAwcHggMHB4O1xyXG5cclxufVxyXG5cclxuLmlucHV0MiB7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIG1hcmdpbjogMTBweDtcclxuICAgIG9wYWNpdHk6IDAuNjtcclxufVxyXG5cclxuLmljb24ge1xyXG4gICAgdGV4dC1hbGlnbjogZW5kO1xyXG59XHJcblxyXG4udGV4eHQge1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgICBvcGFjaXR5OiAwLjY7XHJcbn1cclxuXHJcbmlvbi1idXR0b24ge1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgbWF4LXdpZHRoOiAzMjdweDtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIG1hcmdpbi1ib3R0b206IDM0cHg7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuXHJcbi5pbnB1dF90aXRsZSB7XHJcbiAgICBtYXgtd2lkdGg6IDMwMHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvIGF1dG8gOXB4IGF1dG87XHJcbn1cclxuXHJcbi5jYXB0dXJlX2ltZyB7XHJcbiAgICB3aWR0aDogMjlweDtcclxuICAgIGhlaWdodDogMjlweDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoODRweCwgLTM1cHgsIDEwcHgpO1xyXG59Il19 */";

/***/ }),

/***/ 3730:
/*!********************************************************!*\
  !*** ./src/app/new-user/new-user.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n\r\n  <ion-header class=\"ion-no-border\">\r\n    <ion-toolbar>\r\n\r\n        <div slot=\"start\" class=\"back-button\">\r\n          <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n        </div>\r\n        <div>\r\n          <p class=\"text\"><b>Create Profile</b></p>\r\n        </div>\r\n\r\n        <div slot=\"end\" class=\"w-1\"></div>\r\n\r\n    </ion-toolbar>\r\n\r\n  </ion-header>\r\n\r\n  <!-- get  -->\r\n  <ion-avatar class=\"avatar\">\r\n    <img src=\"\"  id=\"cameraImage\" alt=\"\">\r\n    <!-- get img buttton  -->\r\n    <div class=\"capture_img\" (click)=\"capture_img()\" >\r\n      <img src=\"./../../assets/edit_img.png\" alt=\"\">\r\n    </div>\r\n  </ion-avatar>\r\n  <!-- Name -->\r\n  <ion-row class=\"input_title\">\r\n    <p class=\"input1\"><b>Name</b></p>\r\n  </ion-row>\r\n  <!-- Enter Name -->\r\n  <ion-input type=\"text\" placeholder=\"William\" [(ngModel)]=\"profile_data.name\"></ion-input>\r\n\r\n  <!-- Bio -->\r\n  <ion-row class=\"input_title\">\r\n    <p class=\"input1\"><b>Bio</b></p>\r\n  </ion-row>\r\n  <!-- enter Bio -->\r\n  <ion-input type=\"text\" placeholder=\"Keep enjoying more!\" [(ngModel)]=\"profile_data.bio\"></ion-input>\r\n\r\n  <!-- distance -->\r\n  <ion-row class=\"input_title\">\r\n    <p  class=\"input1\"><b>Socialize Distance</b></p>\r\n  </ion-row>\r\n  <!-- enter distance -->\r\n  <ion-input type=\"text\" placeholder=\"200m\" [(ngModel)]=\"profile_data.socialize_distance\" ></ion-input>\r\n\r\n  <!-- range -->\r\n  <ion-row class=\"input_title\">\r\n    <div style=\"    display: flex;\r\n    align-items: center;\">\r\n      <img src=\"./../../assets/Vector.png\" alt=\"\" srcset=\"\">\r\n    </div>\r\n    <p class=\"input2 m-1\">Set between 100m and 30km</p>\r\n  </ion-row>\r\n\r\n  <!-- Submit button -->\r\n  <ion-button shape=\"round\" expand=\"full\" (click)=\"submit_profile_data()\">\r\n    <b>Save</b>\r\n  </ion-button>\r\n\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_new-user_new-user_module_ts.js.map