"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_location_location_module_ts"],{

/***/ 5:
/*!*****************************************************!*\
  !*** ./src/app/location/location-routing.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocationPageRoutingModule": () => (/* binding */ LocationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _location_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./location.page */ 1785);




const routes = [
    {
        path: '',
        component: _location_page__WEBPACK_IMPORTED_MODULE_0__.LocationPage
    }
];
let LocationPageRoutingModule = class LocationPageRoutingModule {
};
LocationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LocationPageRoutingModule);



/***/ }),

/***/ 7718:
/*!*********************************************!*\
  !*** ./src/app/location/location.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocationPageModule": () => (/* binding */ LocationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _location_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./location-routing.module */ 5);
/* harmony import */ var _location_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./location.page */ 1785);







let LocationPageModule = class LocationPageModule {
};
LocationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _location_routing_module__WEBPACK_IMPORTED_MODULE_0__.LocationPageRoutingModule
        ],
        declarations: [_location_page__WEBPACK_IMPORTED_MODULE_1__.LocationPage]
    })
], LocationPageModule);



/***/ }),

/***/ 1785:
/*!*******************************************!*\
  !*** ./src/app/location/location.page.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocationPage": () => (/* binding */ LocationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _location_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./location.page.html?ngResource */ 3594);
/* harmony import */ var _location_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./location.page.scss?ngResource */ 1790);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);




let LocationPage = class LocationPage {
    constructor() { }
    ngOnInit() {
    }
};
LocationPage.ctorParameters = () => [];
LocationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-location',
        template: _location_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_location_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LocationPage);



/***/ }),

/***/ 1790:
/*!********************************************************!*\
  !*** ./src/app/location/location.page.scss?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "ion-list {\n  height: 100%;\n  display: flex;\n  align-items: center;\n  flex-direction: column;\n  justify-content: center;\n}\n\n.banner {\n  width: 223px;\n  height: 223px;\n  border-radius: 100%;\n  background-color: #FDEAD1;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.banner img {\n  height: 174px;\n  width: 174px;\n}\n\np {\n  text-align: center;\n  margin-top: 40px;\n  font-size: smaller;\n}\n\nion-button {\n  --background: #F2910C;\n  --border-radius: 100px;\n  height: 60px;\n  width: 270px;\n  padding-top: 20px;\n  color: white;\n  text-transform: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvY2F0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtBQUNKOztBQUNJO0VBQ0ksYUFBQTtFQUNBLFlBQUE7QUFDUjs7QUFHQTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUFKOztBQUlBO0VBQ0kscUJBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUFESiIsImZpbGUiOiJsb2NhdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbGlzdCB7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG5cclxuLmJhbm5lciB7XHJcbiAgICB3aWR0aDogMjIzcHg7XHJcbiAgICBoZWlnaHQ6IDIyM3B4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNGREVBRDE7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cclxuICAgIGltZyB7XHJcbiAgICAgICAgaGVpZ2h0OiAxNzRweDtcclxuICAgICAgICB3aWR0aDogMTc0cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbnAge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luLXRvcDogNDBweDtcclxuICAgIGZvbnQtc2l6ZTogc21hbGxlcjsgXHJcblxyXG59XHJcblxyXG5pb24tYnV0dG9uIHtcclxuICAgIC0tYmFja2dyb3VuZDogI0YyOTEwQztcclxuICAgIC0tYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICB3aWR0aDogMjcwcHg7XHJcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG59Il19 */";

/***/ }),

/***/ 3594:
/*!********************************************************!*\
  !*** ./src/app/location/location.page.html?ngResource ***!
  \********************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n   \r\n  <ion-list>\r\n    <div class=\"banner\">\r\n      <img src=\"../../assets/lovepik-map-location-icon-free-vector-illustration-png-image_401494181_wh1200-removebg-preview 1.png\">\r\n    </div>\r\n  \r\n    <p>Turn on your location to track nearby companies and jobs.</p>\r\n    \r\n    <ion-button [routerLink]=\"['/tabs/tab1']\">Location On</ion-button>\r\n  </ion-list>\r\n\r\n</ion-content>\r\n\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_location_location_module_ts.js.map