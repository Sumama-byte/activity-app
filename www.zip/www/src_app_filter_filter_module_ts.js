"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_filter_filter_module_ts"],{

/***/ 1777:
/*!*************************************************!*\
  !*** ./src/app/filter/filter-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterPageRoutingModule": () => (/* binding */ FilterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _filter_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./filter.page */ 432);




const routes = [
    {
        path: '',
        component: _filter_page__WEBPACK_IMPORTED_MODULE_0__.FilterPage
    }
];
let FilterPageRoutingModule = class FilterPageRoutingModule {
};
FilterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FilterPageRoutingModule);



/***/ }),

/***/ 7655:
/*!*****************************************!*\
  !*** ./src/app/filter/filter.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterPageModule": () => (/* binding */ FilterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _filter_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./filter-routing.module */ 1777);
/* harmony import */ var _filter_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./filter.page */ 432);







let FilterPageModule = class FilterPageModule {
};
FilterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _filter_routing_module__WEBPACK_IMPORTED_MODULE_0__.FilterPageRoutingModule
        ],
        declarations: [_filter_page__WEBPACK_IMPORTED_MODULE_1__.FilterPage]
    })
], FilterPageModule);



/***/ }),

/***/ 432:
/*!***************************************!*\
  !*** ./src/app/filter/filter.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FilterPage": () => (/* binding */ FilterPage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _filter_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./filter.page.html?ngResource */ 3497);
/* harmony import */ var _filter_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./filter.page.scss?ngResource */ 9848);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);








let FilterPage = class FilterPage {
  constructor(route, global, apicall) {
    this.route = route;
    this.global = global;
    this.apicall = apicall;
    this.btnRangeData = [{
      id: 1,
      range: 100
    }, {
      id: 2,
      range: 200
    }, {
      id: 3,
      range: 300
    }, {
      id: 4,
      range: 400
    }, {
      id: 5,
      range: 500
    }, {
      id: 6,
      range: 600
    }];
    this.activitybyDate = {
      date: ''
    };
  }

  ngOnInit() {}

  go_to_search() {
    this.route.navigate(['/tabs/tab3']);
  }

  getactivitySocialRange(range) {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.apicall.api_getactivitySocialRange(range);
    })();
  }

  getactivity(event) {
    const x = event.detail.value;
    console.log(x);
    this.apicall.api_getactivitySocialRange(x);
  }

  getcurrentDateActivity() {
    var _this2 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.apicall.api_getcurrentDateactivity();
    })();
  }

  getOneWeekActivity() {
    var _this3 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.apicall.api_getoneWeekactivity();
    })();
  }

  getactivitybyDate(event) {
    var _this4 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(event.detail.value);
      _this4.activitybyDate.date = event.detail.value;
      console.log(_this4.activitybyDate);
      yield _this4.apicall.api_getactivitybymanualDate(_this4.activitybyDate);
    })();
  }

};

FilterPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

FilterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-filter',
  template: _filter_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_filter_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], FilterPage);


/***/ }),

/***/ 9848:
/*!****************************************************!*\
  !*** ./src/app/filter/filter.page.scss?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = ".container {\n  margin: 20px 15px;\n}\n\n.flex {\n  display: flex;\n  flex-wrap: wrap;\n}\n\nion-input {\n  min-width: 222px;\n  border: 1px solid rgb(127, 127, 127);\n  border-radius: 6px;\n}\n\n.filter_button {\n  min-width: 110px;\n  --background: transparent ;\n  --background-activated: #F2910C;\n  --background-focused: #F2910C;\n  --background-hover:#F2910C;\n  border: 1px solid rgb(127, 127, 127);\n  margin: 0% auto 12px auto;\n  border-radius: 6px;\n  text-transform: none;\n  --color-activated: white;\n}\n\n.apply_filter {\n  --background:var(--ion-color-secondary);\n  --background-activated: #F2910C;\n  --background-focused: #F2910C;\n  --background-hover:#F2910C;\n  margin: 20px auto;\n  text-transform: none;\n  --color:white;\n  --color-activated: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbHRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtBQUNKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLGVBQUE7QUFDSjs7QUFDQTtFQUNJLGdCQUFBO0VBQ0Esb0NBQUE7RUFDQSxrQkFBQTtBQUVKOztBQUFBO0VBQ0ksZ0JBQUE7RUFDQSwwQkFBQTtFQUNBLCtCQUFBO0VBQ0EsNkJBQUE7RUFDQSwwQkFBQTtFQUNBLG9DQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0Esd0JBQUE7QUFHSjs7QUFEQTtFQUNJLHVDQUFBO0VBQ0EsK0JBQUE7RUFDQSw2QkFBQTtFQUNBLDBCQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLGFBQUE7RUFDQSx3QkFBQTtBQUlKIiwiZmlsZSI6ImZpbHRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVye1xyXG4gICAgbWFyZ2luOiAyMHB4IDE1cHggO1xyXG5cclxufVxyXG4uZmxleHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LXdyYXA6IHdyYXA7XHJcbn1cclxuaW9uLWlucHV0e1xyXG4gICAgbWluLXdpZHRoOiAyMjJweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYigxMjcsIDEyNywgMTI3KTtcclxuICAgIGJvcmRlci1yYWRpdXM6NnB4O1xyXG59XHJcbi5maWx0ZXJfYnV0dG9ue1xyXG4gICAgbWluLXdpZHRoOiAxMTBweDtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgO1xyXG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI0YyOTEwQztcclxuICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiAjRjI5MTBDO1xyXG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNGMjkxMEM7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMTI3LCAxMjcsIDEyNyk7XHJcbiAgICBtYXJnaW46IDAlIGF1dG8gMTJweCBhdXRvO1xyXG4gICAgYm9yZGVyLXJhZGl1czo2cHg7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcclxuICAgIC0tY29sb3ItYWN0aXZhdGVkOiB3aGl0ZTtcclxufVxyXG4uYXBwbHlfZmlsdGVye1xyXG4gICAgLS1iYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnkpO1xyXG4gICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDogI0YyOTEwQztcclxuICAgIC0tYmFja2dyb3VuZC1mb2N1c2VkOiAjRjI5MTBDO1xyXG4gICAgLS1iYWNrZ3JvdW5kLWhvdmVyOiNGMjkxMEM7XHJcbiAgICBtYXJnaW46IDIwcHggYXV0bztcclxuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG4gICAgLS1jb2xvcjp3aGl0ZTtcclxuICAgIC0tY29sb3ItYWN0aXZhdGVkOiB3aGl0ZTtcclxufSJdfQ== */";

/***/ }),

/***/ 3497:
/*!****************************************************!*\
  !*** ./src/app/filter/filter.page.html?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n\r\n   <ion-list class=\"container\">\r\n    <h3><b>Filter</b></h3>\r\n  \r\n    <h5><b>Social Range</b></h5>\r\n  \r\n    <div class=\"flex\">\r\n      <ion-button class=\"filter_button\" mode=\"ios\" *ngFor=\"let data of btnRangeData\" (click)=\"getactivitySocialRange(data.range)\">{{data.range}}m</ion-button>\r\n      <!-- <ion-button class=\"filter_button\" mode=\"ios\">200m</ion-button>\r\n      <ion-button class=\"filter_button\" mode=\"ios\">300m</ion-button>\r\n      <ion-button class=\"filter_button\" mode=\"ios\">400m</ion-button>\r\n      <ion-button class=\"filter_button\" mode=\"ios\">500m</ion-button>\r\n      <ion-button class=\"filter_button\" mode=\"ios\">600m</ion-button> -->\r\n    </div>\r\n  \r\n    <div>\r\n      <ion-input placeholder=\"Manually Enter\" type=\"number\" (ionChange)=\"getactivity($event)\"></ion-input>\r\n    </div>\r\n  \r\n    <h3><b>Date</b></h3>\r\n  \r\n    <div class=\"flex\">\r\n      <ion-button class=\"filter_button\" mode=\"ios\" (click)=\"getcurrentDateActivity()\">Most Recent</ion-button>\r\n      <ion-button class=\"filter_button\" mode=\"ios\" (click)=\"getOneWeekActivity()\">This Week</ion-button>\r\n    </div>\r\n  \r\n    <div>\r\n      <p>Or manually select</p>\r\n      <ion-input type=\"date\" (ionChange)=\"getactivitybyDate($event)\"></ion-input>\r\n    </div>\r\n    <ion-button shape=\"round\" expand=\"block\" class=\"apply_filter\" mode=\"ios\" (click)=\"go_to_search()\">Apply Filter</ion-button>\r\n     \r\n \r\n   </ion-list>\r\n\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_filter_filter_module_ts.js.map