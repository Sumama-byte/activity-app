"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_canidates_canidates_module_ts"],{

/***/ 9782:
/*!*******************************************************!*\
  !*** ./src/app/canidates/canidates-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CanidatesPageRoutingModule": () => (/* binding */ CanidatesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _canidates_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./canidates.page */ 5629);




const routes = [
    {
        path: '',
        component: _canidates_page__WEBPACK_IMPORTED_MODULE_0__.CanidatesPage
    }
];
let CanidatesPageRoutingModule = class CanidatesPageRoutingModule {
};
CanidatesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CanidatesPageRoutingModule);



/***/ }),

/***/ 6947:
/*!***********************************************!*\
  !*** ./src/app/canidates/canidates.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CanidatesPageModule": () => (/* binding */ CanidatesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _canidates_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./canidates-routing.module */ 9782);
/* harmony import */ var _canidates_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./canidates.page */ 5629);







let CanidatesPageModule = class CanidatesPageModule {
};
CanidatesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _canidates_routing_module__WEBPACK_IMPORTED_MODULE_0__.CanidatesPageRoutingModule
        ],
        declarations: [_canidates_page__WEBPACK_IMPORTED_MODULE_1__.CanidatesPage]
    })
], CanidatesPageModule);



/***/ }),

/***/ 5629:
/*!*********************************************!*\
  !*** ./src/app/canidates/canidates.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CanidatesPage": () => (/* binding */ CanidatesPage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _canidates_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./canidates.page.html?ngResource */ 8844);
/* harmony import */ var _canidates_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./canidates.page.scss?ngResource */ 7989);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);








let CanidatesPage = class CanidatesPage {
  constructor(route, global, apicall) {
    this.route = route;
    this.global = global;
    this.apicall = apicall;
    this.selectTabs = 'going';
    this.going = [{
      id: 1,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'William'
    }, {
      id: 2,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'William'
    }];
    this.may_be_going = [{
      id: 1,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'Miller'
    }, {
      id: 2,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'Miller'
    }];
  }

  ngOnInit() {
    this.getAllStatus();
  }

  getAllStatus() {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.global.GetActivityStatus.subscribe(res => {
        _this.allStatus = res;
        console.log(_this.allStatus);
        _this.Going = _this.allStatus.filter(x => x.status === 'g');
        console.log(_this.Going);
        _this.MaybeGoing = _this.allStatus.filter(x => x.status === 'm');
        console.log(_this.MaybeGoing);
      });
    })();
  }

  go_back() {
    this.route.navigate(['/tabs/tab2']);
  }

};

CanidatesPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

CanidatesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-canidates',
  template: _canidates_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_canidates_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], CanidatesPage);


/***/ }),

/***/ 7989:
/*!**********************************************************!*\
  !*** ./src/app/canidates/canidates.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  margin-top: 10px;\n  display: flex;\n  align-items: center;\n}\n\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  margin-left: 15px;\n  height: 33px;\n  width: 33px;\n}\n\n.text {\n  margin: 0px;\n  text-align: center;\n  font-size: 18px;\n}\n\nion-segment {\n  width: 300px;\n  display: flex;\n  border-radius: 100px;\n  background: white;\n  box-shadow: 0px 0px 12px -6px rgba(0, 0, 0, 0.66);\n  -moz-box-shadow: 0px 0px 12px -6px rgba(0, 0, 0, 0.66);\n  margin: auto auto;\n}\n\nion-segment ion-segment-button {\n  --border-radius: 100px;\n  --indicator-color: #F2910C;\n  --color-checked: white;\n  padding: 10px;\n}\n\nion-row {\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  padding: 5px;\n}\n\nion-row ion-col {\n  min-height: 69px;\n  display: flex;\n  margin: 0px 5px 0px 5px;\n  padding: 0;\n  border-radius: 10px;\n  align-items: center;\n}\n\nion-row ion-col .user_img {\n  border: 2px solid #17A525;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 1px;\n  border-radius: 14px;\n  width: 50px;\n  height: 50px;\n  margin: 15px 0px 0px 5px;\n}\n\nion-row ion-col .user_img .userimg {\n  height: 100%;\n  width: 100%;\n  border-radius: 14px;\n}\n\nion-row ion-col .m-1 {\n  margin: 3.5px 12px;\n}\n\nion-row ion-col .m-2 {\n  margin: 15px 0px 0px 5px;\n}\n\nion-row ion-col .title {\n  font-size: 16px;\n  line-height: 18.75px;\n}\n\n.bold_lbl {\n  font-family: \"Roboto\", sans-serif;\n  font-weight: bold;\n  text-align: center;\n  margin-bottom: 5px;\n  margin-top: 50px;\n  text-transform: uppercase;\n  letter-spacing: 5px;\n  position: absolute;\n  top: 40%;\n  left: 0;\n  right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbmlkYXRlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtBQUNKOztBQUNBO0VBQ0ksbUJBQUE7RUFDQSxzQ0FBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFFSjs7QUFBQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFHSjs7QUFEQTtFQUNJLFlBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtFQUNBLGlEQUFBO0VBQ0Esc0RBQUE7RUFDQSxpQkFBQTtBQUlKOztBQUZJO0VBQ0ksc0JBQUE7RUFDQSwwQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtBQUlSOztBQURBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUVBLFlBQUE7QUFHSjs7QUFESTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFHUjs7QUFEUTtFQUNJLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHdCQUFBO0FBR1o7O0FBRlk7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FBSWhCOztBQUFRO0VBQ0ksa0JBQUE7QUFFWjs7QUFDUTtFQUNJLHdCQUFBO0FBQ1o7O0FBRVE7RUFDSSxlQUFBO0VBQ0Esb0JBQUE7QUFBWjs7QUFPQTtFQUNJLGlDQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7QUFKSiIsImZpbGUiOiJjYW5pZGF0ZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmhlYWRlcntcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcbi5iYWNrLWJ1dHRvbntcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICBib3gtc2hhZG93OiAycHggM3B4IDVweCA1cHggd2hpdGVzbW9rZTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG4gICAgaGVpZ2h0OiAzM3B4O1xyXG4gICAgd2lkdGg6IDMzcHg7XHJcbn1cclxuLnRleHR7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxufVxyXG5pb24tc2VnbWVudCB7XHJcbiAgICB3aWR0aDozMDBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDBweDsgICBcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDBweCAxMnB4IC02cHggcmdiKDAgMCAwIC8gNjYlKTtcclxuICAgIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCAxMnB4IC02cHggcmdiYSgwLCAwLCAwLCAwLjY2KTtcclxuICAgIG1hcmdpbjogYXV0byBhdXRvO1xyXG5cclxuICAgIGlvbi1zZWdtZW50LWJ1dHRvbiB7XHJcbiAgICAgICAgLS1ib3JkZXItcmFkaXVzOiAxMDBweDtcclxuICAgICAgICAtLWluZGljYXRvci1jb2xvcjogI0YyOTEwQztcclxuICAgICAgICAtLWNvbG9yLWNoZWNrZWQ6IHdoaXRlO1xyXG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICB9XHJcbn1cclxuaW9uLXJvdyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIFxyXG4gICAgcGFkZGluZzogNXB4O1xyXG5cclxuICAgIGlvbi1jb2wge1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IDY5cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBtYXJnaW46IDBweCA1cHggMHB4IDVweDtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHJcbiAgICAgICAgLnVzZXJfaW1nIHtcclxuICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzE3QTUyNTtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDFweDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgICAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogNTBweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAxNXB4IDBweCAwcHggNXB4O1xyXG4gICAgICAgICAgICAudXNlcmltZ3tcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICB9XHJcbiAgICAgICAgLm0tMSB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMy41cHggMTJweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5tLTIge1xyXG4gICAgICAgICAgICBtYXJnaW46IDE1cHggMHB4IDBweCA1cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAudGl0bGUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgICAgICAgIGxpbmUtaGVpZ2h0OiAxOC43NXB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG59XHJcblxyXG4uYm9sZF9sYmx7XHJcbiAgICBmb250LWZhbWlseTogJ1JvYm90bycgLCBzYW5zLXNlcmlmO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGxldHRlci1zcGFjaW5nOiA1cHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDQwJTtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxufSJdfQ== */";

/***/ }),

/***/ 8844:
/*!**********************************************************!*\
  !*** ./src/app/canidates/canidates.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n\r\n  <!-- header -->\r\n  <ion-list class=\"header\">\r\n     <ion-item lines=\"none\">\r\n      \r\n      <div slot=\"start\" class=\"back-button\" (click)=\"go_back()\">\r\n        <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n      </div>\r\n\r\n        \r\n      <p class=\"text ion-text-center\"><b>Beach Party</b></p>\r\n   \r\n\r\n     </ion-item>    \r\n  </ion-list>\r\n\r\n  <!-- segment change  -->\r\n  <ion-segment [(ngModel)]=\"selectTabs\" mode=\"ios\" value=\"going\">\r\n    <ion-segment-button value=\"going\">\r\n      <ion-label>Going</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"may_be_going\">\r\n      <ion-label>May be going</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n\r\n\r\n  <!-- canidates going -->\r\n\r\n  <ion-row *ngIf=\" selectTabs == 'going'\">\r\n    <ion-col size=\"12\" *ngFor=\"let data of Going\">\r\n\r\n      <div class=\"user_img\">\r\n        <img class=\"userimg\" src=\"{{this.data.img}}\" alt=\"\">\r\n      </div>\r\n\r\n      <div class=\"m-2\">\r\n        <p class=\"title m-1\"><b>{{this.data.name}}</b></p>\r\n      </div>\r\n    </ion-col>\r\n\r\n  <div *ngIf=\"this.Going == 0\">\r\n    <h3 class=\"bold_lbl\">There is no activity here.</h3>\r\n  </div>\r\n\r\n  </ion-row>\r\n\r\n\r\n  <!-- canidates may be going  -->\r\n\r\n  \r\n  <ion-row *ngIf=\" selectTabs == 'may_be_going' \">\r\n    <ion-col size=\"12\" *ngFor=\"let data of MaybeGoing\">\r\n\r\n      <div class=\"user_img\">\r\n        <img class=\"userimg\" src=\"{{this.data.img}}\" alt=\"\">\r\n      </div>\r\n\r\n      <div class=\"m-2\">\r\n        <p class=\"title m-1\"><b>{{this.data.name}}</b></p>\r\n      </div>\r\n    </ion-col>\r\n    <div *ngIf=\"this.MaybeGoing == 0\">\r\n      <h3 class=\"bold_lbl\">There is no activity here.</h3>\r\n    </div>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_canidates_canidates_module_ts.js.map