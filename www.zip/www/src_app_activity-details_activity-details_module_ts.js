"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_activity-details_activity-details_module_ts"],{

/***/ 3987:
/*!*********************************************************************!*\
  !*** ./src/app/activity-details/activity-details-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActivityDetailsPageRoutingModule": () => (/* binding */ ActivityDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _activity_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./activity-details.page */ 8480);




const routes = [
    {
        path: '',
        component: _activity_details_page__WEBPACK_IMPORTED_MODULE_0__.ActivityDetailsPage
    }
];
let ActivityDetailsPageRoutingModule = class ActivityDetailsPageRoutingModule {
};
ActivityDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ActivityDetailsPageRoutingModule);



/***/ }),

/***/ 5550:
/*!*************************************************************!*\
  !*** ./src/app/activity-details/activity-details.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActivityDetailsPageModule": () => (/* binding */ ActivityDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _activity_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./activity-details-routing.module */ 3987);
/* harmony import */ var _activity_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./activity-details.page */ 8480);







let ActivityDetailsPageModule = class ActivityDetailsPageModule {
};
ActivityDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _activity_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.ActivityDetailsPageRoutingModule
        ],
        declarations: [_activity_details_page__WEBPACK_IMPORTED_MODULE_1__.ActivityDetailsPage]
    })
], ActivityDetailsPageModule);



/***/ }),

/***/ 8480:
/*!***********************************************************!*\
  !*** ./src/app/activity-details/activity-details.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActivityDetailsPage": () => (/* binding */ ActivityDetailsPage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _activity_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./activity-details.page.html?ngResource */ 5295);
/* harmony import */ var _activity_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./activity-details.page.scss?ngResource */ 9030);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);








let ActivityDetailsPage = class ActivityDetailsPage {
  constructor(route, global, apicall) {
    this.route = route;
    this.global = global;
    this.apicall = apicall;
    this.postStatus = {
      a_id: '',
      u_id: '',
      status: ''
    };
  }

  ngOnInit() {
    this.data = history.state.data;
    this.postStatus.a_id = this.data.a_id;
    this.global.Uid.subscribe(uid => {
      console.log(uid);
      this.postStatus.u_id = uid;
    });
  } //navigation


  nav_back() {
    this.route.navigate(['/tabs/tab1']);
  } //data to going 


  going() {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('going');
      _this.postStatus.status = "g";
      console.log(_this.postStatus);
      yield _this.apicall.api_postStatus(_this.postStatus);
    })();
  } //data to may_be_going 


  may_be_going() {
    var _this2 = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('may_be_going');
      _this2.postStatus.status = "m";
      console.log(_this2.postStatus);
      yield _this2.apicall.api_postStatus(_this2.postStatus);
    })();
  }

};

ActivityDetailsPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

ActivityDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-activity-details',
  template: _activity_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_activity_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ActivityDetailsPage);


/***/ }),

/***/ 9030:
/*!************************************************************************!*\
  !*** ./src/app/activity-details/activity-details.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = ".back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  height: 33px;\n  width: 33px;\n}\n\n.txt {\n  font-size: 18px;\n  margin: auto;\n}\n\n.image {\n  width: 100%;\n  height: 230px;\n  margin: 30px auto 0px auto;\n  box-shadow: 2px 2px 37px rgba(0, 0, 0, 0.215);\n}\n\n.algin_left {\n  display: flex;\n}\n\n.div2 {\n  width: 90%;\n  margin-left: auto;\n  margin-right: auto;\n}\n\n.div2 .para {\n  margin-left: auto;\n  margin-right: auto;\n  font-size: small;\n}\n\n.div2 .div3 {\n  font-size: smaller;\n  font-weight: bold;\n  padding: 0;\n}\n\n.div2 .coltime {\n  display: flex;\n}\n\n.div2 .div4 {\n  display: flex;\n  width: 37px;\n  height: 46px;\n  background-color: #F2910C;\n  color: white;\n  border-radius: 8px;\n  font-size: 21px;\n  font-weight: bolder;\n  background-image: url('div_ouline.png');\n  justify-content: center;\n  align-items: center;\n  margin: 8px;\n}\n\nion-button {\n  --background: #F2910C;\n  --border-radius: 100px;\n  height: 60px;\n  width: 150px;\n  padding-top: 20px;\n  color: white;\n  text-transform: none;\n  margin: 0px auto 25px auto;\n}\n\n.fs-0 {\n  width: 100%;\n  font-size: 12px;\n}\n\n.col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n}\n\nion-item {\n  --background: transparent;\n}\n\n.center {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjdGl2aXR5LWRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksbUJBQUE7RUFDQSxzQ0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBQUo7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUNBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSwwQkFBQTtFQUNBLDZDQUFBO0FBRUo7O0FBQ0k7RUFDSSxhQUFBO0FBRVI7O0FBQUE7RUFDSSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUdKOztBQURJO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBR1I7O0FBREk7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtBQUdSOztBQURFO0VBQ0UsYUFBQTtBQUdKOztBQURNO0VBQ0MsYUFBQTtFQUdFLFdBQUE7RUFDRCxZQUFBO0VBRUEseUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFHQSx1Q0FBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FBRlI7O0FBU0E7RUFDSSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLDBCQUFBO0FBTko7O0FBU0E7RUFDSSxXQUFBO0VBQ0EsZUFBQTtBQU5KOztBQVFBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQUxKOztBQU9BO0VBQ0kseUJBQUE7QUFKSjs7QUFNQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBSEoiLCJmaWxlIjoiYWN0aXZpdHktZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgXHJcbi5iYWNrLWJ1dHRvbntcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICBib3gtc2hhZG93OiAycHggM3B4IDVweCA1cHggd2hpdGVzbW9rZTtcclxuICAgIGhlaWdodDogMzNweDtcclxuICAgIHdpZHRoOiAzM3B4O1xyXG59XHJcbi50eHR7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbn1cclxuLmltYWdle1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDIzMHB4O1xyXG4gICAgbWFyZ2luOiAzMHB4IGF1dG8gMHB4IGF1dG87XHJcbiAgICBib3gtc2hhZG93OiAycHggMnB4IDM3cHggcmdiYSgwLCAwLCAwLCAwLjIxNSk7XHJcbn1cclxuXHJcbiAgICAuYWxnaW5fbGVmdHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgfVxyXG4uZGl2MntcclxuICAgIHdpZHRoOiA5MCU7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgXHJcbiAgICAucGFyYXtcclxuICAgICAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgICAgICAgZm9udC1zaXplOiBzbWFsbDtcclxuICAgIH1cclxuICAgIC5kaXYze1xyXG4gICAgICAgIGZvbnQtc2l6ZTogc21hbGxlcjtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgfVxyXG4gIC5jb2x0aW1le1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICB9XHJcbiAgICAgIC5kaXY0e1xyXG4gICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAvLyB3aWR0aDogMzdweDtcclxuICAgICAgICAvLyBoZWlnaHQ6IDQzcHg7XHJcbiAgICAgICAgIHdpZHRoOiAzN3B4O1xyXG4gICAgICAgIGhlaWdodDogNDZweDtcclxuICAgICAgXHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0YyOTEwQztcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjFweDtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZGVyO1xyXG4gICAgICAgIC8vIGJhY2tncm91bmQtaW1hZ2U6IHVybChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM2Nzdmcgd2lkdGg9JzEwMCUyNScgaGVpZ2h0PScxMDAlMjUnIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyclM2UlM2NyZWN0IHdpZHRoPScxMDAlMjUnIGhlaWdodD0nMTAwJTI1JyBmaWxsPSdub25lJyByeD0nMTAnIHJ5PScxMCcgc3Ryb2tlPSdibGFjaycgc3Ryb2tlLXdpZHRoPSc2JyBzdHJva2UtZGFzaGFycmF5PScxMDAlMmM0NScgc3Ryb2tlLWRhc2hvZmZzZXQ9JzkyJyBzdHJva2UtbGluZWNhcD0nc3F1YXJlJy8lM2UlM2Mvc3ZnJTNlXCIpO1xyXG4gICAgICAgIC8vIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4vLi4vLi4vYXNzZXRzL2Rpdl9vdWxpbmUucG5nKTtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIG1hcmdpbjogOHB4O1xyXG4gICAgfVxyXG5cclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgIFxyXG59XHJcbmlvbi1idXR0b24ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjI5MTBDO1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAxMDBweDtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIHBhZGRpbmctdG9wOiAyMHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbiAgICBtYXJnaW46MHB4IGF1dG8gMjVweCBhdXRvO1xyXG59XHJcblxyXG4uZnMtMHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcbi5jb2x7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5pb24taXRlbXtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbn1cclxuLmNlbnRlcntcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn0iXX0= */";

/***/ }),

/***/ 5295:
/*!************************************************************************!*\
  !*** ./src/app/activity-details/activity-details.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\r\n  <ion-item lines=\"none\" class=\"ion-text-center\">\r\n\r\n    <div slot=\"start\" class=\"back-button\" (click)=\"nav_back()\">\r\n      <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n    </div>\r\n    <!-- Activtiy title -->\r\n    <p class=\"txt\">{{data.activity_name}}</p>\r\n\r\n    <ion-icon slot=\"end\" name=\"heart-outline\"></ion-icon>\r\n  </ion-item>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"col\">\r\n      <!-- location image  -->\r\n       \r\n        <img class=\"image\" src=\"{{data.a_image}}\" alt=\"\">\r\n \r\n\r\n      <ion-item lines=\"none\" class=\"fs-0\">\r\n        <div slot=\"start\" class=\"algin_left\">\r\n\r\n          <ion-icon name=\"location-outline\" size=\"large\"></ion-icon>\r\n\r\n          <!-- activity location -->\r\n          <p> {{data.location}}</p>\r\n\r\n        </div>\r\n        <!-- Avtivity range -->\r\n        <div slot=\"end\">\r\n          <p> Within {{data.social_range}} Km</p>\r\n        </div>\r\n      </ion-item>\r\n\r\n\r\n    </ion-col>\r\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"center\">\r\n\r\n      <div class=\"div2\">\r\n        <!-- activity description -->\r\n        <p class=\"para\">\r\n          {{data.description}}\r\n        </p>\r\n        <!-- attendies title -->\r\n        <p><b>Number Of Atendees Allowed</b></p>\r\n        <!-- canidaties nunber -->\r\n        <h5><b>{{data.max_atendes}} </b></h5>\r\n        <ion-row>\r\n          <ion-col size=\"6\" class=\"div3\">Start Time</ion-col>\r\n          <ion-col size=\"6\" class=\"div3\">End Time</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n\r\n          <!-- Activity Start time  -->\r\n          <ion-col size=\"6\" class=\"coltime\">\r\n            <div class=\"div4\">\r\n                {{data.start_time}}\r\n            </div>\r\n            <div class=\"div4\">00</div>\r\n          </ion-col>\r\n          <!-- Activity end time  -->\r\n          <ion-col size=\"6\" class=\"coltime\">\r\n            <div class=\"div4\">{{data.end_time}}</div>\r\n            <div class=\"div4\">00</div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n      <ion-item lines=\"none\">\r\n        <!-- Going button -->\r\n        <ion-button   (click)=\"going()\">I am Going</ion-button>\r\n        <!--May be Going button -->\r\n        <ion-button   (click)=\"may_be_going()\">Maybe Going</ion-button>\r\n      </ion-item>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_activity-details_activity-details_module_ts.js.map