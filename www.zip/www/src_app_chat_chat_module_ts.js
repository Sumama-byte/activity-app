"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_chat_chat_module_ts"],{

/***/ 4761:
/*!*********************************************!*\
  !*** ./src/app/chat/chat-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChatPageRoutingModule": () => (/* binding */ ChatPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _chat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chat.page */ 4099);




const routes = [
    {
        path: '',
        component: _chat_page__WEBPACK_IMPORTED_MODULE_0__.ChatPage
    }
];
let ChatPageRoutingModule = class ChatPageRoutingModule {
};
ChatPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChatPageRoutingModule);



/***/ }),

/***/ 4709:
/*!*************************************!*\
  !*** ./src/app/chat/chat.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChatPageModule": () => (/* binding */ ChatPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _chat_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chat-routing.module */ 4761);
/* harmony import */ var _chat_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chat.page */ 4099);
/* harmony import */ var ngx_autosize__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-autosize */ 327);








let ChatPageModule = class ChatPageModule {
};
ChatPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _chat_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChatPageRoutingModule,
            ngx_autosize__WEBPACK_IMPORTED_MODULE_7__.AutosizeModule
        ],
        declarations: [_chat_page__WEBPACK_IMPORTED_MODULE_1__.ChatPage]
    })
], ChatPageModule);



/***/ }),

/***/ 4099:
/*!***********************************!*\
  !*** ./src/app/chat/chat.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChatPage": () => (/* binding */ ChatPage)
/* harmony export */ });
/* harmony import */ var D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _chat_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chat.page.html?ngResource */ 9910);
/* harmony import */ var _chat_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chat.page.scss?ngResource */ 6232);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);









let ChatPage = class ChatPage {
  constructor(route, global, apicall) {
    this.route = route;
    this.global = global;
    this.apicall = apicall;
    this.messages = [{
      user: 'Rehan',
      createdAt: 150023234,
      msg: 'Hey whats up?'
    }, {
      user: 'Usman',
      createdAt: 150027234,
      msg: 'working on ionic'
    }, {
      user: 'Rehan',
      createdAt: 150025234,
      msg: 'lorem ipsum '
    }];
    this.currentUser = 'Rehan';
    this.newMsg = '';
    this.userMsg = {
      sender_id: '',
      reciever_id: '',
      msg: ''
    };
    this.userData = {
      reciever_id: ''
    };
  }

  ngOnInit() {
    this.getChat();
    this.global.Chat.subscribe(res => {
      this.chat = res;
      console.log(this.chat);
      this.userMsg.reciever_id = this.chat.u_id;
      this.userData.reciever_id = this.chat.u_id;
    });
    this.global.Uid.subscribe(uid => {
      this.userMsg.sender_id = uid;
      console.log(uid);
    });
  }

  getChat() {
    this.global.Storchat.subscribe(res => {
      this.allChat = res;
      console.log(this.allChat);
      console.log(res);
    });
  }

  sendMessage() {
    var _this = this;

    return (0,D_activityApp_activity_app_1_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.apicall.api_postChat(_this.userMsg);
      console.log(_this.userMsg);
      yield _this.apicall.api_getChat(_this.userData);
      setTimeout(() => {
        _this.content.scrollToBottom(200);
      });
    })();
  }

  go_back() {
    this.route.navigate(['/tabs/tab4']);
  }

};

ChatPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

ChatPage.propDecorators = {
  content: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_6__.ViewChild,
    args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonContent]
  }]
};
ChatPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
  selector: 'app-chat',
  template: _chat_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_chat_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ChatPage);


/***/ }),

/***/ 6232:
/*!************************************************!*\
  !*** ./src/app/chat/chat.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-list {\n  box-shadow: 2px 2px 14px rgba(0, 0, 0, 0.225);\n}\n\nion-label {\n  margin-left: 10px;\n}\n\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  height: 33px;\n  width: 33px;\n}\n\nimg {\n  border-radius: 100%;\n}\n\n.time {\n  opacity: 0.7;\n  font-size: 8px;\n}\n\n.message {\n  padding: 10px;\n  margin: 20px;\n  white-space: pre-wrap;\n}\n\n.other-message {\n  border-radius: 0px 16px 16px 16px;\n  background: var(--ion-color-primary);\n  color: #fff;\n}\n\n.my-message {\n  border-radius: 16px 0px 16px 16px;\n  box-shadow: 2px 2px 17px rgba(0, 0, 0, 0.225);\n  background: none;\n  color: rgb(0, 0, 0);\n}\n\n.my_img {\n  width: 26px;\n  height: 26px;\n  border-radius: 100px;\n  position: absolute;\n  right: 0;\n  top: 107%;\n}\n\n.other_img {\n  width: 26px;\n  height: 26px;\n  border-radius: 100px;\n  position: absolute;\n  left: -15px;\n  top: 107%;\n}\n\n.userimage {\n  height: 100%;\n  width: 100%;\n}\n\n.time {\n  color: #dfdfdf;\n  float: right;\n  font-size: small;\n}\n\n.message-input {\n  width: 100%;\n  border: 1px solid #F39200;\n  border-radius: 100px;\n  background: #fff;\n  resize: none;\n  padding-left: 10px;\n  padding-right: 10px;\n  margin-left: 43px;\n}\n\n::placeholder {\n  padding-top: 10px;\n}\n\n.msg-btn {\n  --padding-start: 0.5em;\n  --padding-end: 0.5em;\n}\n\n.p-1 {\n  padding: 13px 0px 13px 13px;\n  --background: transparent;\n}\n\nion-fab-button {\n  --background-foucsed: none;\n  --background-hover: none;\n}\n\nion-footer ion-toolbar {\n  --background: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksNkNBQUE7QUFDSjs7QUFFQTtFQUNJLGlCQUFBO0FBQ0o7O0FBRUE7RUFDSSxtQkFBQTtFQUNBLHNDQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUFDSjs7QUFFQTtFQUNJLG1CQUFBO0FBQ0o7O0FBRUE7RUFFSSxZQUFBO0VBQ0EsY0FBQTtBQUFKOztBQUdBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtBQUFKOztBQUdBO0VBQ0ksaUNBQUE7RUFDQSxvQ0FBQTtFQUNBLFdBQUE7QUFBSjs7QUFHQTtFQUNJLGlDQUFBO0VBQ0EsNkNBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBQUo7O0FBR0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtBQUFKOztBQUdBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7QUFBSjs7QUFHQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0FBQUo7O0FBR0E7RUFDSSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQUo7O0FBR0E7RUFDSSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUFKOztBQUdBO0VBQ0ksaUJBQUE7QUFBSjs7QUFHQTtFQUNJLHNCQUFBO0VBQ0Esb0JBQUE7QUFBSjs7QUFHQTtFQUNJLDJCQUFBO0VBQ0EseUJBQUE7QUFBSjs7QUFHQTtFQUNJLDBCQUFBO0VBQ0Esd0JBQUE7QUFBSjs7QUFLSTtFQUNJLGtCQUFBO0FBRlIiLCJmaWxlIjoiY2hhdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tbGlzdCB7XHJcbiAgICBib3gtc2hhZG93OiAycHggMnB4IDE0cHggcmdiYSgwLCAwLCAwLCAwLjIyNSlcclxufVxyXG5cclxuaW9uLWxhYmVsIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG59XHJcblxyXG4uYmFjay1idXR0b24ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgIGJveC1zaGFkb3c6IDJweCAzcHggNXB4IDVweCB3aGl0ZXNtb2tlO1xyXG4gICAgaGVpZ2h0OiAzM3B4O1xyXG4gICAgd2lkdGg6IDMzcHg7XHJcbn1cclxuXHJcbmltZyB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG59XHJcblxyXG4udGltZSB7XHJcblxyXG4gICAgb3BhY2l0eTogMC43O1xyXG4gICAgZm9udC1zaXplOiA4cHg7XHJcbn1cclxuXHJcbi5tZXNzYWdlIHtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBtYXJnaW46IDIwcHg7XHJcbiAgICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7XHJcbn1cclxuXHJcbi5vdGhlci1tZXNzYWdlIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweCAxNnB4IDE2cHggMTZweDtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4ubXktbWVzc2FnZSB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNnB4IDBweCAxNnB4IDE2cHg7XHJcbiAgICBib3gtc2hhZG93OiAycHggMnB4IDE3cHggcmdiYSgwLCAwLCAwLCAwLjIyNSk7XHJcbiAgICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gICAgY29sb3I6IHJnYigwLCAwLCAwKTtcclxufVxyXG5cclxuLm15X2ltZyB7XHJcbiAgICB3aWR0aDogMjZweDtcclxuICAgIGhlaWdodDogMjZweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDEwNyU7XHJcbn1cclxuXHJcbi5vdGhlcl9pbWcge1xyXG4gICAgd2lkdGg6IDI2cHg7XHJcbiAgICBoZWlnaHQ6IDI2cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGxlZnQ6IC0xNXB4O1xyXG4gICAgdG9wOiAxMDclO1xyXG59XHJcblxyXG4udXNlcmltYWdle1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi50aW1lIHtcclxuICAgIGNvbG9yOiAjZGZkZmRmO1xyXG4gICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgZm9udC1zaXplOiBzbWFsbDtcclxufVxyXG5cclxuLm1lc3NhZ2UtaW5wdXQge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjRjM5MjAwO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcmVzaXplOiBub25lO1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgcGFkZGluZy1yaWdodDogMTBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiA0M3B4O1xyXG59XHJcblxyXG46OnBsYWNlaG9sZGVyIHtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG59XHJcblxyXG4ubXNnLWJ0biB7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDAuNWVtO1xyXG4gICAgLS1wYWRkaW5nLWVuZDogMC41ZW07XHJcbn1cclxuXHJcbi5wLTEge1xyXG4gICAgcGFkZGluZzogMTNweCAwcHggMTNweCAxM3B4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxufVxyXG5cclxuaW9uLWZhYi1idXR0b24ge1xyXG4gICAgLS1iYWNrZ3JvdW5kLWZvdWNzZWQ6IG5vbmU7XHJcbiAgICAtLWJhY2tncm91bmQtaG92ZXI6IG5vbmU7XHJcbn1cclxuXHJcbmlvbi1mb290ZXIge1xyXG5cclxuICAgIGlvbi10b29sYmFyIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 9910:
/*!************************************************!*\
  !*** ./src/app/chat/chat.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <!-- header -->\r\n  <ion-list>\r\n    <ion-item lines=\"none\">\r\n\r\n      <ion-avatar slot=\"start\" class=\"back-button\" (click)=\"go_back()\">\r\n        <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n      </ion-avatar>\r\n      <ion-avatar>\r\n        <img src=\"{{chat.img}}\" class=\"img\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>{{chat.name}}</h2>\r\n        <!-- <p>{{chat.last_time}}</p> -->\r\n      </ion-label>\r\n      <ion-icon slot=\"end\" name=\"ellipsis-vertical\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-header>\r\n<ion-content>\r\n\r\n  <!-- message area -->\r\n  <ion-grid>\r\n    <ion-row *ngFor=\"let message of allChat\">\r\n      <ion-col size=\"9\" *ngIf=\"message.reciever_id\" class=\"message other-message\">\r\n        <!-- <b>{{message.user}}</b><br> -->\r\n        <span>{{message.reciever_msg}}</span>\r\n        <div class=\"time\" text-right><br>\r\n          {{message.reciever_date}} {{message.reciever_time}} \r\n        </div>\r\n\r\n        <div class=\"other_img\">\r\n          <img class=\"userimage\" src=\"{{message.receiver_img}}\" alt=\"\">\r\n        </div>\r\n      </ion-col>\r\n\r\n      <ion-col offset=\"3\" size=\"9\" *ngIf=\"message.sender_id\" class=\"message my-message\">\r\n        <!-- <b>{{message.user}}</b><br> -->\r\n        <span>{{message.sender_msg}}</span>\r\n        <div class=\"time\" text-right><br>\r\n          {{message.sender_date}} {{message.sender_time}} \r\n        </div>\r\n        <div class=\"my_img\">\r\n          <!-- user img -->\r\n          <img class=\"userimage\"  src=\"{{message.sender_img}}\" alt=\"\">\r\n        </div>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n\r\n<!-- enter msg -->\r\n<ion-fab horizontal=\"start\" vertical=\"bottom\" slot=\"fixed\">\r\n  <ion-fab-button>\r\n    <ion-icon color=\"light\" name=\"add\"></ion-icon>\r\n  </ion-fab-button>\r\n  <ion-fab-list side=\"top\">\r\n    <ion-fab-button color=\"light\">\r\n      <ion-icon name=\"logo-facebook\"></ion-icon>\r\n    </ion-fab-button>\r\n    <ion-fab-button color=\"light\">\r\n      <ion-icon name=\"logo-twitter\"></ion-icon>\r\n    </ion-fab-button>\r\n    <ion-fab-button color=\"light\">\r\n      <ion-icon name=\"logo-vimeo\"></ion-icon>\r\n    </ion-fab-button>\r\n    <ion-fab-button color=\"light\">\r\n      <ion-icon name=\"logo-google\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab-list>\r\n</ion-fab>\r\n<ion-footer class=\"ion-no-border\">\r\n\r\n  <ion-toolbar>\r\n\r\n    <ion-item lines=\"none\" class=\"p-1\">\r\n      <textarea autosize maxRows=\"4\" class=\"message-input\" placeholder=\"text here\" [(ngModel)]=\"userMsg.msg\" #txtmsg>\r\n       \r\n      </textarea> \r\n\r\n      <ion-button expand=\"block\" fill=\"clear\" color=\"primary\" *ngIf=\"txtmsg.value.length > 0\" class=\"msg-btn\"\r\n        (click)=\"sendMessage()\"> \r\n        <ion-icon name=\"send\" slot=\"icon-only\"></ion-icon>\r\n      </ion-button>\r\n    </ion-item>\r\n\r\n\r\n\r\n  </ion-toolbar>\r\n</ion-footer>";

/***/ }),

/***/ 327:
/*!*************************************************************!*\
  !*** ./node_modules/ngx-autosize/fesm2020/ngx-autosize.mjs ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AutosizeDirective": () => (/* binding */ AutosizeDirective),
/* harmony export */   "AutosizeModule": () => (/* binding */ AutosizeModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);



class WindowRef {
  get nativeWindow() {
    return window;
  }

}

WindowRef.ɵfac = function WindowRef_Factory(t) {
  return new (t || WindowRef)();
};

WindowRef.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: WindowRef,
  factory: WindowRef.ɵfac
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](WindowRef, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable
  }], null, null);
})();

const MAX_LOOKUP_RETRIES = 3;

class AutosizeDirective {
  constructor(element, _window, _zone) {
    this.element = element;
    this._window = _window;
    this._zone = _zone;
    this.onlyGrow = false;
    this.useImportant = false;
    this.resized = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.autosize = true;
    this.retries = 0;
    this._destroyed = false;

    if (this.element.nativeElement.tagName !== 'TEXTAREA') {
      this._findNestedTextArea();
    } else {
      this.textAreaEl = this.element.nativeElement;
      this.textAreaEl.style['overflow-y'] = 'hidden';

      this._onTextAreaFound();
    }
  }

  set minRows(value) {
    this._minRows = +value;

    if (this.textAreaEl) {
      this.textAreaEl.rows = this._minRows;
    }
  }

  set _autosize(autosize) {
    this.autosize = typeof autosize === 'boolean' ? autosize : true;
  }

  onInput(textArea) {
    this.adjust();
  }

  ngOnDestroy() {
    this._destroyed = true;

    if (this._windowResizeHandler) {
      this._window.nativeWindow.removeEventListener('resize', this._windowResizeHandler, false);
    }
  }

  ngAfterContentChecked() {
    this.adjust();
  }

  ngOnChanges(changes) {
    this.adjust(true);
  }

  _findNestedTextArea() {
    this.textAreaEl = this.element.nativeElement.querySelector('TEXTAREA');

    if (!this.textAreaEl && this.element.nativeElement.shadowRoot) {
      this.textAreaEl = this.element.nativeElement.shadowRoot.querySelector('TEXTAREA');
    }

    if (!this.textAreaEl) {
      if (this.retries >= MAX_LOOKUP_RETRIES) {
        console.warn('ngx-autosize: textarea not found');
      } else {
        this.retries++;
        setTimeout(() => {
          this._findNestedTextArea();
        }, 100);
      }

      return;
    }

    this.textAreaEl.style['overflow-y'] = 'hidden';

    this._onTextAreaFound();
  }

  _onTextAreaFound() {
    this._addWindowResizeHandler();

    setTimeout(() => {
      this.adjust();
    });
  }

  _addWindowResizeHandler() {
    this._windowResizeHandler = debounce(() => {
      this._zone.run(() => {
        this.adjust();
      });
    }, 200);

    this._zone.runOutsideAngular(() => {
      this._window.nativeWindow.addEventListener('resize', this._windowResizeHandler, false);
    });
  }

  adjust(inputsChanged = false) {
    if (this.autosize && !this._destroyed && this.textAreaEl && this.textAreaEl.parentNode) {
      const currentText = this.textAreaEl.value;

      if (inputsChanged === false && currentText === this._oldContent && this.textAreaEl.offsetWidth === this._oldWidth) {
        return;
      }

      this._oldContent = currentText;
      this._oldWidth = this.textAreaEl.offsetWidth;
      const clone = this.textAreaEl.cloneNode(true);
      const parent = this.textAreaEl.parentNode;
      clone.style.width = this.textAreaEl.offsetWidth + 'px';
      clone.style.visibility = 'hidden';
      clone.style.position = 'absolute';
      clone.textContent = currentText;
      parent.appendChild(clone);
      clone.style['overflow-y'] = 'hidden';
      clone.style.height = 'auto';
      let height = clone.scrollHeight; // add into height top and bottom borders' width

      let computedStyle = this._window.nativeWindow.getComputedStyle(clone, null);

      height += parseInt(computedStyle.getPropertyValue('border-top-width'));
      height += parseInt(computedStyle.getPropertyValue('border-bottom-width')); // add into height top and bottom paddings width

      height += parseInt(computedStyle.getPropertyValue('padding-top'));
      height += parseInt(computedStyle.getPropertyValue('padding-bottom'));
      const oldHeight = this.textAreaEl.offsetHeight;
      const willGrow = height > oldHeight;

      if (this.onlyGrow === false || willGrow) {
        const lineHeight = this._getLineHeight();

        const rowsCount = height / lineHeight;

        if (this._minRows && this._minRows >= rowsCount) {
          height = this._minRows * lineHeight;
        } else if (this.maxRows && this.maxRows <= rowsCount) {
          // never shrink the textarea if onlyGrow is true
          const maxHeight = this.maxRows * lineHeight;
          height = this.onlyGrow ? Math.max(maxHeight, oldHeight) : maxHeight;
          this.textAreaEl.style['overflow-y'] = 'auto';
        } else {
          this.textAreaEl.style['overflow-y'] = 'hidden';
        }

        const heightStyle = height + 'px';
        const important = this.useImportant ? 'important' : '';
        this.textAreaEl.style.setProperty('height', heightStyle, important);
        this.resized.emit(height);
      }

      parent.removeChild(clone);
    }
  }

  _getLineHeight() {
    let lineHeight = parseInt(this.textAreaEl.style.lineHeight, 10);

    if (isNaN(lineHeight) && this._window.nativeWindow.getComputedStyle) {
      const styles = this._window.nativeWindow.getComputedStyle(this.textAreaEl);

      lineHeight = parseInt(styles.lineHeight, 10);
    }

    if (isNaN(lineHeight)) {
      const fontSize = this._window.nativeWindow.getComputedStyle(this.textAreaEl, null).getPropertyValue('font-size');

      lineHeight = Math.floor(parseInt(fontSize.replace('px', ''), 10) * 1.5);
    }

    return lineHeight;
  }

}

AutosizeDirective.ɵfac = function AutosizeDirective_Factory(t) {
  return new (t || AutosizeDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](WindowRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone));
};

AutosizeDirective.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: AutosizeDirective,
  selectors: [["", "autosize", ""]],
  hostBindings: function AutosizeDirective_HostBindings(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("input", function AutosizeDirective_input_HostBindingHandler($event) {
        return ctx.onInput($event.target);
      });
    }
  },
  inputs: {
    minRows: "minRows",
    _autosize: ["autosize", "_autosize"],
    maxRows: "maxRows",
    onlyGrow: "onlyGrow",
    useImportant: "useImportant"
  },
  outputs: {
    resized: "resized"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AutosizeDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[autosize]'
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: WindowRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone
    }];
  }, {
    minRows: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    _autosize: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
      args: ['autosize']
    }],
    maxRows: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    onlyGrow: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    useImportant: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    resized: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    onInput: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener,
      args: ['input', ['$event.target']]
    }]
  });
})();

function debounce(func, timeout) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      func(...args);
    }, timeout);
  };
}

class AutosizeModule {}

AutosizeModule.ɵfac = function AutosizeModule_Factory(t) {
  return new (t || AutosizeModule)();
};

AutosizeModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: AutosizeModule,
  declarations: [AutosizeDirective],
  exports: [AutosizeDirective]
});
AutosizeModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  providers: [WindowRef],
  imports: [[]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AutosizeModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      declarations: [AutosizeDirective],
      imports: [],
      providers: [WindowRef],
      exports: [AutosizeDirective]
    }]
  }], null, null);
})();
/*
 * Public API Surface of ngx-autosize
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ })

}]);
//# sourceMappingURL=src_app_chat_chat_module_ts.js.map