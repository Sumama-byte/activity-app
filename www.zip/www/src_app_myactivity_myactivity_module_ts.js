"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_myactivity_myactivity_module_ts"],{

/***/ 2162:
/*!*********************************************************!*\
  !*** ./src/app/myactivity/myactivity-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyactivityPageRoutingModule": () => (/* binding */ MyactivityPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _myactivity_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myactivity.page */ 8949);




const routes = [
    {
        path: '',
        component: _myactivity_page__WEBPACK_IMPORTED_MODULE_0__.MyactivityPage
    }
];
let MyactivityPageRoutingModule = class MyactivityPageRoutingModule {
};
MyactivityPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MyactivityPageRoutingModule);



/***/ }),

/***/ 5720:
/*!*************************************************!*\
  !*** ./src/app/myactivity/myactivity.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyactivityPageModule": () => (/* binding */ MyactivityPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _myactivity_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myactivity-routing.module */ 2162);
/* harmony import */ var _myactivity_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./myactivity.page */ 8949);







let MyactivityPageModule = class MyactivityPageModule {
};
MyactivityPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _myactivity_routing_module__WEBPACK_IMPORTED_MODULE_0__.MyactivityPageRoutingModule
        ],
        declarations: [_myactivity_page__WEBPACK_IMPORTED_MODULE_1__.MyactivityPage]
    })
], MyactivityPageModule);



/***/ }),

/***/ 8949:
/*!***********************************************!*\
  !*** ./src/app/myactivity/myactivity.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyactivityPage": () => (/* binding */ MyactivityPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _myactivity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myactivity.page.html?ngResource */ 4008);
/* harmony import */ var _myactivity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./myactivity.page.scss?ngResource */ 330);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/global.service */ 1307);







let MyactivityPage = class MyactivityPage {
    constructor(route, global, apicall) {
        this.route = route;
        this.global = global;
        this.apicall = apicall;
    }
    ngOnInit() {
        this.data = history.state.data;
        console.log(this.data);
    }
    //navigation
    nav_back() {
        this.route.navigate(['tabs/tab2']);
    }
};
MyactivityPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _Services_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService },
    { type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService }
];
MyactivityPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-myactivity',
        template: _myactivity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_myactivity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MyactivityPage);



/***/ }),

/***/ 330:
/*!************************************************************!*\
  !*** ./src/app/myactivity/myactivity.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = ".back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  height: 33px;\n  width: 33px;\n}\n\n.txt {\n  font-size: 18px;\n  margin: auto;\n}\n\n.image {\n  width: 100%;\n  height: 230px;\n  margin: 30px auto 0px auto;\n  box-shadow: 2px 2px 37px rgba(0, 0, 0, 0.215);\n}\n\n.algin_left {\n  display: flex;\n}\n\n.div2 {\n  width: 90%;\n  margin-left: auto;\n  margin-right: auto;\n}\n\n.div2 .para {\n  margin-left: auto;\n  margin-right: auto;\n  font-size: small;\n}\n\n.div2 .div3 {\n  font-size: smaller;\n  font-weight: bold;\n  padding: 0;\n}\n\n.div2 .coltime {\n  display: flex;\n}\n\n.div2 .div4 {\n  display: flex;\n  width: 37px;\n  height: 46px;\n  background-color: #F2910C;\n  color: white;\n  border-radius: 8px;\n  font-size: 21px;\n  font-weight: bolder;\n  background-image: url('div_ouline.png');\n  justify-content: center;\n  align-items: center;\n  margin: 8px;\n}\n\nion-button {\n  --background: #F2910C;\n  --border-radius: 100px;\n  height: 60px;\n  width: 150px;\n  padding-top: 20px;\n  color: white;\n  text-transform: none;\n  margin: 0px auto 25px auto;\n}\n\n.fs-0 {\n  width: 100%;\n  font-size: 12px;\n}\n\n.col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n}\n\nion-item {\n  --background: transparent;\n}\n\n.center {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15YWN0aXZpdHkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksbUJBQUE7RUFDQSxzQ0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FBQUo7O0FBRUE7RUFDSSxlQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUNBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSwwQkFBQTtFQUNBLDZDQUFBO0FBRUo7O0FBQ0k7RUFDSSxhQUFBO0FBRVI7O0FBQUE7RUFDSSxVQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQUdKOztBQURJO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBR1I7O0FBREk7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsVUFBQTtBQUdSOztBQURFO0VBQ0UsYUFBQTtBQUdKOztBQURNO0VBQ0MsYUFBQTtFQUdFLFdBQUE7RUFDRCxZQUFBO0VBRUEseUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFHQSx1Q0FBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FBRlI7O0FBU0E7RUFDSSxxQkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtFQUNBLDBCQUFBO0FBTko7O0FBU0E7RUFDSSxXQUFBO0VBQ0EsZUFBQTtBQU5KOztBQVFBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQUxKOztBQU9BO0VBQ0kseUJBQUE7QUFKSjs7QUFNQTtFQUNJLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0FBSEoiLCJmaWxlIjoibXlhY3Rpdml0eS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgXHJcbi5iYWNrLWJ1dHRvbntcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICBib3gtc2hhZG93OiAycHggM3B4IDVweCA1cHggd2hpdGVzbW9rZTtcclxuICAgIGhlaWdodDogMzNweDtcclxuICAgIHdpZHRoOiAzM3B4O1xyXG59XHJcbi50eHR7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbn1cclxuLmltYWdle1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDIzMHB4O1xyXG4gICAgbWFyZ2luOiAzMHB4IGF1dG8gMHB4IGF1dG87XHJcbiAgICBib3gtc2hhZG93OiAycHggMnB4IDM3cHggcmdiYSgwLCAwLCAwLCAwLjIxNSk7XHJcbn1cclxuXHJcbiAgICAuYWxnaW5fbGVmdHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgfVxyXG4uZGl2MntcclxuICAgIHdpZHRoOiA5MCU7ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgXHJcbiAgICAucGFyYXtcclxuICAgICAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgICAgICAgZm9udC1zaXplOiBzbWFsbDtcclxuICAgIH1cclxuICAgIC5kaXYze1xyXG4gICAgICAgIGZvbnQtc2l6ZTogc21hbGxlcjtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgfVxyXG4gIC5jb2x0aW1le1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICB9XHJcbiAgICAgIC5kaXY0e1xyXG4gICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAvLyB3aWR0aDogMzdweDtcclxuICAgICAgICAvLyBoZWlnaHQ6IDQzcHg7XHJcbiAgICAgICAgIHdpZHRoOiAzN3B4O1xyXG4gICAgICAgIGhlaWdodDogNDZweDtcclxuICAgICAgXHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0YyOTEwQztcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjFweDtcclxuICAgICAgICBmb250LXdlaWdodDogYm9sZGVyO1xyXG4gICAgICAgIC8vIGJhY2tncm91bmQtaW1hZ2U6IHVybChcImRhdGE6aW1hZ2Uvc3ZnK3htbCwlM2Nzdmcgd2lkdGg9JzEwMCUyNScgaGVpZ2h0PScxMDAlMjUnIHhtbG5zPSdodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyclM2UlM2NyZWN0IHdpZHRoPScxMDAlMjUnIGhlaWdodD0nMTAwJTI1JyBmaWxsPSdub25lJyByeD0nMTAnIHJ5PScxMCcgc3Ryb2tlPSdibGFjaycgc3Ryb2tlLXdpZHRoPSc2JyBzdHJva2UtZGFzaGFycmF5PScxMDAlMmM0NScgc3Ryb2tlLWRhc2hvZmZzZXQ9JzkyJyBzdHJva2UtbGluZWNhcD0nc3F1YXJlJy8lM2UlM2Mvc3ZnJTNlXCIpO1xyXG4gICAgICAgIC8vIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4vLi4vLi4vYXNzZXRzL2Rpdl9vdWxpbmUucG5nKTtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgIG1hcmdpbjogOHB4O1xyXG4gICAgfVxyXG5cclxuICAgICAgICBcclxuICAgICAgICBcclxuICAgIFxyXG59XHJcbmlvbi1idXR0b24ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjRjI5MTBDO1xyXG4gICAgLS1ib3JkZXItcmFkaXVzOiAxMDBweDtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIHBhZGRpbmctdG9wOiAyMHB4O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbiAgICBtYXJnaW46MHB4IGF1dG8gMjVweCBhdXRvO1xyXG59XHJcblxyXG4uZnMtMHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcbi5jb2x7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5pb24taXRlbXtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbn1cclxuLmNlbnRlcntcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbn0iXX0= */";

/***/ }),

/***/ 4008:
/*!************************************************************!*\
  !*** ./src/app/myactivity/myactivity.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\n  <ion-item lines=\"none\" class=\"ion-text-center\">\n\n    <div slot=\"start\" class=\"back-button\" (click)=\"nav_back()\">\n      <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\n    </div>\n    <!-- Activtiy title -->\n    <p class=\"txt\">{{data.activity_name}}</p>\n\n    <ion-icon slot=\"end\" name=\"heart-outline\"></ion-icon>\n  </ion-item>\n</ion-header>\n\n<ion-content>\n\n  <ion-row>\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"col\">\n      <!-- location image  -->\n       \n        <img class=\"image\" src=\"{{data.a_image}}\" alt=\"\">\n \n\n      <ion-item lines=\"none\" class=\"fs-0\">\n        <div slot=\"start\" class=\"algin_left\">\n\n          <ion-icon name=\"location-outline\" size=\"large\"></ion-icon>\n\n          <!-- activity location -->\n          <p> {{data.location}}</p>\n\n        </div>\n        <!-- Avtivity range -->\n        <div slot=\"end\">\n          <p> Within {{data.social_range}} Km</p>\n        </div>\n      </ion-item>\n\n\n    </ion-col>\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"center\">\n\n      <div class=\"div2\">\n        <!-- activity description -->\n        <p class=\"para\">\n          {{data.description}}\n        </p>\n        <!-- attendies title -->\n        <p><b>Number Of Atendees Allowed</b></p>\n        <!-- canidaties nunber -->\n        <h5><b>{{data.max_atendes}} </b></h5>\n        <ion-row>\n          <ion-col size=\"6\" class=\"div3\">Start Time</ion-col>\n          <ion-col size=\"6\" class=\"div3\">End Time</ion-col>\n        </ion-row>\n        <ion-row>\n\n          <!-- Activity Start time  -->\n          <ion-col size=\"6\" class=\"coltime\">\n            <div class=\"div4\">\n                {{data.start_time}}\n            </div>\n            <div class=\"div4\">00</div>\n          </ion-col>\n          <!-- Activity end time  -->\n          <ion-col size=\"6\" class=\"coltime\">\n            <div class=\"div4\">{{data.end_time}}</div>\n            <div class=\"div4\">00</div>\n          </ion-col>\n        </ion-row>\n      </div>\n\n    </ion-col>\n  </ion-row>\n\n\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_myactivity_myactivity_module_ts.js.map