"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_mapmodal_mapmodal_module_ts"],{

/***/ 1419:
/*!******************************************!*\
  !*** ./src/app/Services/gmap.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GmapsService": () => (/* binding */ GmapsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);



let GmapsService = class GmapsService {
  constructor() {}

  loadGoogleMaps() {
    const win = window;
    const gModule = win.google;

    if (gModule && gModule.maps) {
      return Promise.resolve(gModule.maps);
    }

    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://maps.googleapis.com/maps/api/js?key=' + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.mapsKey;
      script.async = true;
      script.defer = true;
      document.body.appendChild(script);

      script.onload = () => {
        const loadedGoogleModule = win.google;

        if (loadedGoogleModule && loadedGoogleModule.maps) {
          resolve(loadedGoogleModule.maps);
        } else {
          reject('Google Map SDK is not Available');
        }
      };
    });
  }

};

GmapsService.ctorParameters = () => [];

GmapsService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
  providedIn: 'root'
})], GmapsService);


/***/ }),

/***/ 263:
/*!***********************************************************!*\
  !*** ./src/app/pages/mapmodal/mapmodal-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MapmodalPageRoutingModule": () => (/* binding */ MapmodalPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _mapmodal_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mapmodal.page */ 8430);




const routes = [
    {
        path: '',
        component: _mapmodal_page__WEBPACK_IMPORTED_MODULE_0__.MapmodalPage
    }
];
let MapmodalPageRoutingModule = class MapmodalPageRoutingModule {
};
MapmodalPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MapmodalPageRoutingModule);



/***/ }),

/***/ 1923:
/*!***************************************************!*\
  !*** ./src/app/pages/mapmodal/mapmodal.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MapmodalPageModule": () => (/* binding */ MapmodalPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _mapmodal_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mapmodal-routing.module */ 263);
/* harmony import */ var _mapmodal_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mapmodal.page */ 8430);







let MapmodalPageModule = class MapmodalPageModule {
};
MapmodalPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _mapmodal_routing_module__WEBPACK_IMPORTED_MODULE_0__.MapmodalPageRoutingModule
        ],
        declarations: [_mapmodal_page__WEBPACK_IMPORTED_MODULE_1__.MapmodalPage]
    })
], MapmodalPageModule);



/***/ }),

/***/ 8430:
/*!*************************************************!*\
  !*** ./src/app/pages/mapmodal/mapmodal.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MapmodalPage": () => (/* binding */ MapmodalPage)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _mapmodal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mapmodal.page.html?ngResource */ 5820);
/* harmony import */ var _mapmodal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mapmodal.page.scss?ngResource */ 386);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_app_Services_gmap_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/Services/gmap.service */ 1419);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);









let MapmodalPage = class MapmodalPage {
  constructor(gmaps, renderer, actionSheetCtrl, modalCtrl) {
    this.gmaps = gmaps;
    this.renderer = renderer;
    this.actionSheetCtrl = actionSheetCtrl;
    this.modalCtrl = modalCtrl;
    this.center = {
      lat: '',
      lng: ''
    };
    this.markers = [];
    this.location = {
      lat: '',
      lng: ''
    };
  }

  ngOnInit() {}

  ngAfterViewInit() {
    this.loadMap();
  }

  loadMap() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const coordinates = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();

      try {
        let googleMaps = yield _this.gmaps.loadGoogleMaps();
        _this.googleMaps = googleMaps;
        const mapEl = _this.mapElementRef.nativeElement;
        const location = new googleMaps.LatLng(coordinates.coords.latitude, coordinates.coords.longitude);
        _this.map = new googleMaps.Map(mapEl, {
          center: location,
          zoom: 16
        });

        _this.renderer.addClass(mapEl, 'visible'); // this.addMarker(location);


        _this.onMapClick();
      } catch (e) {
        console.log(e);
      }
    })();
  }

  onMapClick() {
    this.mapClickListener = this.googleMaps.event.addListener(this.map, "click", mapsMouseEvent => {
      console.log(mapsMouseEvent.latLng.toJSON());
      this.addMarker(mapsMouseEvent.latLng); // this.checkAndRemoveMarker(x)

      for (var i = 0; i < this.markers.length; i++) {
        this.markers[i].setMap(this.map);
      }
    });
  }

  addMarker(location) {
    let googleMaps = this.googleMaps;
    const icon = {
      url: 'assets/location-outline.svg',
      scaledSize: new googleMaps.Size(50, 50)
    };
    const marker = new googleMaps.Marker({
      position: location,
      map: this.map,
      icon: icon // draggable: true,
      // animation: googleMaps.Animation.DROP

    });
    this.markers.push(marker);
    console.log(marker.position.lat());
    console.log(marker.position.lng());
    this.location.lat = marker.position.lat();
    this.location.lng = marker.position.lng();
    this.markerClickListener = this.googleMaps.event.addListener(marker, 'click', () => {
      console.log('markerclick', marker); // this.checkAndRemoveMarker(marker);

      console.log('markers: ', this.markers);
    });
    return marker;
  }

  setLocation() {
    this.cancel();
  }

  cancel() {
    return this.modalCtrl.dismiss(this.location, 'cancel');
  }

  confirm() {
    return this.modalCtrl.dismiss(this.location, 'confirm');
  }

};

MapmodalPage.ctorParameters = () => [{
  type: src_app_Services_gmap_service__WEBPACK_IMPORTED_MODULE_3__.GmapsService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Renderer2
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController
}];

MapmodalPage.propDecorators = {
  Data: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input
  }],
  mapElementRef: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild,
    args: ['map', {
      static: true
    }]
  }]
};
MapmodalPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-mapmodal',
  template: _mapmodal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_mapmodal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MapmodalPage);


/***/ }),

/***/ 591:
/*!*********************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/definitions.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 7621:
/*!***************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Geolocation": () => (/* binding */ Geolocation)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 591);

const Geolocation = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Geolocation', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_geolocation_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 8391)).then(m => new m.GeolocationWeb())
});



/***/ }),

/***/ 386:
/*!**************************************************************!*\
  !*** ./src/app/pages/mapmodal/mapmodal.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "ion-toolbar {\n  --background: #F39200;\n  color: white;\n}\n\nion-header {\n  color: white;\n}\n\n#map {\n  width: 100%;\n  height: 480px;\n}\n\nion-button {\n  margin-top: 20px;\n  color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1hcG1vZGFsLnBhZ2Uuc2NzcyIsIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxGaXZlciUyME9yZGVyc1xcQWN0aXZpdHlcXGFjdGl2aXR5LWFwcFxcc3JjXFxhcHBcXHBhZ2VzXFxtYXBtb2RhbFxcbWFwbW9kYWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFDO0VBQ08scUJBQUE7RUFDQSxZQUFBO0FDQ1I7O0FEQ0E7RUFDSSxZQUFBO0FDRUo7O0FEQUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtBQ0dKOztBRERBO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0FDSUoiLCJmaWxlIjoibWFwbW9kYWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiIGlvbi10b29sYmFyIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6ICNGMzkyMDA7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG59XHJcbmlvbi1oZWFkZXIge1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG59XHJcbiNtYXAge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDQ4MHB4O1xyXG59XHJcbmlvbi1idXR0b24ge1xyXG4gICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxufSIsImlvbi10b29sYmFyIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRjM5MjAwO1xuICBjb2xvcjogd2hpdGU7XG59XG5cbmlvbi1oZWFkZXIge1xuICBjb2xvcjogd2hpdGU7XG59XG5cbiNtYXAge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA0ODBweDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn0iXX0= */";

/***/ }),

/***/ 5820:
/*!**************************************************************!*\
  !*** ./src/app/pages/mapmodal/mapmodal.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar style=\"background-color: var(--ion-background-color);\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"cancel()\">Cancel</ion-button>\n    </ion-buttons>\n    <ion-title>Select Location</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"confirm()\" [strong]=\"true\">Confirm</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"ion-padding\" style=\"--ion-background-color:none;\">\n  <div id=\"map\" #map></div>\n  <ion-button mode=\"ios\" expand=\"block\" color=\"primary\" style=\"--color:white;\" (click)=\"setLocation()\">Select Location</ion-button>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_mapmodal_mapmodal_module_ts.js.map