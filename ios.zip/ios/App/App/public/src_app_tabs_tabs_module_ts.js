"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tabs_tabs_module_ts"],{

/***/ 530:
/*!*********************************************!*\
  !*** ./src/app/tabs/tabs-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageRoutingModule": () => (/* binding */ TabsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs.page */ 7942);




const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_0__.TabsPage,
        children: [
            {
                path: 'tab1',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_capacitor_core_dist_index_js"), __webpack_require__.e("common"), __webpack_require__.e("src_app_tab1_tab1_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../tab1/tab1.module */ 2168)).then(m => m.Tab1PageModule)
            },
            {
                path: 'tab2',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_tab2_tab2_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../tab2/tab2.module */ 4608)).then(m => m.Tab2PageModule)
            },
            {
                path: 'tab3',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_tab3_tab3_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../tab3/tab3.module */ 3746)).then(m => m.Tab3PageModule)
            },
            {
                path: 'tab4',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab4_tab4_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../tab4/tab4.module */ 2486)).then(m => m.Tab4PageModule)
            },
            {
                path: 'tab5',
                loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_tab5_tab5_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../tab5/tab5.module */ 5184)).then(m => m.Tab5PageModule)
            },
            {
                path: 'profile',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_capacitor_core_dist_index_js"), __webpack_require__.e("default-src_app_profile_profile_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../profile/profile.module */ 4523)).then(m => m.ProfilePageModule)
            },
            {
                path: 'notification',
                loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_notification_notification_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../notification/notification.module */ 2154)).then(m => m.NotificationPageModule)
            },
            {
                path: 'create-activity',
                loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-node_modules_capacitor_core_dist_index_js"), __webpack_require__.e("default-src_app_create-activity_create-activity_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ../create-activity/create-activity.module */ 9785)).then(m => m.CreateActivityPageModule)
            },
            {
                path: 'activity-details',
                loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_activity-details_activity-details_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../activity-details/activity-details.module */ 5550)).then(m => m.ActivityDetailsPageModule)
            },
            {
                path: 'canidates',
                loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_canidates_canidates_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../canidates/canidates.module */ 6947)).then(m => m.CanidatesPageModule)
            },
            {
                path: 'filter',
                loadChildren: () => __webpack_require__.e(/*! import() */ "common").then(__webpack_require__.bind(__webpack_require__, /*! ../filter/filter.module */ 7655)).then(m => m.FilterPageModule)
            },
            {
                path: 'myactivity',
                loadChildren: () => __webpack_require__.e(/*! import() */ "default-src_app_myactivity_myactivity_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ../myactivity/myactivity.module */ 5720)).then(m => m.MyactivityPageModule)
            },
            {
                path: '',
                redirectTo: '/tabs/tab1',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ 5564:
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPageModule": () => (/* binding */ TabsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tabs-routing.module */ 530);
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page */ 7942);







let TabsPageModule = class TabsPageModule {
};
TabsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_0__.TabsPageRoutingModule
        ],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_1__.TabsPage]
    })
], TabsPageModule);



/***/ }),

/***/ 7942:
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TabsPage": () => (/* binding */ TabsPage)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tabs.page.html?ngResource */ 5230);
/* harmony import */ var _tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tabs.page.scss?ngResource */ 4710);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);








let TabsPage = class TabsPage {
  constructor(route, apicall, global) {
    this.route = route;
    this.apicall = apicall;
    this.global = global;
    this.YourActivity = {
      u_id: ''
    };
  }

  nav() {
    this.route.navigate(['/tabs/create-activity']);
    this.getDataactivity();
  }

  getDataactivity() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.global.Uid.subscribe(uid => {
        _this.YourActivity.u_id = uid;
      });
      yield _this.apicall.api_getActivity(_this.YourActivity.u_id);
      yield _this.apicall.api_myparticipantActivity(_this.YourActivity.u_id);
      yield _this.apicall.api_getallActivitybylocation();
      yield _this.apicall.api_getallfilterActivity(); //  await this.apicall.api_getpeopleForChat();
    })();
  }

};

TabsPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}];

TabsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-tabs',
  template: _tabs_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tabs_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], TabsPage);


/***/ }),

/***/ 4710:
/*!************************************************!*\
  !*** ./src/app/tabs/tabs.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-tabs ion-button {\n  width: 70px;\n  height: 70px;\n  margin: -35px auto;\n  display: flex;\n  z-index: 12;\n  --border-color: #fff;\n  --border-radius: 100%;\n  --border-style: solid;\n  --border-width: 5px;\n  --box-shadow: none;\n  --ripple-color:none;\n  --background-activated:#454545;\n  --background-activated-opacity: 1;\n}\nion-tabs ion-button ion-icon {\n  color: #fff;\n}\nion-tabs ion-tab-bar {\n  box-shadow: 10px -1px 20px rgba(0, 0, 0, 0.14);\n}\nion-tabs ion-tab-bar ion-tab-button {\n  --ripple-color:#fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYnMucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcRml2ZXIlMjBPcmRlcnNcXEFjdGl2aXR5XFxhY3Rpdml0eS1hcHBcXHNyY1xcYXBwXFx0YWJzXFx0YWJzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsaUNBQUE7QUNBUjtBRENRO0VBQ0ksV0FBQTtBQ0NaO0FERUk7RUFDSSw4Q0FBQTtBQ0FSO0FEQ1E7RUFDSSxtQkFBQTtBQ0NaIiwiZmlsZSI6InRhYnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRhYnMge1xyXG4gICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgd2lkdGg6IDcwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiA3MHB4O1xyXG4gICAgICAgIG1hcmdpbjogLTM1cHggYXV0bztcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIHotaW5kZXg6IDEyO1xyXG4gICAgICAgIC0tYm9yZGVyLWNvbG9yOiAjZmZmO1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgICAgICAtLWJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICAgICAgLS1ib3JkZXItd2lkdGg6IDVweDtcclxuICAgICAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgLS1yaXBwbGUtY29sb3I6bm9uZTtcclxuICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOiM0NTQ1NDU7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZC1vcGFjaXR5OiAxO1xyXG4gICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgY29sb3I6ICNmZmY7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgaW9uLXRhYi1iYXIge1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDEwcHggLTFweCAyMHB4IHJnYigwIDAgMCAvIDE0JSk7XHJcbiAgICAgICAgaW9uLXRhYi1idXR0b257XHJcbiAgICAgICAgICAgIC0tcmlwcGxlLWNvbG9yOiNmZmY7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiIsImlvbi10YWJzIGlvbi1idXR0b24ge1xuICB3aWR0aDogNzBweDtcbiAgaGVpZ2h0OiA3MHB4O1xuICBtYXJnaW46IC0zNXB4IGF1dG87XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHotaW5kZXg6IDEyO1xuICAtLWJvcmRlci1jb2xvcjogI2ZmZjtcbiAgLS1ib3JkZXItcmFkaXVzOiAxMDAlO1xuICAtLWJvcmRlci1zdHlsZTogc29saWQ7XG4gIC0tYm9yZGVyLXdpZHRoOiA1cHg7XG4gIC0tYm94LXNoYWRvdzogbm9uZTtcbiAgLS1yaXBwbGUtY29sb3I6bm9uZTtcbiAgLS1iYWNrZ3JvdW5kLWFjdGl2YXRlZDojNDU0NTQ1O1xuICAtLWJhY2tncm91bmQtYWN0aXZhdGVkLW9wYWNpdHk6IDE7XG59XG5pb24tdGFicyBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6ICNmZmY7XG59XG5pb24tdGFicyBpb24tdGFiLWJhciB7XG4gIGJveC1zaGFkb3c6IDEwcHggLTFweCAyMHB4IHJnYmEoMCwgMCwgMCwgMC4xNCk7XG59XG5pb24tdGFicyBpb24tdGFiLWJhciBpb24tdGFiLWJ1dHRvbiB7XG4gIC0tcmlwcGxlLWNvbG9yOiNmZmY7XG59Il19 */";

/***/ }),

/***/ 5230:
/*!************************************************!*\
  !*** ./src/app/tabs/tabs.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-tabs>\r\n  \r\n  <ion-button (click)=\"nav()\">\r\n    <ion-icon name=\"flash\"></ion-icon>\r\n  </ion-button>\r\n\r\n  <ion-tab-bar slot=\"bottom\" (click)=\"getDataactivity()\">\r\n    <ion-tab-button tab=\"tab1\">\r\n      <ion-icon name=\"home-outline\"></ion-icon> \r\n      <ion-label>Home</ion-label>   \r\n    </ion-tab-button>\r\n\r\n    <ion-tab-button tab=\"tab2\" (click)=\"getDataactivity()\">\r\n      <ion-icon name=\"calendar-clear-outline\"></ion-icon>\r\n      <ion-label>Activities</ion-label>  \r\n    </ion-tab-button>\r\n\r\n    <ion-tab-button></ion-tab-button>\r\n\r\n    <ion-tab-button tab=\"tab3\" (click)=\"getDataactivity()\">\r\n      <ion-icon name=\"search-outline\"></ion-icon>\r\n      <ion-label>Search</ion-label>\r\n    </ion-tab-button>\r\n    \r\n    \r\n    <ion-tab-button tab=\"tab4\" (click)=\"getDataactivity()\">\r\n      <ion-icon name=\"chatbubble-ellipses-outline\"></ion-icon>\r\n      <ion-label>Chats</ion-label>\r\n    </ion-tab-button>\r\n  </ion-tab-bar>\r\n\r\n</ion-tabs>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tabs_tabs_module_ts.js.map