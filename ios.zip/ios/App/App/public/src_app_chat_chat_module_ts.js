"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_chat_chat_module_ts"],{

/***/ 4761:
/*!*********************************************!*\
  !*** ./src/app/chat/chat-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChatPageRoutingModule": () => (/* binding */ ChatPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _chat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chat.page */ 4099);




const routes = [
    {
        path: '',
        component: _chat_page__WEBPACK_IMPORTED_MODULE_0__.ChatPage
    }
];
let ChatPageRoutingModule = class ChatPageRoutingModule {
};
ChatPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ChatPageRoutingModule);



/***/ }),

/***/ 4709:
/*!*************************************!*\
  !*** ./src/app/chat/chat.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChatPageModule": () => (/* binding */ ChatPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _chat_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./chat-routing.module */ 4761);
/* harmony import */ var _chat_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chat.page */ 4099);
/* harmony import */ var ngx_autosize__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-autosize */ 327);








let ChatPageModule = class ChatPageModule {
};
ChatPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _chat_routing_module__WEBPACK_IMPORTED_MODULE_0__.ChatPageRoutingModule,
            ngx_autosize__WEBPACK_IMPORTED_MODULE_7__.AutosizeModule
        ],
        declarations: [_chat_page__WEBPACK_IMPORTED_MODULE_1__.ChatPage]
    })
], ChatPageModule);



/***/ }),

/***/ 4099:
/*!***********************************!*\
  !*** ./src/app/chat/chat.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ChatPage": () => (/* binding */ ChatPage)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _chat_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./chat.page.html?ngResource */ 9910);
/* harmony import */ var _chat_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chat.page.scss?ngResource */ 6232);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 3491);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);










let ChatPage = class ChatPage {
  constructor(route, global, apiCall) {
    this.route = route;
    this.global = global;
    this.apiCall = apiCall;
    this.messages = [];
    this.currentUser = 'Rehan';
    this.newMsg = {
      incoming_key: '',
      outgoing_key: '',
      msg: ''
    };
    this.other = '';
    this.userData = {
      name: '',
      img: ''
    };
    this.keys = {
      incoming_key: '',
      outgoing_key: ''
    };
    this.counter = (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.interval)(60000); // sets 60 seconds interval

    this.subscription = null;
  }

  ngOnInit() {
    // this.sendMessage();
    this.chat = history.state.data;
    this.userData.img = this.chat.img;
    this.userData.name = this.chat.name;
    this.keys.incoming_key = this.chat.u_id;
    this.newMsg.incoming_key = this.chat.u_id;
    this.global.Uid.subscribe(u_id => {
      this.other = u_id;
      this.keys.outgoing_key = u_id;
      this.newMsg.outgoing_key = u_id;
    });
    this.getChat();
    setTimeout(() => {
      this.content.scrollToBottom(200);
    }, 100);
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.content.scrollToBottom(200);
    }, 300);
    this.getChat();
  }

  getChat() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.apiCall.api_getChat(_this.keys);
      yield _this.global.Chat.subscribe(res => {
        _this.messages = res;
        _this.chat = res;
        console.log(_this.chat);
      });
    })();
  }

  sendMessage() {
    var _this2 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.apiCall.api_postChat(_this2.newMsg);

      _this2.getChat();

      _this2.newMsg.msg = '';
      setTimeout(() => {
        _this2.content.scrollToBottom(200); // this.getChat();

      });
    })();
  }

  go_back() {
    this.route.navigate(['/tabs/tab4']);
  }

  ngOnDestroy() {
    console.log('Destroy');
    this.getChat();
  }

};

ChatPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

ChatPage.propDecorators = {
  content: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.ViewChild,
    args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonContent]
  }]
};
ChatPage = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-chat',
  template: _chat_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_chat_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ChatPage);


/***/ }),

/***/ 3491:
/*!********************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/interval.js ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "interval": () => (/* binding */ interval)
/* harmony export */ });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Observable */ 2378);
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../scheduler/async */ 328);
/* harmony import */ var _util_isNumeric__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/isNumeric */ 7269);



function interval(period = 0, scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_0__.async) {
  if (!(0,_util_isNumeric__WEBPACK_IMPORTED_MODULE_1__.isNumeric)(period) || period < 0) {
    period = 0;
  }

  if (!scheduler || typeof scheduler.schedule !== 'function') {
    scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_0__.async;
  }

  return new _Observable__WEBPACK_IMPORTED_MODULE_2__.Observable(subscriber => {
    subscriber.add(scheduler.schedule(dispatch, period, {
      subscriber,
      counter: 0,
      period
    }));
    return subscriber;
  });
}

function dispatch(state) {
  const {
    subscriber,
    counter,
    period
  } = state;
  subscriber.next(counter);
  this.schedule({
    subscriber,
    counter: counter + 1,
    period
  }, period);
}

/***/ }),

/***/ 6232:
/*!************************************************!*\
  !*** ./src/app/chat/chat.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  height: 91%;\n}\n\nion-list {\n  box-shadow: 2px 2px 14px rgba(0, 0, 0, 0.225);\n}\n\nion-label {\n  margin-left: 10px;\n}\n\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  height: 33px;\n  width: 33px;\n}\n\nion-grid img {\n  border-radius: 100%;\n  height: 100%;\n  width: 100%;\n}\n\nion-grid .time {\n  opacity: 0.7;\n  font-size: 8px;\n}\n\nion-grid .message {\n  padding: 10px;\n  margin: 20px;\n  white-space: pre-wrap;\n}\n\nion-grid .other-message {\n  border-radius: 0px 16px 16px 16px;\n  background: var(--ion-color-primary);\n  color: #fff;\n}\n\nion-grid .my-message {\n  border-radius: 16px 0px 16px 16px;\n  box-shadow: 2px 2px 17px rgba(0, 0, 0, 0.225);\n  background: none;\n  color: rgb(0, 0, 0);\n}\n\nion-grid .my_img {\n  width: 26px;\n  height: 26px;\n  border-radius: 100%;\n  position: absolute;\n  right: 0;\n  top: 107%;\n}\n\nion-grid .other_img {\n  width: 26px;\n  height: 26px;\n  border-radius: 100%;\n  position: absolute;\n  left: -15px;\n  top: 107%;\n}\n\nion-grid .userimage {\n  height: 100%;\n  width: 100%;\n}\n\nion-grid .time {\n  color: #dfdfdf;\n  float: right;\n  font-size: small;\n}\n\n.msg-area {\n  width: 100%;\n  border: 1px solid #F39200;\n  background: #fff;\n  margin-left: 61px;\n  border-radius: 100px;\n  font-size: 22px;\n  padding: 6px;\n  padding-left: 14px;\n  resize: none;\n  height: 59px;\n  margin-top: 10px;\n}\n\n.ion-icon {\n  font-size: 20px;\n}\n\n::placeholder {\n  padding-top: 10px;\n}\n\n.p-1 {\n  padding: 0px 0px 13px 13px;\n  --background: transparent;\n}\n\nion-fab-button {\n  --background-foucsed: none;\n  --background-hover: none;\n}\n\nion-footer ion-toolbar {\n  --background: #fff;\n}\n\n.message-input {\n  border: 1px solid var(--ion-color-primary);\n  border-radius: 50px;\n  background: white;\n}\n\n.msg-btn {\n  --padding-start: 0.5em;\n  --padding-end: 0.5em;\n}\n\n.msg-btn ion-icon {\n  font-size: 25px;\n}\n\nion-textarea {\n  --padding-start: 20px;\n  --padding-top: 4px;\n  --padding-bottom: 4px;\n  min-height: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNoYXQucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcRml2ZXIlMjBPcmRlcnNcXEFjdGl2aXR5XFxhY3Rpdml0eS1hcHBcXHNyY1xcYXBwXFxjaGF0XFxjaGF0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7QUNDSjs7QURDQTtFQUNJLDZDQUFBO0FDRUo7O0FEQ0E7RUFDSSxpQkFBQTtBQ0VKOztBRENBO0VBQ0ksbUJBQUE7RUFDQSxzQ0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDRUo7O0FEQ0E7RUFDSSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0FDRUo7O0FEQ0E7RUFFSSxZQUFBO0VBQ0EsY0FBQTtBQ0FKOztBREdBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSxxQkFBQTtBQ0RKOztBRElBO0VBQ0ksaUNBQUE7RUFDQSxvQ0FBQTtFQUNBLFdBQUE7QUNGSjs7QURLQTtFQUNJLGlDQUFBO0VBQ0EsNkNBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FDSEo7O0FETUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtBQ0pKOztBRE9BO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7QUNMSjs7QURRQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0FDTko7O0FEU0E7RUFDSSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FDUEo7O0FEVUM7RUFDRyxXQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQ1BKOztBRGtCQTtFQUNJLGVBQUE7QUNmSjs7QURpQkE7RUFDSSxpQkFBQTtBQ2RKOztBRG9CQTtFQUNJLDBCQUFBO0VBQ0EseUJBQUE7QUNqQko7O0FEb0JBO0VBQ0ksMEJBQUE7RUFDQSx3QkFBQTtBQ2pCSjs7QURzQkk7RUFDSSxrQkFBQTtBQ25CUjs7QUR3QkE7RUFFSSwwQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUN0Qko7O0FEMEJFO0VBQ0Usc0JBQUE7RUFDQSxvQkFBQTtBQ3ZCSjs7QUR3Qkk7RUFDSSxlQUFBO0FDdEJSOztBRDBCRTtFQUNFLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0FDdkJKIiwiZmlsZSI6ImNoYXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gICAgaGVpZ2h0OiA5MSU7XHJcbn1cclxuaW9uLWxpc3Qge1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDJweCAxNHB4IHJnYmEoMCwgMCwgMCwgMC4yMjUpXHJcbn1cclxuXHJcbmlvbi1sYWJlbCB7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxufVxyXG5cclxuLmJhY2stYnV0dG9uIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICBib3gtc2hhZG93OiAycHggM3B4IDVweCA1cHggd2hpdGVzbW9rZTtcclxuICAgIGhlaWdodDogMzNweDtcclxuICAgIHdpZHRoOiAzM3B4O1xyXG59XHJcbmlvbi1ncmlkIHtcclxuaW1nIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLnRpbWUge1xyXG5cclxuICAgIG9wYWNpdHk6IDAuNztcclxuICAgIGZvbnQtc2l6ZTogOHB4O1xyXG59XHJcblxyXG4ubWVzc2FnZSB7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgbWFyZ2luOiAyMHB4O1xyXG4gICAgd2hpdGUtc3BhY2U6IHByZS13cmFwO1xyXG59XHJcblxyXG4ub3RoZXItbWVzc2FnZSB7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHggMTZweCAxNnB4IDE2cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufVxyXG5cclxuLm15LW1lc3NhZ2Uge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTZweCAwcHggMTZweCAxNnB4O1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDJweCAxN3B4IHJnYmEoMCwgMCwgMCwgMC4yMjUpO1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIGNvbG9yOiByZ2IoMCwgMCwgMCk7XHJcbn1cclxuXHJcbi5teV9pbWcge1xyXG4gICAgd2lkdGg6IDI2cHg7XHJcbiAgICBoZWlnaHQ6IDI2cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDEwNyU7XHJcbn1cclxuXHJcbi5vdGhlcl9pbWcge1xyXG4gICAgd2lkdGg6IDI2cHg7XHJcbiAgICBoZWlnaHQ6IDI2cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogLTE1cHg7XHJcbiAgICB0b3A6IDEwNyU7XHJcbn1cclxuXHJcbi51c2VyaW1hZ2V7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxufVxyXG5cclxuLnRpbWUge1xyXG4gICAgY29sb3I6ICNkZmRmZGY7XHJcbiAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICBmb250LXNpemU6IHNtYWxsO1xyXG59XHJcbn1cclxuIC5tc2ctYXJlYSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNGMzkyMDA7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDYxcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDBweDtcclxuICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgIHBhZGRpbmc6IDZweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTRweDtcclxuICAgIHJlc2l6ZTogbm9uZTtcclxuICAgIGhlaWdodDogNTlweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuLy8gLm1lc3NhZ2UtaW5wdXQge1xyXG4vLyAgICAgLy8gd2lkdGg6IDEwMCU7XHJcbi8vICAgICAvLyBib3JkZXI6IDFweCBzb2xpZCAjRjM5MjAwO1xyXG4vLyAgICAgLy8gYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbi8vICAgICAvLyBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4vLyAgICAgLy8gcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4vLyAgICAgLy8gcGFkZGluZy1yaWdodDogMTBweDtcclxuLy8gICAgIC8vIG1hcmdpbi1sZWZ0OiA0M3B4O1xyXG4vLyB9XHJcbi5pb24taWNvbiAge1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG59XHJcbjo6cGxhY2Vob2xkZXIge1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbn1cclxuXHJcblxyXG5cclxuXHJcbi5wLTEge1xyXG4gICAgcGFkZGluZzogMHB4IDBweCAxM3B4IDEzcHg7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG5pb24tZmFiLWJ1dHRvbiB7XHJcbiAgICAtLWJhY2tncm91bmQtZm91Y3NlZDogbm9uZTtcclxuICAgIC0tYmFja2dyb3VuZC1ob3Zlcjogbm9uZTtcclxufVxyXG5cclxuaW9uLWZvb3RlciB7XHJcblxyXG4gICAgaW9uLXRvb2xiYXIge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogI2ZmZjtcclxuICAgIH1cclxufVxyXG5cclxuXHJcbi5tZXNzYWdlLWlucHV0IHtcclxuICAgIC8vIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAgLy8gYm94LXNoYWRvdzogMnB4IDJweCA1cHggMHB4IHJnYigwIDAgMCAvIDUlKTtcclxuICB9XHJcblxyXG4gIC5tc2ctYnRuIHtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMC41ZW07XHJcbiAgICAtLXBhZGRpbmctZW5kOiAwLjVlbTtcclxuICAgIGlvbi1pY29ue1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIH1cclxufVxyXG4gIFxyXG4gIGlvbi10ZXh0YXJlYSB7XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6IDIwcHg7XHJcbiAgICAtLXBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICAtLXBhZGRpbmctYm90dG9tOiA0cHg7XHJcbiAgICBtaW4taGVpZ2h0OiAzMHB4O1xyXG4gIH1cclxuICAiLCJpb24tY29udGVudCB7XG4gIGhlaWdodDogOTElO1xufVxuXG5pb24tbGlzdCB7XG4gIGJveC1zaGFkb3c6IDJweCAycHggMTRweCByZ2JhKDAsIDAsIDAsIDAuMjI1KTtcbn1cblxuaW9uLWxhYmVsIHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5cbi5iYWNrLWJ1dHRvbiB7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGJveC1zaGFkb3c6IDJweCAzcHggNXB4IDVweCB3aGl0ZXNtb2tlO1xuICBoZWlnaHQ6IDMzcHg7XG4gIHdpZHRoOiAzM3B4O1xufVxuXG5pb24tZ3JpZCBpbWcge1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xufVxuaW9uLWdyaWQgLnRpbWUge1xuICBvcGFjaXR5OiAwLjc7XG4gIGZvbnQtc2l6ZTogOHB4O1xufVxuaW9uLWdyaWQgLm1lc3NhZ2Uge1xuICBwYWRkaW5nOiAxMHB4O1xuICBtYXJnaW46IDIwcHg7XG4gIHdoaXRlLXNwYWNlOiBwcmUtd3JhcDtcbn1cbmlvbi1ncmlkIC5vdGhlci1tZXNzYWdlIHtcbiAgYm9yZGVyLXJhZGl1czogMHB4IDE2cHggMTZweCAxNnB4O1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGNvbG9yOiAjZmZmO1xufVxuaW9uLWdyaWQgLm15LW1lc3NhZ2Uge1xuICBib3JkZXItcmFkaXVzOiAxNnB4IDBweCAxNnB4IDE2cHg7XG4gIGJveC1zaGFkb3c6IDJweCAycHggMTdweCByZ2JhKDAsIDAsIDAsIDAuMjI1KTtcbiAgYmFja2dyb3VuZDogbm9uZTtcbiAgY29sb3I6IHJnYigwLCAwLCAwKTtcbn1cbmlvbi1ncmlkIC5teV9pbWcge1xuICB3aWR0aDogMjZweDtcbiAgaGVpZ2h0OiAyNnB4O1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAwO1xuICB0b3A6IDEwNyU7XG59XG5pb24tZ3JpZCAub3RoZXJfaW1nIHtcbiAgd2lkdGg6IDI2cHg7XG4gIGhlaWdodDogMjZweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAtMTVweDtcbiAgdG9wOiAxMDclO1xufVxuaW9uLWdyaWQgLnVzZXJpbWFnZSB7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG59XG5pb24tZ3JpZCAudGltZSB7XG4gIGNvbG9yOiAjZGZkZmRmO1xuICBmbG9hdDogcmlnaHQ7XG4gIGZvbnQtc2l6ZTogc21hbGw7XG59XG5cbi5tc2ctYXJlYSB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXI6IDFweCBzb2xpZCAjRjM5MjAwO1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xuICBtYXJnaW4tbGVmdDogNjFweDtcbiAgYm9yZGVyLXJhZGl1czogMTAwcHg7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgcGFkZGluZzogNnB4O1xuICBwYWRkaW5nLWxlZnQ6IDE0cHg7XG4gIHJlc2l6ZTogbm9uZTtcbiAgaGVpZ2h0OiA1OXB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4uaW9uLWljb24ge1xuICBmb250LXNpemU6IDIwcHg7XG59XG5cbjo6cGxhY2Vob2xkZXIge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbn1cblxuLnAtMSB7XG4gIHBhZGRpbmc6IDBweCAwcHggMTNweCAxM3B4O1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG5pb24tZmFiLWJ1dHRvbiB7XG4gIC0tYmFja2dyb3VuZC1mb3Vjc2VkOiBub25lO1xuICAtLWJhY2tncm91bmQtaG92ZXI6IG5vbmU7XG59XG5cbmlvbi1mb290ZXIgaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICNmZmY7XG59XG5cbi5tZXNzYWdlLWlucHV0IHtcbiAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbn1cblxuLm1zZy1idG4ge1xuICAtLXBhZGRpbmctc3RhcnQ6IDAuNWVtO1xuICAtLXBhZGRpbmctZW5kOiAwLjVlbTtcbn1cbi5tc2ctYnRuIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNXB4O1xufVxuXG5pb24tdGV4dGFyZWEge1xuICAtLXBhZGRpbmctc3RhcnQ6IDIwcHg7XG4gIC0tcGFkZGluZy10b3A6IDRweDtcbiAgLS1wYWRkaW5nLWJvdHRvbTogNHB4O1xuICBtaW4taGVpZ2h0OiAzMHB4O1xufSJdfQ== */";

/***/ }),

/***/ 9910:
/*!************************************************!*\
  !*** ./src/app/chat/chat.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\r\n  <!-- header -->\r\n  <ion-list>\r\n    <ion-item lines=\"none\">\r\n\r\n      <ion-avatar slot=\"start\" class=\"back-button\" (click)=\"go_back()\">\r\n        <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n      </ion-avatar>\r\n      <ion-avatar>\r\n        <img src=\"{{userData.img}}\" class=\"img\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n        <h2>{{userData.name}}</h2>\r\n        <!-- <p>{{chat.last_time}}</p> -->\r\n      </ion-label>\r\n      <ion-icon slot=\"end\" name=\"ellipsis-vertical\" size=\"large\"></ion-icon>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-header>\r\n  <ion-content>\r\n\r\n    <!-- message area -->\r\n    <ion-grid>\r\n      <ion-row *ngFor=\"let message of messages\">\r\n        <ion-col size=\"9\" *ngIf=\"message.incoming_key == other\" class=\"message other-message\">\r\n          <b>{{message.name}}</b><br>\r\n          <span>{{message.msg}}</span>\r\n          <div class=\"time\" text-right><br>\r\n            {{message.date | date:'short'}}\r\n          </div>\r\n  \r\n          <div class=\"other_img\">\r\n            <img src=\"{{message.img}}\" alt=\"\">\r\n          </div>\r\n        </ion-col>\r\n  \r\n        <ion-col offset=\"3\" size=\"9\" *ngIf=\"message.outgoing_key == other\" class=\"message my-message\">\r\n          <b>{{message.name}}</b><br>\r\n          <span>{{message.msg}}</span>\r\n          <div class=\"time\" text-right><br>\r\n            {{message.date | date:'short'}}\r\n          </div>\r\n          <div class=\"my_img\">\r\n            <!-- user img -->\r\n            <img src=\"{{message.img}}\" alt=\"\">\r\n          </div>\r\n        </ion-col>\r\n  \r\n      </ion-row>\r\n    </ion-grid>\r\n  \r\n  </ion-content>\r\n  \r\n  \r\n  <!-- enter msg -->\r\n  <!-- <ion-fab horizontal=\"start\" vertical=\"bottom\" slot=\"fixed\">\r\n    <ion-fab-button>\r\n      <ion-icon color=\"light\" name=\"add\"></ion-icon>\r\n    </ion-fab-button>\r\n    <ion-fab-list side=\"top\">\r\n      <ion-fab-button color=\"light\">\r\n        <ion-icon name=\"logo-facebook\"></ion-icon>\r\n      </ion-fab-button>\r\n      <ion-fab-button color=\"light\">\r\n        <ion-icon name=\"logo-twitter\"></ion-icon>\r\n      </ion-fab-button>\r\n      <ion-fab-button color=\"light\">\r\n        <ion-icon name=\"logo-vimeo\"></ion-icon>\r\n      </ion-fab-button>\r\n      <ion-fab-button color=\"light\">\r\n        <ion-icon name=\"logo-google\"></ion-icon>\r\n      </ion-fab-button>\r\n    </ion-fab-list>\r\n  </ion-fab> -->\r\n  <!-- <ion-footer class=\"ion-no-border\">\r\n  \r\n    <ion-toolbar>\r\n  \r\n      <ion-item lines=\"none\" class=\"p-1\">\r\n        <div class=\"msg-area\">\r\n          <ion-input [autosize]=\"true\" maxRows=\"4\" class=\"message-input\" placeholder=\"text here\" [(ngModel)]=\"newMsg.msg\" ></ion-input> \r\n        </div>\r\n  \r\n        <ion-button expand=\"block\" fill=\"clear\" color=\"primary\"  class=\"msg-btn\"\r\n          (click)=\"sendMessage()\"> \r\n          <ion-icon name=\"send\" slot=\"icon-only\"></ion-icon>\r\n        </ion-button>\r\n      </ion-item>\r\n  \r\n  \r\n  \r\n    </ion-toolbar>\r\n  </ion-footer> -->\r\n\r\n\r\n  <ion-footer class=\"ion-no-border\">\r\n    <ion-toolbar class=\"ion-no-border\">\r\n      <ion-row class=\"ion-align-items-center\">\r\n        <ion-col size=\"10\">\r\n          <ion-textarea placeholder=\"type text here\" class=\"message-input\" autoGrow=\"true\" rows=\"1\" [(ngModel)]=\"newMsg.msg\" ></ion-textarea>\r\n        </ion-col>\r\n        <ion-col size=\"2\" class=\"ion-text-center\">\r\n          <ion-button fill=\"clear\" class=\"msg-btn\" [disabled]=\"newMsg.msg == ''\"  (click)=\"sendMessage()\">\r\n            <ion-icon slot=\"icon-only\" name=\"send\" color=\"primary\"></ion-icon>\r\n          </ion-button>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-toolbar>\r\n  </ion-footer>";

/***/ }),

/***/ 327:
/*!*************************************************************!*\
  !*** ./node_modules/ngx-autosize/fesm2020/ngx-autosize.mjs ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AutosizeDirective": () => (/* binding */ AutosizeDirective),
/* harmony export */   "AutosizeModule": () => (/* binding */ AutosizeModule)
/* harmony export */ });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ 2560);



class WindowRef {
  get nativeWindow() {
    return window;
  }

}

WindowRef.ɵfac = function WindowRef_Factory(t) {
  return new (t || WindowRef)();
};

WindowRef.ɵprov = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"]({
  token: WindowRef,
  factory: WindowRef.ɵfac
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](WindowRef, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Injectable
  }], null, null);
})();

const MAX_LOOKUP_RETRIES = 3;

class AutosizeDirective {
  constructor(element, _window, _zone) {
    this.element = element;
    this._window = _window;
    this._zone = _zone;
    this.onlyGrow = false;
    this.useImportant = false;
    this.resized = new _angular_core__WEBPACK_IMPORTED_MODULE_0__.EventEmitter();
    this.autosize = true;
    this.retries = 0;
    this._destroyed = false;

    if (this.element.nativeElement.tagName !== 'TEXTAREA') {
      this._findNestedTextArea();
    } else {
      this.textAreaEl = this.element.nativeElement;
      this.textAreaEl.style['overflow-y'] = 'hidden';

      this._onTextAreaFound();
    }
  }

  set minRows(value) {
    this._minRows = +value;

    if (this.textAreaEl) {
      this.textAreaEl.rows = this._minRows;
    }
  }

  set _autosize(autosize) {
    this.autosize = typeof autosize === 'boolean' ? autosize : true;
  }

  onInput(textArea) {
    this.adjust();
  }

  ngOnDestroy() {
    this._destroyed = true;

    if (this._windowResizeHandler) {
      this._window.nativeWindow.removeEventListener('resize', this._windowResizeHandler, false);
    }
  }

  ngAfterContentChecked() {
    this.adjust();
  }

  ngOnChanges(changes) {
    this.adjust(true);
  }

  _findNestedTextArea() {
    this.textAreaEl = this.element.nativeElement.querySelector('TEXTAREA');

    if (!this.textAreaEl && this.element.nativeElement.shadowRoot) {
      this.textAreaEl = this.element.nativeElement.shadowRoot.querySelector('TEXTAREA');
    }

    if (!this.textAreaEl) {
      if (this.retries >= MAX_LOOKUP_RETRIES) {
        console.warn('ngx-autosize: textarea not found');
      } else {
        this.retries++;
        setTimeout(() => {
          this._findNestedTextArea();
        }, 100);
      }

      return;
    }

    this.textAreaEl.style['overflow-y'] = 'hidden';

    this._onTextAreaFound();
  }

  _onTextAreaFound() {
    this._addWindowResizeHandler();

    setTimeout(() => {
      this.adjust();
    });
  }

  _addWindowResizeHandler() {
    this._windowResizeHandler = debounce(() => {
      this._zone.run(() => {
        this.adjust();
      });
    }, 200);

    this._zone.runOutsideAngular(() => {
      this._window.nativeWindow.addEventListener('resize', this._windowResizeHandler, false);
    });
  }

  adjust(inputsChanged = false) {
    if (this.autosize && !this._destroyed && this.textAreaEl && this.textAreaEl.parentNode) {
      const currentText = this.textAreaEl.value;

      if (inputsChanged === false && currentText === this._oldContent && this.textAreaEl.offsetWidth === this._oldWidth) {
        return;
      }

      this._oldContent = currentText;
      this._oldWidth = this.textAreaEl.offsetWidth;
      const clone = this.textAreaEl.cloneNode(true);
      const parent = this.textAreaEl.parentNode;
      clone.style.width = this.textAreaEl.offsetWidth + 'px';
      clone.style.visibility = 'hidden';
      clone.style.position = 'absolute';
      clone.textContent = currentText;
      parent.appendChild(clone);
      clone.style['overflow-y'] = 'hidden';
      clone.style.height = 'auto';
      let height = clone.scrollHeight; // add into height top and bottom borders' width

      let computedStyle = this._window.nativeWindow.getComputedStyle(clone, null);

      height += parseInt(computedStyle.getPropertyValue('border-top-width'));
      height += parseInt(computedStyle.getPropertyValue('border-bottom-width')); // add into height top and bottom paddings width

      height += parseInt(computedStyle.getPropertyValue('padding-top'));
      height += parseInt(computedStyle.getPropertyValue('padding-bottom'));
      const oldHeight = this.textAreaEl.offsetHeight;
      const willGrow = height > oldHeight;

      if (this.onlyGrow === false || willGrow) {
        const lineHeight = this._getLineHeight();

        const rowsCount = height / lineHeight;

        if (this._minRows && this._minRows >= rowsCount) {
          height = this._minRows * lineHeight;
        } else if (this.maxRows && this.maxRows <= rowsCount) {
          // never shrink the textarea if onlyGrow is true
          const maxHeight = this.maxRows * lineHeight;
          height = this.onlyGrow ? Math.max(maxHeight, oldHeight) : maxHeight;
          this.textAreaEl.style['overflow-y'] = 'auto';
        } else {
          this.textAreaEl.style['overflow-y'] = 'hidden';
        }

        const heightStyle = height + 'px';
        const important = this.useImportant ? 'important' : '';
        this.textAreaEl.style.setProperty('height', heightStyle, important);
        this.resized.emit(height);
      }

      parent.removeChild(clone);
    }
  }

  _getLineHeight() {
    let lineHeight = parseInt(this.textAreaEl.style.lineHeight, 10);

    if (isNaN(lineHeight) && this._window.nativeWindow.getComputedStyle) {
      const styles = this._window.nativeWindow.getComputedStyle(this.textAreaEl);

      lineHeight = parseInt(styles.lineHeight, 10);
    }

    if (isNaN(lineHeight)) {
      const fontSize = this._window.nativeWindow.getComputedStyle(this.textAreaEl, null).getPropertyValue('font-size');

      lineHeight = Math.floor(parseInt(fontSize.replace('px', ''), 10) * 1.5);
    }

    return lineHeight;
  }

}

AutosizeDirective.ɵfac = function AutosizeDirective_Factory(t) {
  return new (t || AutosizeDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](WindowRef), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone));
};

AutosizeDirective.ɵdir = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
  type: AutosizeDirective,
  selectors: [["", "autosize", ""]],
  hostBindings: function AutosizeDirective_HostBindings(rf, ctx) {
    if (rf & 1) {
      _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("input", function AutosizeDirective_input_HostBindingHandler($event) {
        return ctx.onInput($event.target);
      });
    }
  },
  inputs: {
    minRows: "minRows",
    _autosize: ["autosize", "_autosize"],
    maxRows: "maxRows",
    onlyGrow: "onlyGrow",
    useImportant: "useImportant"
  },
  outputs: {
    resized: "resized"
  },
  features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AutosizeDirective, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Directive,
    args: [{
      selector: '[autosize]'
    }]
  }], function () {
    return [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.ElementRef
    }, {
      type: WindowRef
    }, {
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgZone
    }];
  }, {
    minRows: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    _autosize: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input,
      args: ['autosize']
    }],
    maxRows: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    onlyGrow: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    useImportant: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Input
    }],
    resized: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.Output
    }],
    onInput: [{
      type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.HostListener,
      args: ['input', ['$event.target']]
    }]
  });
})();

function debounce(func, timeout) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      func(...args);
    }, timeout);
  };
}

class AutosizeModule {}

AutosizeModule.ɵfac = function AutosizeModule_Factory(t) {
  return new (t || AutosizeModule)();
};

AutosizeModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
  type: AutosizeModule,
  declarations: [AutosizeDirective],
  exports: [AutosizeDirective]
});
AutosizeModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
  providers: [WindowRef],
  imports: [[]]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AutosizeModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_0__.NgModule,
    args: [{
      declarations: [AutosizeDirective],
      imports: [],
      providers: [WindowRef],
      exports: [AutosizeDirective]
    }]
  }], null, null);
})();
/*
 * Public API Surface of ngx-autosize
 */

/**
 * Generated bundle index. Do not edit.
 */




/***/ })

}]);
//# sourceMappingURL=src_app_chat_chat_module_ts.js.map