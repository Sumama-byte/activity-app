"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_myactivity_myactivity_module_ts"],{

/***/ 2162:
/*!*********************************************************!*\
  !*** ./src/app/myactivity/myactivity-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyactivityPageRoutingModule": () => (/* binding */ MyactivityPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _myactivity_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myactivity.page */ 8949);




const routes = [
    {
        path: '',
        component: _myactivity_page__WEBPACK_IMPORTED_MODULE_0__.MyactivityPage
    }
];
let MyactivityPageRoutingModule = class MyactivityPageRoutingModule {
};
MyactivityPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MyactivityPageRoutingModule);



/***/ }),

/***/ 5720:
/*!*************************************************!*\
  !*** ./src/app/myactivity/myactivity.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyactivityPageModule": () => (/* binding */ MyactivityPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _myactivity_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myactivity-routing.module */ 2162);
/* harmony import */ var _myactivity_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./myactivity.page */ 8949);







let MyactivityPageModule = class MyactivityPageModule {
};
MyactivityPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _myactivity_routing_module__WEBPACK_IMPORTED_MODULE_0__.MyactivityPageRoutingModule
        ],
        declarations: [_myactivity_page__WEBPACK_IMPORTED_MODULE_1__.MyactivityPage]
    })
], MyactivityPageModule);



/***/ }),

/***/ 8949:
/*!***********************************************!*\
  !*** ./src/app/myactivity/myactivity.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MyactivityPage": () => (/* binding */ MyactivityPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _myactivity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./myactivity.page.html?ngResource */ 4008);
/* harmony import */ var _myactivity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./myactivity.page.scss?ngResource */ 330);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/global.service */ 1307);







let MyactivityPage = class MyactivityPage {
    constructor(route, global, apicall) {
        this.route = route;
        this.global = global;
        this.apicall = apicall;
    }
    ngOnInit() {
        this.data = history.state.data;
        console.log(this.data);
    }
    //navigation
    nav_back() {
        this.route.navigate(['tabs/tab2']);
    }
};
MyactivityPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _Services_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService },
    { type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService }
];
MyactivityPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-myactivity',
        template: _myactivity_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_myactivity_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MyactivityPage);



/***/ }),

/***/ 330:
/*!************************************************************!*\
  !*** ./src/app/myactivity/myactivity.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = ".back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  height: 33px;\n  width: 33px;\n}\n\n.txt {\n  font-size: 18px;\n  margin: auto;\n}\n\n.image {\n  width: 100%;\n  height: 230px;\n  margin: 30px auto 0px auto;\n  box-shadow: 2px 2px 37px rgba(0, 0, 0, 0.215);\n}\n\n.algin_left {\n  display: flex;\n}\n\n.div2 {\n  width: 90%;\n  margin-left: auto;\n  margin-right: auto;\n}\n\n.div2 .para {\n  margin-left: auto;\n  margin-right: auto;\n  font-size: small;\n}\n\n.div2 .div3 {\n  font-size: smaller;\n  font-weight: bold;\n  padding: 0;\n}\n\n.div2 .coltime {\n  display: flex;\n}\n\n.div2 .div4 {\n  display: flex;\n  width: 37px;\n  height: 46px;\n  background-color: #F2910C;\n  color: white;\n  border-radius: 8px;\n  font-size: 21px;\n  font-weight: bolder;\n  background-image: url('div_ouline.png');\n  justify-content: center;\n  align-items: center;\n  margin: 8px;\n}\n\nion-button {\n  --background: #F2910C;\n  --border-radius: 100px;\n  height: 60px;\n  width: 150px;\n  padding-top: 20px;\n  color: white;\n  text-transform: none;\n  margin: 0px auto 25px auto;\n}\n\n.fs-0 {\n  width: 100%;\n  font-size: 12px;\n}\n\n.col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n}\n\nion-item {\n  --background: transparent;\n}\n\n.center {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm15YWN0aXZpdHkucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcRml2ZXIlMjBPcmRlcnNcXEFjdGl2aXR5XFxhY3Rpdml0eS1hcHBcXHNyY1xcYXBwXFxteWFjdGl2aXR5XFxteWFjdGl2aXR5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLG1CQUFBO0VBQ0Esc0NBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQ0FKOztBREVBO0VBQ0ksZUFBQTtFQUNBLFlBQUE7QUNDSjs7QURDQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsMEJBQUE7RUFDQSw2Q0FBQTtBQ0VKOztBRENJO0VBQ0ksYUFBQTtBQ0VSOztBREFBO0VBQ0ksVUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNHSjs7QURESTtFQUNJLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ0dSOztBRERJO0VBQ0ksa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7QUNHUjs7QURERTtFQUNFLGFBQUE7QUNHSjs7QURETTtFQUNDLGFBQUE7RUFHRSxXQUFBO0VBQ0QsWUFBQTtFQUVBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBR0EsdUNBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQ0ZSOztBRFNBO0VBQ0kscUJBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7RUFDQSwwQkFBQTtBQ05KOztBRFNBO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUNOSjs7QURRQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7QUNMSjs7QURPQTtFQUNJLHlCQUFBO0FDSko7O0FETUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtBQ0hKIiwiZmlsZSI6Im15YWN0aXZpdHkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiIFxyXG4uYmFjay1idXR0b257XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDNweCA1cHggNXB4IHdoaXRlc21va2U7XHJcbiAgICBoZWlnaHQ6IDMzcHg7XHJcbiAgICB3aWR0aDogMzNweDtcclxufVxyXG4udHh0e1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcbi5pbWFnZXtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAyMzBweDtcclxuICAgIG1hcmdpbjogMzBweCBhdXRvIDBweCBhdXRvO1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDJweCAzN3B4IHJnYmEoMCwgMCwgMCwgMC4yMTUpO1xyXG59XHJcblxyXG4gICAgLmFsZ2luX2xlZnR7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgIH1cclxuLmRpdjJ7XHJcbiAgICB3aWR0aDogOTAlOyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxuICAgIFxyXG4gICAgLnBhcmF7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbiAgICB9XHJcbiAgICAuZGl2M3tcclxuICAgICAgICBmb250LXNpemU6IHNtYWxsZXI7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgIH1cclxuICAuY29sdGltZXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgfVxyXG4gICAgICAuZGl2NHtcclxuICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgLy8gd2lkdGg6IDM3cHg7XHJcbiAgICAgICAgLy8gaGVpZ2h0OiA0M3B4O1xyXG4gICAgICAgICB3aWR0aDogMzdweDtcclxuICAgICAgICBoZWlnaHQ6IDQ2cHg7XHJcbiAgICAgIFxyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNGMjkxMEM7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICBmb250LXNpemU6IDIxcHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgICAgICAvLyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCJkYXRhOmltYWdlL3N2Zyt4bWwsJTNjc3ZnIHdpZHRoPScxMDAlMjUnIGhlaWdodD0nMTAwJTI1JyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnJTNlJTNjcmVjdCB3aWR0aD0nMTAwJTI1JyBoZWlnaHQ9JzEwMCUyNScgZmlsbD0nbm9uZScgcng9JzEwJyByeT0nMTAnIHN0cm9rZT0nYmxhY2snIHN0cm9rZS13aWR0aD0nNicgc3Ryb2tlLWRhc2hhcnJheT0nMTAwJTJjNDUnIHN0cm9rZS1kYXNob2Zmc2V0PSc5Micgc3Ryb2tlLWxpbmVjYXA9J3NxdWFyZScvJTNlJTNjL3N2ZyUzZVwiKTtcclxuICAgICAgICAvLyBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLy4uLy4uL2Fzc2V0cy9kaXZfb3VsaW5lLnBuZyk7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBtYXJnaW46IDhweDtcclxuICAgIH1cclxuXHJcbiAgICAgICAgXHJcbiAgICAgICAgXHJcbiAgICBcclxufVxyXG5pb24tYnV0dG9uIHtcclxuICAgIC0tYmFja2dyb3VuZDogI0YyOTEwQztcclxuICAgIC0tYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICB3aWR0aDogMTUwcHg7XHJcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG4gICAgbWFyZ2luOjBweCBhdXRvIDI1cHggYXV0bztcclxufVxyXG5cclxuLmZzLTB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG4uY29se1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbn1cclxuaW9uLWl0ZW17XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG59XHJcbi5jZW50ZXJ7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59IiwiLmJhY2stYnV0dG9uIHtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgYm94LXNoYWRvdzogMnB4IDNweCA1cHggNXB4IHdoaXRlc21va2U7XG4gIGhlaWdodDogMzNweDtcbiAgd2lkdGg6IDMzcHg7XG59XG5cbi50eHQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbjogYXV0bztcbn1cblxuLmltYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMjMwcHg7XG4gIG1hcmdpbjogMzBweCBhdXRvIDBweCBhdXRvO1xuICBib3gtc2hhZG93OiAycHggMnB4IDM3cHggcmdiYSgwLCAwLCAwLCAwLjIxNSk7XG59XG5cbi5hbGdpbl9sZWZ0IHtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLmRpdjIge1xuICB3aWR0aDogOTAlO1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xufVxuLmRpdjIgLnBhcmEge1xuICBtYXJnaW4tbGVmdDogYXV0bztcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xuICBmb250LXNpemU6IHNtYWxsO1xufVxuLmRpdjIgLmRpdjMge1xuICBmb250LXNpemU6IHNtYWxsZXI7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBwYWRkaW5nOiAwO1xufVxuLmRpdjIgLmNvbHRpbWUge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuLmRpdjIgLmRpdjQge1xuICBkaXNwbGF5OiBmbGV4O1xuICB3aWR0aDogMzdweDtcbiAgaGVpZ2h0OiA0NnB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjI5MTBDO1xuICBjb2xvcjogd2hpdGU7XG4gIGJvcmRlci1yYWRpdXM6IDhweDtcbiAgZm9udC1zaXplOiAyMXB4O1xuICBmb250LXdlaWdodDogYm9sZGVyO1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoLi8uLi8uLi9hc3NldHMvZGl2X291bGluZS5wbmcpO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luOiA4cHg7XG59XG5cbmlvbi1idXR0b24ge1xuICAtLWJhY2tncm91bmQ6ICNGMjkxMEM7XG4gIC0tYm9yZGVyLXJhZGl1czogMTAwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgd2lkdGg6IDE1MHB4O1xuICBwYWRkaW5nLXRvcDogMjBweDtcbiAgY29sb3I6IHdoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgbWFyZ2luOiAwcHggYXV0byAyNXB4IGF1dG87XG59XG5cbi5mcy0wIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuLmNvbCB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cbi5jZW50ZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn0iXX0= */";

/***/ }),

/***/ 4008:
/*!************************************************************!*\
  !*** ./src/app/myactivity/myactivity.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\r\n  <ion-item lines=\"none\" class=\"ion-text-center\">\r\n\r\n    <div slot=\"start\" class=\"back-button\" (click)=\"nav_back()\">\r\n      <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n    </div>\r\n    <!-- Activtiy title -->\r\n    <p class=\"txt\">{{data.activity_name}}</p>\r\n\r\n    <ion-icon slot=\"end\" name=\"heart-outline\"></ion-icon>\r\n  </ion-item>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"col\">\r\n      <!-- location image  -->\r\n       \r\n        <img class=\"image\" src=\"{{data.a_image}}\" alt=\"\">\r\n \r\n\r\n      <ion-item lines=\"none\" class=\"fs-0\">\r\n        <div slot=\"start\" class=\"algin_left\">\r\n\r\n          <ion-icon name=\"location-outline\" size=\"large\"></ion-icon>\r\n\r\n          <!-- activity location -->\r\n          <p> {{data.location}}</p>\r\n\r\n        </div>\r\n        <!-- Avtivity range -->\r\n        <div slot=\"end\">\r\n          <p> Within {{data.social_range}} Km</p>\r\n        </div>\r\n      </ion-item>\r\n\r\n\r\n    </ion-col>\r\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"center\">\r\n\r\n      <div class=\"div2\">\r\n        <!-- activity description -->\r\n        <p class=\"para\">\r\n          {{data.description}}\r\n        </p>\r\n        <!-- attendies title -->\r\n        <p><b>Number Of Atendees Allowed</b></p>\r\n        <!-- canidaties nunber -->\r\n        <h5><b>{{data.max_atendes}} </b></h5>\r\n        <ion-row>\r\n          <ion-col size=\"6\" class=\"div3\">Start Time</ion-col>\r\n          <ion-col size=\"6\" class=\"div3\">End Time</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n\r\n          <!-- Activity Start time  -->\r\n          <ion-col size=\"6\" class=\"coltime\">\r\n            <div class=\"div4\">\r\n                {{data.start_time}}\r\n            </div>\r\n            <div class=\"div4\">00</div>\r\n          </ion-col>\r\n          <!-- Activity end time  -->\r\n          <ion-col size=\"6\" class=\"coltime\">\r\n            <div class=\"div4\">{{data.end_time}}</div>\r\n            <div class=\"div4\">00</div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_myactivity_myactivity_module_ts.js.map