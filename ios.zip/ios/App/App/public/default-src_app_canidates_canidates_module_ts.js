"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_canidates_canidates_module_ts"],{

/***/ 9782:
/*!*******************************************************!*\
  !*** ./src/app/canidates/canidates-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CanidatesPageRoutingModule": () => (/* binding */ CanidatesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _canidates_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./canidates.page */ 5629);




const routes = [
    {
        path: '',
        component: _canidates_page__WEBPACK_IMPORTED_MODULE_0__.CanidatesPage
    }
];
let CanidatesPageRoutingModule = class CanidatesPageRoutingModule {
};
CanidatesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CanidatesPageRoutingModule);



/***/ }),

/***/ 6947:
/*!***********************************************!*\
  !*** ./src/app/canidates/canidates.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CanidatesPageModule": () => (/* binding */ CanidatesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _canidates_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./canidates-routing.module */ 9782);
/* harmony import */ var _canidates_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./canidates.page */ 5629);







let CanidatesPageModule = class CanidatesPageModule {
};
CanidatesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _canidates_routing_module__WEBPACK_IMPORTED_MODULE_0__.CanidatesPageRoutingModule
        ],
        declarations: [_canidates_page__WEBPACK_IMPORTED_MODULE_1__.CanidatesPage]
    })
], CanidatesPageModule);



/***/ }),

/***/ 5629:
/*!*********************************************!*\
  !*** ./src/app/canidates/canidates.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CanidatesPage": () => (/* binding */ CanidatesPage)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _canidates_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./canidates.page.html?ngResource */ 8844);
/* harmony import */ var _canidates_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./canidates.page.scss?ngResource */ 7989);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);








let CanidatesPage = class CanidatesPage {
  constructor(route, global, apicall) {
    this.route = route;
    this.global = global;
    this.apicall = apicall;
    this.selectTabs = 'going';
    this.going = [{
      id: 1,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'William'
    }, {
      id: 2,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'William'
    }];
    this.may_be_going = [{
      id: 1,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'Miller'
    }, {
      id: 2,
      user_img: '../../assets/Rectangle 144.png',
      user_name: 'Miller'
    }];
  }

  ngOnInit() {
    this.getAllStatus();
  }

  getAllStatus() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.global.GetActivityStatus.subscribe(res => {
        _this.allStatus = res;
        console.log(_this.allStatus);
        _this.Going = _this.allStatus.filter(x => x.status === 'g');
        console.log(_this.Going);
        _this.MaybeGoing = _this.allStatus.filter(x => x.status === 'm');
        console.log(_this.MaybeGoing);
      });
    })();
  }

  go_back() {
    this.route.navigate(['/tabs/tab1']);
  }

};

CanidatesPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

CanidatesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-canidates',
  template: _canidates_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_canidates_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], CanidatesPage);


/***/ }),

/***/ 7989:
/*!**********************************************************!*\
  !*** ./src/app/canidates/canidates.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = ".header {\n  margin-top: 10px;\n  display: flex;\n  align-items: center;\n}\n\n.text {\n  margin: 0px;\n  text-align: center;\n  font-size: 18px;\n}\n\nion-segment {\n  width: 300px;\n  display: flex;\n  border-radius: 100px;\n  background: white;\n  box-shadow: 0px 0px 12px -6px rgba(0, 0, 0, 0.66);\n  -moz-box-shadow: 0px 0px 12px -6px rgba(0, 0, 0, 0.66);\n  margin: auto auto;\n}\n\nion-segment ion-segment-button {\n  --border-radius: 100px;\n  --indicator-color: #F2910C;\n  --color-checked: white;\n  padding: 10px;\n}\n\nion-row {\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  padding: 5px;\n}\n\nion-row ion-col {\n  min-height: 69px;\n  display: flex;\n  margin: 0px 5px 0px 5px;\n  padding: 0;\n  border-radius: 10px;\n  align-items: center;\n}\n\nion-row ion-col .user_img {\n  border: 2px solid #17A525;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 1px;\n  border-radius: 14px;\n  width: 50px;\n  height: 50px;\n  margin: 15px 0px 0px 5px;\n}\n\nion-row ion-col .user_img .userimg {\n  height: 100%;\n  width: 100%;\n  border-radius: 14px;\n}\n\nion-row ion-col .m-1 {\n  margin: 3.5px 12px;\n}\n\nion-row ion-col .m-2 {\n  margin: 15px 0px 0px 5px;\n}\n\nion-row ion-col .title {\n  font-size: 16px;\n  line-height: 18.75px;\n}\n\n.bold_lbl {\n  font-family: \"Roboto\", sans-serif;\n  font-weight: bold;\n  text-align: center;\n  margin-bottom: 5px;\n  margin-top: 50px;\n  text-transform: uppercase;\n  letter-spacing: 5px;\n  position: absolute;\n  top: 40%;\n  left: 0;\n  right: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbmlkYXRlcy5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFxGaXZlciUyME9yZGVyc1xcQWN0aXZpdHlcXGFjdGl2aXR5LWFwcFxcc3JjXFxhcHBcXGNhbmlkYXRlc1xcY2FuaWRhdGVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDQ0o7O0FEUUE7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FDTEo7O0FET0E7RUFDSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0VBQ0EsaUJBQUE7RUFDQSxpREFBQTtFQUNBLHNEQUFBO0VBQ0EsaUJBQUE7QUNKSjs7QURNSTtFQUNJLHNCQUFBO0VBQ0EsMEJBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7QUNKUjs7QURPQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFFQSxZQUFBO0FDTEo7O0FET0k7RUFDSSxnQkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0FDTFI7O0FET1E7RUFDSSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtBQ0xaOztBRE1ZO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQ0poQjs7QURRUTtFQUNJLGtCQUFBO0FDTlo7O0FEU1E7RUFDSSx3QkFBQTtBQ1BaOztBRFVRO0VBQ0ksZUFBQTtFQUNBLG9CQUFBO0FDUlo7O0FEZUE7RUFDSSxpQ0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0FDWkoiLCJmaWxlIjoiY2FuaWRhdGVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkZXJ7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgZGlzcGxheTpmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG4vLyAuYmFjay1idXR0b257XHJcbi8vICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4vLyAgICAgYm94LXNoYWRvdzogMnB4IDNweCA1cHggNXB4IHdoaXRlc21va2U7XHJcbi8vICAgICBtYXJnaW4tbGVmdDogMTVweDtcclxuLy8gICAgIGhlaWdodDogMzNweDtcclxuLy8gICAgIHdpZHRoOiAzM3B4O1xyXG4vLyB9XHJcbi50ZXh0e1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuaW9uLXNlZ21lbnQge1xyXG4gICAgd2lkdGg6MzAwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwcHg7ICAgXHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTJweCAtNnB4IHJnYigwIDAgMCAvIDY2JSk7XHJcbiAgICAtbW96LWJveC1zaGFkb3c6IDBweCAwcHggMTJweCAtNnB4IHJnYmEoMCwgMCwgMCwgMC42Nik7XHJcbiAgICBtYXJnaW46IGF1dG8gYXV0bztcclxuXHJcbiAgICBpb24tc2VnbWVudC1idXR0b24ge1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgICAgICAgLS1pbmRpY2F0b3ItY29sb3I6ICNGMjkxMEM7XHJcbiAgICAgICAgLS1jb2xvci1jaGVja2VkOiB3aGl0ZTtcclxuICAgICAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgfVxyXG59XHJcbmlvbi1yb3cge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBcclxuICAgIHBhZGRpbmc6IDVweDtcclxuXHJcbiAgICBpb24tY29sIHtcclxuICAgICAgICBtaW4taGVpZ2h0OiA2OXB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgbWFyZ2luOiAwcHggNXB4IDBweCA1cHg7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgICAgIC51c2VyX2ltZyB7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMnB4IHNvbGlkICMxN0E1MjU7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAxcHg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMTVweCAwcHggMHB4IDVweDtcclxuICAgICAgICAgICAgLnVzZXJpbWd7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5tLTEge1xyXG4gICAgICAgICAgICBtYXJnaW46IDMuNXB4IDEycHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAubS0yIHtcclxuICAgICAgICAgICAgbWFyZ2luOiAxNXB4IDBweCAwcHggNXB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnRpdGxlIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogMTguNzVweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxufVxyXG5cclxuLmJvbGRfbGJse1xyXG4gICAgZm9udC1mYW1pbHk6ICdSb2JvdG8nICwgc2Fucy1zZXJpZjtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgbWFyZ2luLXRvcDogNTBweDtcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICBsZXR0ZXItc3BhY2luZzogNXB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA0MCU7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbn0iLCIuaGVhZGVyIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLnRleHQge1xuICBtYXJnaW46IDBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE4cHg7XG59XG5cbmlvbi1zZWdtZW50IHtcbiAgd2lkdGg6IDMwMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBib3JkZXItcmFkaXVzOiAxMDBweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIGJveC1zaGFkb3c6IDBweCAwcHggMTJweCAtNnB4IHJnYmEoMCwgMCwgMCwgMC42Nik7XG4gIC1tb3otYm94LXNoYWRvdzogMHB4IDBweCAxMnB4IC02cHggcmdiYSgwLCAwLCAwLCAwLjY2KTtcbiAgbWFyZ2luOiBhdXRvIGF1dG87XG59XG5pb24tc2VnbWVudCBpb24tc2VnbWVudC1idXR0b24ge1xuICAtLWJvcmRlci1yYWRpdXM6IDEwMHB4O1xuICAtLWluZGljYXRvci1jb2xvcjogI0YyOTEwQztcbiAgLS1jb2xvci1jaGVja2VkOiB3aGl0ZTtcbiAgcGFkZGluZzogMTBweDtcbn1cblxuaW9uLXJvdyB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgcGFkZGluZzogNXB4O1xufVxuaW9uLXJvdyBpb24tY29sIHtcbiAgbWluLWhlaWdodDogNjlweDtcbiAgZGlzcGxheTogZmxleDtcbiAgbWFyZ2luOiAwcHggNXB4IDBweCA1cHg7XG4gIHBhZGRpbmc6IDA7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG5pb24tcm93IGlvbi1jb2wgLnVzZXJfaW1nIHtcbiAgYm9yZGVyOiAycHggc29saWQgIzE3QTUyNTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHBhZGRpbmc6IDFweDtcbiAgYm9yZGVyLXJhZGl1czogMTRweDtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbiAgbWFyZ2luOiAxNXB4IDBweCAwcHggNXB4O1xufVxuaW9uLXJvdyBpb24tY29sIC51c2VyX2ltZyAudXNlcmltZyB7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1yYWRpdXM6IDE0cHg7XG59XG5pb24tcm93IGlvbi1jb2wgLm0tMSB7XG4gIG1hcmdpbjogMy41cHggMTJweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAubS0yIHtcbiAgbWFyZ2luOiAxNXB4IDBweCAwcHggNXB4O1xufVxuaW9uLXJvdyBpb24tY29sIC50aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDE4Ljc1cHg7XG59XG5cbi5ib2xkX2xibCB7XG4gIGZvbnQtZmFtaWx5OiBcIlJvYm90b1wiLCBzYW5zLXNlcmlmO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGxldHRlci1zcGFjaW5nOiA1cHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA0MCU7XG4gIGxlZnQ6IDA7XG4gIHJpZ2h0OiAwO1xufSJdfQ== */";

/***/ }),

/***/ 8844:
/*!**********************************************************!*\
  !*** ./src/app/canidates/canidates.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n\r\n  <!-- header -->\r\n  <ion-list class=\"header\">\r\n     <ion-item lines=\"none\">\r\n      \r\n      <div slot=\"start\" class=\"back-button\" (click)=\"go_back()\">\r\n        <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n      </div>\r\n\r\n        \r\n      <p class=\"text ion-text-center\"><b>Beach Party</b></p>\r\n   \r\n\r\n     </ion-item>    \r\n  </ion-list>\r\n\r\n  <!-- segment change  -->\r\n  <ion-segment [(ngModel)]=\"selectTabs\" mode=\"ios\" value=\"going\">\r\n    <ion-segment-button value=\"going\">\r\n      <ion-label>Going</ion-label>\r\n    </ion-segment-button>\r\n    <ion-segment-button value=\"may_be_going\">\r\n      <ion-label>May be going</ion-label>\r\n    </ion-segment-button>\r\n  </ion-segment>\r\n\r\n\r\n  <!-- canidates going -->\r\n\r\n  <ion-row *ngIf=\" selectTabs == 'going'\">\r\n    <ion-col size=\"12\" *ngFor=\"let data of Going\">\r\n\r\n      <div class=\"user_img\">\r\n        <img class=\"userimg\" src=\"{{this.data.img}}\" alt=\"\">\r\n      </div>\r\n\r\n      <div class=\"m-2\">\r\n        <p class=\"title m-1\"><b>{{this.data.name}}</b></p>\r\n      </div>\r\n    </ion-col>\r\n\r\n  <div *ngIf=\"this.Going == 0\">\r\n    <h3 class=\"bold_lbl\">There is no activity here.</h3>\r\n  </div>\r\n\r\n  </ion-row>\r\n\r\n\r\n  <!-- canidates may be going  -->\r\n\r\n  \r\n  <ion-row *ngIf=\" selectTabs == 'may_be_going' \">\r\n    <ion-col size=\"12\" *ngFor=\"let data of MaybeGoing\">\r\n\r\n      <div class=\"user_img\">\r\n        <img class=\"userimg\" src=\"{{this.data.img}}\" alt=\"\">\r\n      </div>\r\n\r\n      <div class=\"m-2\">\r\n        <p class=\"title m-1\"><b>{{this.data.name}}</b></p>\r\n      </div>\r\n    </ion-col>\r\n    <div *ngIf=\"this.MaybeGoing == 0\">\r\n      <h3 class=\"bold_lbl\">There is no activity here.</h3>\r\n    </div>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=default-src_app_canidates_canidates_module_ts.js.map