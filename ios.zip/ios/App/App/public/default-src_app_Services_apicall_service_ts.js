"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_Services_apicall_service_ts"],{

/***/ 3742:
/*!*********************************************!*\
  !*** ./src/app/Services/apicall.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApicallService": () => (/* binding */ ApicallService)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.service */ 2557);
/* harmony import */ var _global_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./global.service */ 1307);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ 8987);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./toast.service */ 4620);








let ApicallService = class ApicallService {
  constructor(global, router, authservice, http, toast) {
    this.global = global;
    this.router = router;
    this.authservice = authservice;
    this.http = http;
    this.toast = toast;
    this.goingStatus = "are  going";
    this.maygoingStatus = "may be going";
    this.alreadygoingStatus = "are already going";
    this.alreadymaygoingStatus = "already may go";
  } // eslint-disable-next-line @typescript-eslint/naming-convention
  //Login


  api_addLogin(login) {
    var _this = this;

    this.authservice.con(login, 'login').then( /*#__PURE__*/function () {
      var _ref = (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (res) {
        _this.login = JSON.parse(String(res).toString()); // this.global.set_login(this.login);

        if (_this.login.error === false) {
          console.log(_this.login);
          return;
        } else {
          console.log(_this.login);
        }
      });

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }(), err => {
      console.log(err);
    });
  } //create activity


  api_addActivity(data) {
    var _this2 = this;

    this.authservice.con(data, 'insert_activity').then( /*#__PURE__*/function () {
      var _ref2 = (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (res) {
        _this2.data = JSON.parse(String(res).toString());

        if (_this2.data.error === false) {
          console.log(_this2.data);
          return;
        }
      });

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }(), err => {
      console.log(err);
    });
  } //Get Method


  getActivities() {
    return this.authservice.getdata('getappointment').then(result => {
      this.activity = JSON.parse(String(result)); // this.global.set_activity(this.activity);

      console.log(this.activity, 'data Updated');
      return result;
    }, err => {
      console.log(err);
      return err;
    });
  } // profile api


  api_postProfile(data) {
    var _this3 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.authservice.con(data, 'create_profile').then(result => {
        _this3.data = JSON.parse(String(result));

        if (_this3.data.error === false) {
          _this3.router.navigate(['/tabs/tab1']);

          _this3.toast.profilecreateToast();

          console.log(_this3.data);
          return;
        } else {
          console.log(_this3.data);
        }
      }, err => {
        console.log(err);
      });
    })();
  }

  api_getprofile(u_id) {
    var _this4 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.authservice.getdata('getprofile/' + u_id).then(result => {
        _this4.data = JSON.parse(String(result));
        console.log(_this4.data);

        _this4.global.set_profileInfo(_this4.data);
      }, err => {
        console.log(err);
      });
    })();
  }

  api_updateprofile(data) {
    var _this5 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5.authservice.con(data, 'update_profile').then(result => {
        _this5.data = JSON.parse(String(result));

        if (_this5.data.error === false) {
          console.log(_this5.data);
          return;
        }

        console.log(_this5.data);
      }, err => {
        console.log(err);
      });
    })();
  } // google login


  api_postLogin(data) {
    var _this6 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this6.authservice.con(data, 'login').then(result => {
        _this6.data = JSON.parse(String(result));

        if (_this6.data.error === false) {
          _this6.router.navigate(['/tabs/tab1']);

          _this6.toast.loginToast();

          console.log(_this6.data);
          return;
        } else _this6.data.error === true;

        _this6.router.navigate(['new-user']);

        _this6.toast.newUserloginToast();

        console.log(_this6.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get activity by id


  api_getActivity(u_id) {
    var _this7 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this7.authservice.getdata('getactivitybyid/' + u_id).then(result => {
        _this7.data = JSON.parse(String(result));
        console.log(_this7.data);

        _this7.global.set_getActivity(_this7.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get all public activity for filter


  api_getallfilterActivity() {
    var _this8 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this8.authservice.getdata('getactivitybylocation').then(result => {
        _this8.data = JSON.parse(String(result));
        console.log(_this8.data);

        _this8.global.set_allfilteractivity(_this8.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get my activity activity


  api_myparticipantActivity(u_id) {
    var _this9 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this9.authservice.getdata('myparticipantactivity/' + u_id).then(result => {
        _this9.data = JSON.parse(String(result));
        console.log(_this9.data);

        _this9.global.set_myparticipant(_this9.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get activity status


  api_ActivityStatus(a_id) {
    var _this10 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this10.authservice.getdata('getstatus_activity/' + a_id).then(result => {
        _this10.data = JSON.parse(String(result));
        console.log(_this10.data);

        _this10.global.set_getActivityStatus(_this10.data);
      }, err => {
        console.log(err);
      });
    })();
  } // post activity


  api_postActivity(data) {
    var _this11 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this11.authservice.con(data, 'insert_activity').then(result => {
        _this11.data = JSON.parse(String(result));

        if (_this11.data.error === false) {
          console.log(_this11.data);

          _this11.toast.createActiviyToast();

          _this11.router.navigate(['tabs/tab2']);

          return;
        } else {
          console.log(_this11.data);
        }
      }, err => {
        console.log(err);
      });
    })();
  } // update activity


  api_updateActivity(data) {
    var _this12 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this12.authservice.con(data, 'updateactivity').then(result => {
        _this12.data = JSON.parse(String(result));

        if (_this12.data.error === false) {
          console.log(_this12.data);
          return;
        }

        console.log(_this12.data);
      }, err => {
        console.log(err);
      });
    })();
  } // post status


  api_postStatus(data) {
    var _this13 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this13.authservice.con(data, 'create_status').then(result => {
        _this13.data = JSON.parse(String(result));

        if (_this13.data.error === false) {
          console.log(_this13.data);
          console.log(data);

          if (data.status == 'g') {
            _this13.toast.alreadygoingActiviyToast(_this13.alreadygoingStatus);
          } else {
            _this13.toast.alreadygoingActiviyToast(_this13.alreadymaygoingStatus);
          }

          return;
        } else {
          console.log(_this13.data);
          console.log(data);

          if (data.status == 'g') {
            _this13.toast.goingActiviyToast(_this13.goingStatus);

            _this13.router.navigate(['tabs/tab2']);
          } else {
            _this13.toast.goingActiviyToast(_this13.maygoingStatus);

            _this13.router.navigate(['tabs/tab2']);
          }
        }
      }, err => {
        console.log(err);
      });
    })();
  } // post status


  api_getStatus(data) {
    var _this14 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this14.authservice.con(data, 'update_status').then(result => {
        _this14.data = JSON.parse(String(result));

        if (_this14.data.error === false) {
          console.log(_this14.data);
          return;
        }

        console.log(_this14.data);
      }, err => {
        console.log(err);
      });
    })();
  }

  api_getpeopleForChat() {} //  get people  for Chat


  api_getUsersForChat(data) {
    var _this15 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this15.authservice.con(data, 'getAllUsers').then(result => {
        _this15.data = JSON.parse(String(result));

        _this15.global.set_storpeopleForchat(_this15.data.users);
      });
    })();
  } // post status


  api_postChat(data) {
    var _this16 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this16.authservice.con(data, 'insertChat').then(result => {
        _this16.data = JSON.parse(String(result));

        if (_this16.data.error === false) {
          console.log(_this16.data);
          return;
        }

        console.log(_this16.data);
      }, err => {
        console.log(err);
      });
    })();
  } // get chat 


  api_getChat(data) {
    var _this17 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this17.authservice.con(data, 'getChat').then( /*#__PURE__*/function () {
        var _ref3 = (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* (res) {
          _this17.data = JSON.parse(String(res).toString());

          _this17.global.set_chat(_this17.data.message);

          console.log(_this17.data);
        });

        return function (_x3) {
          return _ref3.apply(this, arguments);
        };
      }(), err => {
        console.log(err);
      });

      return _this17.data.message;
    })();
  } //  get one week activity


  api_getoneWeekactivity() {
    var _this18 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this18.authservice.getdata('getOneWeekActivity').then(result => {
        _this18.data = JSON.parse(String(result));
        console.log(_this18.data);

        _this18.global.set_allfilteractivity(_this18.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get current date activity


  api_getcurrentDateactivity() {
    var _this19 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this19.authservice.getdata('getcurrentDateActivity').then(result => {
        _this19.data = JSON.parse(String(result));
        console.log(_this19.data);

        _this19.global.set_allfilteractivity(_this19.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get activity Social Range


  api_getactivitySocialRange(social_range) {
    var _this20 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this20.authservice.getdata('getActivityonSocialRange/' + social_range).then(result => {
        _this20.data = JSON.parse(String(result));
        console.log(_this20.data);

        _this20.global.set_allfilteractivity(_this20.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get activity by manual date


  api_getactivitybymanualDate(data) {
    var _this21 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this21.authservice.con(data, 'getActivitybymanualDate').then(result => {
        _this21.data = JSON.parse(String(result));
        console.log(_this21.data);

        _this21.global.set_allfilteractivity(_this21.data);

        console.log(_this21.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  get all public activity


  api_getallActivitybylocation() {
    var _this22 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this22.authservice.getdata('getactivitybylocation').then(result => {
        _this22.data = JSON.parse(String(result));
        console.log(_this22.data);

        _this22.global.set_storallactivity(_this22.data);
      }, err => {
        console.log(err);
      });
    })();
  } //  post location


  api_postLocation(data) {
    var _this23 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this23.authservice.con(data, 'addUserlocation').then(result => {
        _this23.data = JSON.parse(String(result));
        console.log(_this23.data);
      }, err => {
        console.log(err);
      });
    })();
  }

};

ApicallService.ctorParameters = () => [{
  type: _global_service__WEBPACK_IMPORTED_MODULE_2__.GlobalService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router
}, {
  type: _auth_service__WEBPACK_IMPORTED_MODULE_1__.AuthService
}, {
  type: _angular_common_http__WEBPACK_IMPORTED_MODULE_5__.HttpClient
}, {
  type: _toast_service__WEBPACK_IMPORTED_MODULE_3__.ToastService
}];

ApicallService = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Injectable)({
  providedIn: 'root'
})], ApicallService);


/***/ }),

/***/ 2557:
/*!******************************************!*\
  !*** ./src/app/Services/auth.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": () => (/* binding */ AuthService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 8987);



const apiUrl = 'https://turbonowpk.com/activity/public/';
let AuthService = class AuthService {
    constructor(http) {
        this.http = http;
    }
    con(data, type) {
        return new Promise((resolve, reject) => {
            this.http.post(apiUrl + type, JSON.stringify(data)).
                subscribe(res => {
                resolve(JSON.stringify(res));
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
    // geting posts
    getdata(type) {
        return new Promise((resolve, reject) => {
            this.http.get(apiUrl + type).
                subscribe(res => {
                resolve(JSON.stringify(res));
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ 1307:
/*!********************************************!*\
  !*** ./src/app/Services/global.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GlobalService": () => (/* binding */ GlobalService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 4505);



let GlobalService = class GlobalService {
    constructor() {
        //user_chat
        this.chat = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Chat = this.chat.asObservable();
        //activity_details
        this.activity_details = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Activity_Details = this.activity_details.asObservable();
        // create profile
        this.profileInfo = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.ProfileInfo = this.profileInfo.asObservable();
        // user id
        this.uid = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Uid = this.uid.asObservable();
        // get activity
        this.getactivity = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Getactivity = this.getactivity.asObservable();
        // get my participant activity
        this.myparticipant = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Myparticipant = this.myparticipant.asObservable();
        // get all public activity for filter
        this.allfilteractivity = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Allfilteractivity = this.allfilteractivity.asObservable();
        // get status
        this.getActivityStatus = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.GetActivityStatus = this.getActivityStatus.asObservable();
        // get people for chat
        this.storpeopleForchat = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.StorpeopleForchat = this.storpeopleForchat.asObservable();
        // get chat
        this.storchat = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Storchat = this.storchat.asObservable();
        // get all public activity
        this.storallactivity = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Storallactivity = this.storallactivity.asObservable();
        // get activity for update
        this.activityDataforUpdate = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.ActivityDataforUpdate = this.activityDataforUpdate.asObservable();
    }
    set_chat(chat) {
        this.chat.next(chat);
    }
    set_activity_details(activity_details) {
        this.activity_details.next(activity_details);
    }
    set_profileInfo(u_id) {
        this.profileInfo.next(u_id);
        console.log(u_id);
    }
    add_uid(u_id) {
        this.uid.next(u_id);
        console.log(u_id);
    }
    set_getActivity(getactivity) {
        this.getactivity.next(getactivity);
        console.log(getactivity);
    }
    set_myparticipant(myparticipant) {
        this.myparticipant.next(myparticipant);
        console.log(myparticipant);
    }
    set_allfilteractivity(allfilteractivity) {
        this.allfilteractivity.next(allfilteractivity);
        console.log(allfilteractivity);
    }
    set_getActivityStatus(getActivityStatus) {
        this.getActivityStatus.next(getActivityStatus);
        console.log(getActivityStatus);
    }
    set_storpeopleForchat(storpeopleForchat) {
        this.storpeopleForchat.next(storpeopleForchat);
        console.log(storpeopleForchat);
    }
    set_storchat(storchat) {
        this.storchat.next(storchat);
        console.log(storchat);
    }
    set_storallactivity(storallactivity) {
        this.storallactivity.next(storallactivity);
        console.log(storallactivity);
    }
    set_activityDataforUpdate(activityDataforUpdate) {
        this.activityDataforUpdate.next(activityDataforUpdate);
        console.log(activityDataforUpdate);
    }
};
GlobalService.ctorParameters = () => [];
GlobalService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], GlobalService);



/***/ }),

/***/ 4620:
/*!*******************************************!*\
  !*** ./src/app/Services/toast.service.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ToastService": () => (/* binding */ ToastService)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 3819);




let ToastService = class ToastService {
  constructor(toastController) {
    this.toastController = toastController;
  }

  goingActiviyToast(status) {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(status);
      const toast = yield _this.toastController.create({
        message: 'You' + ' ' + status + ' ' + 'to this activity',
        duration: 3000,
        cssClass: 'custom-toast',
        mode: 'ios',
        position: 'top',
        icon: 'checkmark-circle',
        buttons: [{
          text: 'Dismiss',
          role: 'cancel'
        }]
      });
      yield toast.present();
    })();
  }

  alreadygoingActiviyToast(status) {
    var _this2 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log(status);
      const toast = yield _this2.toastController.create({
        message: 'You' + ' ' + status + ' ' + 'to this activity',
        duration: 3000,
        cssClass: 'custom-toast',
        mode: 'ios',
        position: 'top',
        icon: 'checkmark-done-circle',
        buttons: [{
          text: 'Dismiss',
          role: 'cancel'
        }]
      });
      yield toast.present();
    })();
  }

  createActiviyToast() {
    var _this3 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this3.toastController.create({
        message: 'Your activity created successfully',
        duration: 3000,
        cssClass: 'custom-toast',
        mode: 'ios',
        position: 'top',
        icon: 'checkmark-circle',
        buttons: [{
          text: 'Dismiss',
          role: 'cancel'
        }]
      });
      yield toast.present();
    })();
  }

  loginToast() {
    var _this4 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this4.toastController.create({
        message: 'Login Successfully',
        duration: 3000,
        cssClass: 'custom-toast',
        mode: 'ios',
        position: 'top',
        icon: 'checkmark-circle',
        buttons: [{
          text: 'Dismiss',
          role: 'cancel'
        }]
      });
      yield toast.present();
    })();
  }

  newUserloginToast() {
    var _this5 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this5.toastController.create({
        message: 'Create a profile before login successfully',
        duration: 3000,
        cssClass: 'custom-toast',
        mode: 'ios',
        position: 'top',
        icon: 'checkmark-circle',
        buttons: [{
          text: 'Dismiss',
          role: 'cancel'
        }]
      });
      yield toast.present();
    })();
  }

  profilecreateToast() {
    var _this6 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const toast = yield _this6.toastController.create({
        message: 'Your profile created successfully',
        duration: 3000,
        cssClass: 'custom-toast',
        mode: 'ios',
        position: 'top',
        icon: 'checkmark-circle',
        buttons: [{
          text: 'Dismiss',
          role: 'cancel'
        }]
      });
      yield toast.present();
    })();
  }

};

ToastService.ctorParameters = () => [{
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.ToastController
}];

ToastService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
  providedIn: 'root'
})], ToastService);


/***/ })

}]);
//# sourceMappingURL=default-src_app_Services_apicall_service_ts.js.map