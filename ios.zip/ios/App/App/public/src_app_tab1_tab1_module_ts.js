"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_tab1_tab1_module_ts"],{

/***/ 1419:
/*!******************************************!*\
  !*** ./src/app/Services/gmap.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GmapsService": () => (/* binding */ GmapsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);



let GmapsService = class GmapsService {
  constructor() {}

  loadGoogleMaps() {
    const win = window;
    const gModule = win.google;

    if (gModule && gModule.maps) {
      return Promise.resolve(gModule.maps);
    }

    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://maps.googleapis.com/maps/api/js?key=' + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.mapsKey;
      script.async = true;
      script.defer = true;
      document.body.appendChild(script);

      script.onload = () => {
        const loadedGoogleModule = win.google;

        if (loadedGoogleModule && loadedGoogleModule.maps) {
          resolve(loadedGoogleModule.maps);
        } else {
          reject('Google Map SDK is not Available');
        }
      };
    });
  }

};

GmapsService.ctorParameters = () => [];

GmapsService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
  providedIn: 'root'
})], GmapsService);


/***/ }),

/***/ 805:
/*!***********************************************!*\
  !*** ./src/app/Services/locations.service.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LocationsService": () => (/* binding */ LocationsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 2560);


let LocationsService = class LocationsService {
    constructor() { }
    getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
        var R = 6371; // Radius of the earth in km
        var dLat = this.deg2rad(lat2 - lat1); // deg2rad below
        var dLon = this.deg2rad(lon2 - lon1);
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        var d = R * c; // Distance in km
        return d / 1000;
    }
    deg2rad(deg) {
        return deg * (Math.PI / 180);
    }
};
LocationsService.ctorParameters = () => [];
LocationsService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.Injectable)({
        providedIn: 'root'
    })
], LocationsService);



/***/ }),

/***/ 4401:
/*!************************************!*\
  !*** ./src/app/tab1/data/index.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "markers": () => (/* binding */ markers)
/* harmony export */ });
const markers = [
    { lat: 30.340225481755812, lng: 73.37332275805674, title: "Man Lee", description: "Chinese Takeaway", address: "122 Ballymacash Rd, Lisburn BT28 3EZ", website: "https://m.facebook.com/pages/Man-Lee/228415820694835", phone: "028 92 662853" },
    { lat: 54.5097827, lng: -6.0572343, title: "Cam Hing", description: "Chinese Takeaway", address: "70 Longstone St, Lisburn BT28 1TR", website: "https://camhinglisbunr.com", phone: "028 92 677928" },
    { lat: 54.5095162, lng: -6.0595896, title: "Golden Garden", description: "Chinese Takeaway", address: "140 Longstone St, Lisburn BT28 1TR", website: "https://golden-garden.business.site", phone: "028 92 671311" },
    { lat: 54.5091808, lng: -6.0363902, title: "Pagoda", description: "Chinese Takeaway", address: "79 Sloan St, Lisburn BT27 5AG", website: "https://pagodalisburn.com", phone: "028 92 665289" },
    { lat: 54.5989611, lng: -5.9972126, title: "Little Wing", description: "Pizzeria", address: "10 Ann St, Belfast BT1 4EF", website: "https://littlewingpizzeria.com", phone: "028 90 247000" }
];


/***/ }),

/***/ 2580:
/*!*********************************************!*\
  !*** ./src/app/tab1/tab1-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageRoutingModule": () => (/* binding */ Tab1PageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 6923);




const routes = [
    {
        path: '',
        component: _tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page,
    }
];
let Tab1PageRoutingModule = class Tab1PageRoutingModule {
};
Tab1PageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], Tab1PageRoutingModule);



/***/ }),

/***/ 2168:
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1PageModule": () => (/* binding */ Tab1PageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tab1.page */ 6923);
/* harmony import */ var _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../explore-container/explore-container.module */ 581);
/* harmony import */ var _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1-routing.module */ 2580);








let Tab1PageModule = class Tab1PageModule {
};
Tab1PageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_4__.CUSTOM_ELEMENTS_SCHEMA],
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule,
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _explore_container_explore_container_module__WEBPACK_IMPORTED_MODULE_1__.ExploreContainerComponentModule,
            _tab1_routing_module__WEBPACK_IMPORTED_MODULE_2__.Tab1PageRoutingModule
        ],
        declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_0__.Tab1Page]
    })
], Tab1PageModule);



/***/ }),

/***/ 6923:
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Tab1Page": () => (/* binding */ Tab1Page)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tab1.page.html?ngResource */ 3852);
/* harmony import */ var _tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tab1.page.scss?ngResource */ 8165);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/global.service */ 1307);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _data_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./data/index */ 4401);
/* harmony import */ var _Services_locations_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Services/locations.service */ 805);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs */ 5398);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_app_Services_gmap_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/Services/gmap.service */ 1419);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);













let Tab1Page = class Tab1Page {
  constructor(route, global, location, apiCall, gmaps, renderer) {
    this.route = route;
    this.global = global;
    this.location = location;
    this.apiCall = apiCall;
    this.gmaps = gmaps;
    this.renderer = renderer;
    this.center = {
      lat: '',
      lng: ''
    };
    this.markers = []; // segment value

    this.selectTabs = 'map';
    this.profile_data = {
      u_id: '',
      name: '',
      img: '',
      bio: '',
      socialize_distance: ''
    };
    this.coords = [{
      coordinate: {
        lat: 33.2,
        lng: -117.8
      }
    }];
    this.userlocation = {
      u_id: '',
      lng: '',
      lat: ''
    };
    this.YourActivity = {
      u_id: ''
    };
  }

  ngOnInit() {
    this.getProfile();
    const ticker = (0,rxjs__WEBPACK_IMPORTED_MODULE_9__.timer)(0, 5000); // ticker.subscribe(() => {
    //   this.getLocation();
    // });

    this.getAllActivity();
    this.get_appData();
    console.log(this.coordinates);
    setInterval(() => {
      this.get_appData(); // api call
    }, 30000); // this.loadMap()
  }

  ngAfterViewInit() {
    this.loadMap();
  }

  loadMap() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const coordinates = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_8__.Geolocation.getCurrentPosition();

      try {
        let googleMaps = yield _this.gmaps.loadGoogleMaps();
        _this.googleMap = yield _this.gmaps.loadGoogleMaps();
        _this.googleMaps = googleMaps;
        const mapEl = _this.mapElementRef.nativeElement;
        const location = new googleMaps.LatLng(coordinates.coords.latitude, coordinates.coords.longitude);
        _this.map = new googleMaps.Map(mapEl, {
          center: location,
          zoom: 16
        });

        _this.renderer.addClass(mapEl, 'visible');

        _this.addMarker(location); // this.onMapClick();

      } catch (e) {
        console.log(e);
      }
    })();
  }

  addMarker(location) {
    console.log(location);
    let googleMaps = this.googleMaps;
    const icon = {
      url: this.Profile,
      scaledSize: new googleMaps.Size(50, 50)
    };
    const marker = new googleMaps.Marker({
      position: location,
      map: this.map,
      icon: icon // draggable: true,
      // animation: googleMaps.Animation.DROP

    });
    this.markers.push(marker); // this.presentActionSheet();

    this.markerClickListener = this.googleMaps.event.addListener(marker, 'click', () => {
      console.log('markerclick', marker); // this.checkAndRemoveMarker(marker);

      console.log('markers: ', this.markers);
    });

    for (let i = 0; i < this.notificationsActivity.length; i++) {
      console.log(this.notificationsActivity[i]);
      console.log(`${this.notificationsActivity[i].lng}`);
      const lat = `${this.notificationsActivity[i].lat}`;
      const lng = `${this.notificationsActivity[i].lng}`;
      const locations = new this.googleMap.LatLng(lat, lng);
      console.log(locations);
      let googleMaps = this.googleMaps;
      const icon = {
        url: this.notificationsActivity[i].a_image,
        scaledSize: new googleMaps.Size(50, 50)
      };
      const marker = new googleMaps.Marker({
        position: locations,
        map: this.map,
        icon: icon // draggable: true,
        // animation: googleMaps.Animation.DROP

      });
      this.markers.push(marker);
    }
  }

  checkAndRemoveMarker(marker) {
    const index = this.markers.findIndex(x => x.position.lat() == marker.position.lat() && x.position.lng() == marker.position.lng());
    console.log('is marker already: ', index);

    if (index >= 0) {
      this.markers[index].setMap(null);
      this.markers.splice(index, 1);
      return;
    }
  }

  ngOnDestroy() {
    // this.googleMaps.event.removeAllListeners();
    if (this.mapClickListener) this.googleMaps.event.removeListener(this.mapClickListener);
    if (this.markerClickListener) this.googleMaps.event.removeListener(this.markerClickListener);
    this.loadMap();
  }

  getProfile() {
    var _this2 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this2.global.Uid.subscribe(uid => {
        _this2.uid = uid;
        _this2.userlocation.u_id = uid;
      });
      yield _this2.apiCall.api_getprofile(_this2.uid);
      console.log(_this2.uid);
      yield _this2.global.ProfileInfo.subscribe(res => {
        console.log(res[0].img);
        _this2.Profile = res[0].img;
        _this2.userName = res[0].name;
      });
    })();
  }

  getAllActivity() {
    var _this3 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.apiCall.api_getallActivitybylocation();

      _this3.global.Storallactivity.subscribe(res => {
        _this3.notificationsActivity = res;
        console.log(res);
      });
    })();
  }

  show_details(data) {
    console.log(data);
    this.route.navigate(['/activity-details'], {
      state: {
        data: data
      }
    });
  }

  get_appData() {
    var _this4 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this4.apiCall.api_getActivity(_this4.uid);
      yield _this4.apiCall.api_myparticipantActivity(_this4.uid);
      yield _this4.apiCall.api_getallfilterActivity(); // await this.apiCall.api_getpeopleForChat();
    })();
  } // navigation


  notification() {
    this.getAllActivity();
    this.get_appData();
    this.route.navigate(['/tabs/notification']);
  }

  profile() {
    this.route.navigate(['/tabs/profile']);
  } // show activity details
  // show_details(data){
  //   this.route.navigate(['/tabs/activity-details']);
  //   this.global.set_activity_details(data);
  // }
  // Map Function


  ionViewDidEnter() {
    this.createMap();
    this.getLocationDistances();
  }

  postLocation() {
    var _this5 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this5.apiCall.api_postLocation(_this5.userlocation);
    })();
  }

  createMap() {// const coordinates = await Geolocation.getCurrentPosition();
    // console.log('Current position:', coordinates);
    // this.getAllActivity();
    // this.get_appData();
    // // Get Current Locations
    // await this.getLocation();
    // // Create Map
    // const mapRef = document.getElementById('my-cool-map');
    // this.newMap = await GoogleMap.create({
    //   id: 'my-cool-map',
    //   element: this.mapRef.nativeElement,
    //   apiKey: environment.mapsKey,
    //   config: {
    //     center: {
    //       lat: coordinates.coords.latitude,
    //       lng: coordinates.coords.longitude,
    //     },
    //     zoom: 15,
    //   }
    // });
    // await this.newMap.enableClustering();
    // // Add Markers
    // this.newMap.addMarkers([
    //   {
    //     coordinate:{
    //       lat: coordinates.coords.latitude,
    //       lng: coordinates.coords.longitude
    //     },
    //     title:this.userName,
    //     snippet:"Zagham",
    //     iconUrl: "https://turbonowpk.com/activity/images/2211011667330422.8122.jpg",
    //     iconSize: {
    //       width: 40,
    //       height:36
    //     },
    //     iconAnchor: {
    //       x: 5,
    //       y: 5
    //     }
    //   }
    // ])
    // for(let i=0; i<this.notificationsActivity.length; i++) {
    //   console.log(this.notificationsActivity[i]);
    //   console.log(`${this.notificationsActivity[i].lng}`);
    //   const x = this.notificationsActivity[i].lng
    //   const lat:number =  +x;
    //   const y = this.notificationsActivity[i].lat
    //   const lng = +y;
    //   console.log(lat, lng)
    //   this.newMap.addMarkers([
    //     {
    //       coordinate:{
    //         lat: lat,
    //         lng: lng
    //       },
    //       title:this.notificationsActivity[i].name,
    //       snippet:"Zagham",
    //       iconUrl: "this.notificationsActivity[i].a_image",
    //       iconSize: {
    //         width: 40,
    //         height:36
    //       }
    //     }
    //   ])
    // }
    //  await this.newMap.setOnMarkerClickListener(async (marker) => {
    //   console.log(marker);
    //  });
    // await this.newMap.setOnMapClickListener(async (marker) => {
    //   console.log(marker)
    // })

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {})();
  } // GeoLocation


  getLocation() {
    var _this6 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      _this6.coordinates = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_8__.Geolocation.getCurrentPosition();
      console.log('Current position:', _this6.coordinates.coords.latitude);
      console.log('Current position:', _this6.coordinates.coords.longitude);
      _this6.userlocation.lat = _this6.coordinates.coords.latitude;
      _this6.userlocation.lng = _this6.coordinates.coords.longitude;
      console.log(_this6.userlocation);

      _this6.postLocation();
    })();
  } // Get Distance


  getLocationDistances() {
    var _this7 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      for (let i = 0; i < _data_index__WEBPACK_IMPORTED_MODULE_5__.markers.length; i++) {
        const x = _this7.location.getDistanceFromLatLonInKm(_data_index__WEBPACK_IMPORTED_MODULE_5__.markers[0].lat, _data_index__WEBPACK_IMPORTED_MODULE_5__.markers[0].lng, _data_index__WEBPACK_IMPORTED_MODULE_5__.markers[1].lat, _data_index__WEBPACK_IMPORTED_MODULE_5__.markers[1].lng);

        console.log(x);
      }
    })();
  }

};

Tab1Page.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService
}, {
  type: _Services_locations_service__WEBPACK_IMPORTED_MODULE_6__.LocationsService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__.ApicallService
}, {
  type: src_app_Services_gmap_service__WEBPACK_IMPORTED_MODULE_7__.GmapsService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.Renderer2
}];

Tab1Page.propDecorators = {
  mapElementRef: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.ViewChild,
    args: ['map', {
      static: true
    }]
  }],
  mapRef: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.ViewChild,
    args: ['map']
  }]
};
Tab1Page = (0,tslib__WEBPACK_IMPORTED_MODULE_12__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
  selector: 'app-tab1',
  template: _tab1_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_tab1_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], Tab1Page);


/***/ }),

/***/ 591:
/*!*********************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/definitions.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 7621:
/*!***************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Geolocation": () => (/* binding */ Geolocation)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 591);

const Geolocation = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Geolocation', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_geolocation_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 8391)).then(m => new m.GeolocationWeb())
});



/***/ }),

/***/ 5398:
/*!*****************************************************************!*\
  !*** ./node_modules/rxjs/_esm2015/internal/observable/timer.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "timer": () => (/* binding */ timer)
/* harmony export */ });
/* harmony import */ var _Observable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Observable */ 2378);
/* harmony import */ var _scheduler_async__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../scheduler/async */ 328);
/* harmony import */ var _util_isNumeric__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util/isNumeric */ 7269);
/* harmony import */ var _util_isScheduler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util/isScheduler */ 7507);




function timer(dueTime = 0, periodOrScheduler, scheduler) {
  let period = -1;

  if ((0,_util_isNumeric__WEBPACK_IMPORTED_MODULE_0__.isNumeric)(periodOrScheduler)) {
    period = Number(periodOrScheduler) < 1 && 1 || Number(periodOrScheduler);
  } else if ((0,_util_isScheduler__WEBPACK_IMPORTED_MODULE_1__.isScheduler)(periodOrScheduler)) {
    scheduler = periodOrScheduler;
  }

  if (!(0,_util_isScheduler__WEBPACK_IMPORTED_MODULE_1__.isScheduler)(scheduler)) {
    scheduler = _scheduler_async__WEBPACK_IMPORTED_MODULE_2__.async;
  }

  return new _Observable__WEBPACK_IMPORTED_MODULE_3__.Observable(subscriber => {
    const due = (0,_util_isNumeric__WEBPACK_IMPORTED_MODULE_0__.isNumeric)(dueTime) ? dueTime : +dueTime - scheduler.now();
    return scheduler.schedule(dispatch, due, {
      index: 0,
      period,
      subscriber
    });
  });
}

function dispatch(state) {
  const {
    index,
    period,
    subscriber
  } = state;
  subscriber.next(index);

  if (subscriber.closed) {
    return;
  } else if (period === -1) {
    return subscriber.complete();
  }

  state.index = index + 1;
  this.schedule(state, period);
}

/***/ }),

/***/ 8165:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-header ion-toolbar .head_align {\n  display: flex;\n  justify-content: space-between;\n}\nion-header ion-toolbar .head_align .head_align_left {\n  margin-left: 10px;\n}\nion-header ion-toolbar .head_align .head_align_right {\n  width: 100px;\n  display: flex;\n  justify-content: space-around;\n  align-items: center;\n}\n.my_class1 {\n  --background: none;\n  --ion-background-color: none;\n}\n.my_class2 {\n  --background: white;\n  --ion-background-color: white;\n  background-color: white;\n}\nion-segment {\n  width: 184px;\n  height: 40px;\n  display: flex;\n  border-radius: 100px;\n  background: white;\n  box-shadow: 0px 0px 12px -6px rgba(0, 0, 0, 0.66);\n  -moz-box-shadow: 0px 0px 12px -6px rgba(0, 0, 0, 0.66);\n  margin: 0 auto;\n  position: absolute;\n  top: 17px;\n  left: 70px;\n  right: 70px;\n  z-index: 1;\n  background-color: white;\n}\nion-segment ion-segment-button {\n  --border-radius: 100px;\n  --indicator-color: #F2910C;\n  --color-checked: white;\n}\nion-list {\n  width: 100%;\n  height: 100%;\n  padding: 0;\n}\n.map-container {\n  background: none;\n  --ion-background-color: none;\n}\nion-row {\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  position: absolute;\n  top: 68px;\n  padding: 5px;\n}\nion-row ion-col {\n  max-width: 382px !important;\n  min-height: 99px;\n  display: flex;\n  align-items: flex-start;\n  align-content: space-between;\n  justify-content: space-between;\n  margin: 0px 5px 27px 5px;\n  padding: 0;\n  box-shadow: 2px 4px 5px rgba(0, 0, 0, 0.1607843137);\n  border-radius: 10px;\n}\nion-row ion-col .user_img {\n  border: 2px solid #17A525;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 14px;\n  padding: 1px;\n  width: 50px;\n  height: 50px;\n  margin: 15px 0px 0px 5px;\n}\nion-row ion-col .user_img .userimg {\n  height: 100%;\n  width: 100%;\n  border-radius: 14px;\n}\nion-row ion-col .m-1 {\n  margin: 3.5px 0px;\n}\nion-row ion-col .m-2 {\n  margin: 15px 0px 0px 5px;\n}\nion-row ion-col .title {\n  font-size: 13px;\n}\nion-row ion-col .subtitle {\n  font-size: 9px;\n}\nion-row ion-col .short_des {\n  width: 215px;\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\nion-row ion-col .location_img {\n  width: 86px;\n  height: 99px;\n  display: flex;\n}\nion-row ion-col .location_img .a {\n  height: 100%;\n  width: 100%;\n  object-fit: cover;\n  object-position: -5px 0px;\n  border-radius: 0px 10px 10px 0px;\n}\n.icon {\n  font-size: 22px;\n  margin-right: 24px;\n}\n.img {\n  width: 35px;\n  height: 35px;\n  border: 1px solid;\n  padding: 2px;\n  border-radius: 100%;\n}\ncapacitor-google-maps::ng-deep {\n  display: inline-block;\n  width: 100%;\n  height: 100%;\n}\ncapacitor-google-maps::ng-deep div[class=gmnoprint] {\n  top: -200px;\n}\ncapacitor-google-maps::ng-deep button[draggable=false] {\n  height: 0px !important;\n  width: 0px !important;\n}\ncapacitor-google-maps::ng-deep div[role=button] {\n  background-image: url('markerTag.png');\n  z-index: 10;\n  background-size: 58px 72px;\n  background-repeat: no-repeat;\n  height: 118px !important;\n  width: 300px !important;\n}\ncapacitor-google-maps::ng-deep div[role=button].img {\n  border-radius: 100%;\n}\ncapacitor-google-maps::ng-deep .gmnoprint {\n  top: -518px;\n}\n:host ::ng-deep capacitor-google-maps {\n  display: inline-block;\n  width: 100%;\n  height: 100%;\n}\n:host ::ng-deep capacitor-google-maps div[class=gmnoprint] {\n  top: -200px;\n}\n:host ::ng-deep capacitor-google-maps button[draggable=false] {\n  height: 0px !important;\n  width: 0px !important;\n}\n:host ::ng-deep capacitor-google-maps div[role=button] {\n  background-image: url('markerTag.png');\n  z-index: 10;\n  background-size: 58px 72px;\n  background-repeat: no-repeat;\n  height: 118px !important;\n  width: 300px !important;\n}\n:host ::ng-deep capacitor-google-maps div[role=button].img {\n  border-radius: 100%;\n}\n:host ::ng-deep capacitor-google-maps .gmnoprint {\n  top: -518px;\n}\n.gmnoprint {\n  margin: 10px;\n  z-index: 0;\n  position: absolute;\n  cursor: pointer;\n  left: 0px;\n  top: -61px;\n}\n.img2 {\n  width: 100%;\n  border-radius: 100%;\n  height: -webkit-fill-available;\n}\n.map {\n  position: absolute;\n  height: 100%;\n  width: 100%;\n  background-color: transparent;\n  opacity: 0;\n  transition: opacity 150ms ease-in;\n}\n.map.visible {\n  opacity: 1;\n}\n.map::ng-deep {\n  display: inline-block;\n  width: 100%;\n  height: 100%;\n}\n.map::ng-deep div[class=gmnoprint] {\n  top: -200px;\n}\n.map::ng-deep button[draggable=false] {\n  height: 0px !important;\n  width: 0px !important;\n}\n.map::ng-deep div[role=button] {\n  background-image: url('markerTag.png');\n  z-index: 10;\n  background-size: 68px 97px;\n  background-repeat: no-repeat;\n  height: 118px !important;\n  width: 300px !important;\n}\n.map::ng-deep div[role=button] div[tabindex=\"-1\"] {\n  background-image: none;\n  z-index: 10;\n  background-size: 68px 97px;\n  background-repeat: no-repeat;\n  height: 118px !important;\n  width: 300px !important;\n}\n.map::ng-deep div[tabindex=\"-1\"] {\n  background-image: url('markerTag.png');\n  z-index: 10;\n  background-size: 68px 97px;\n  background-repeat: no-repeat;\n  height: 118px !important;\n  width: 300px !important;\n}\n.map::ng-deep div[role=button].img {\n  border-radius: 100%;\n}\n.map::ng-deep div[role=button].img img[draggable=false] {\n  border-radius: 100%;\n}\n.map::ng-deep .gmnoprint {\n  top: -518px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRhYjEucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcRml2ZXIlMjBPcmRlcnNcXEFjdGl2aXR5XFxhY3Rpdml0eS1hcHBcXHNyY1xcYXBwXFx0YWIxXFx0YWIxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJUTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtBQ0haO0FES1k7RUFDSSxpQkFBQTtBQ0hoQjtBRFVZO0VBQ0ksWUFBQTtFQUNBLGFBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0FDUmhCO0FEZUE7RUFDRyxrQkFBQTtFQUNBLDRCQUFBO0FDWkg7QURjQTtFQUNHLG1CQUFBO0VBQ0EsNkJBQUE7RUFDQSx1QkFBQTtBQ1hIO0FEY0E7RUFDSSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaURBQUE7RUFDQSxzREFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSx1QkFBQTtBQ1hKO0FEYUk7RUFDSSxzQkFBQTtFQUNBLDBCQUFBO0VBQ0Esc0JBQUE7QUNYUjtBRGdCQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtBQ2JKO0FEZUE7RUFDRSxnQkFBQTtFQUNBLDRCQUFBO0FDWkY7QURlQTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0FDWko7QURjSTtFQUNJLDJCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSw0QkFBQTtFQUNBLDhCQUFBO0VBQ0Esd0JBQUE7RUFDQSxVQUFBO0VBQ0EsbURBQUE7RUFDQSxtQkFBQTtBQ1pSO0FEY1E7RUFDSSx5QkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx3QkFBQTtBQ1paO0FEYVk7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FDWGhCO0FEZVE7RUFDSSxpQkFBQTtBQ2JaO0FEZ0JRO0VBQ0ksd0JBQUE7QUNkWjtBRGlCUTtFQUNJLGVBQUE7QUNmWjtBRGlCUTtFQUNJLGNBQUE7QUNmWjtBRGlCUTtFQUNJLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUNmWjtBRGlCUTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ2ZaO0FEaUJZO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0NBQUE7QUNmaEI7QUQwQkE7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7QUN2Qko7QUQ0QkE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FDekJKO0FEMkJBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ3hCSjtBRHlCSTtFQUNJLFdBQUE7QUN2QlI7QUR5Qkk7RUFDSSxzQkFBQTtFQUNBLHFCQUFBO0FDdkJSO0FEeUJJO0VBQ0ksc0NBQUE7RUFDQSxXQUFBO0VBQ0EsMEJBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0EsdUJBQUE7QUN2QlI7QUR5Qkk7RUFDSSxtQkFBQTtBQ3ZCUjtBRHlCSTtFQUNJLFdBQUE7QUN2QlI7QUQyQkE7RUFDSSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDeEJKO0FEeUJJO0VBQ0ksV0FBQTtBQ3ZCUjtBRHlCSTtFQUNJLHNCQUFBO0VBQ0EscUJBQUE7QUN2QlI7QUR5Qkk7RUFDSSxzQ0FBQTtFQUNBLFdBQUE7RUFDQSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtBQ3ZCUjtBRHlCSTtFQUNJLG1CQUFBO0FDdkJSO0FEeUJJO0VBQ0ksV0FBQTtBQ3ZCUjtBRDJCQTtFQUNJLFlBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUN4Qko7QUQwQkE7RUFDSSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtBQ3ZCSjtBRDhCQTtFQUNJLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSw2QkFBQTtFQUNBLFVBQUE7RUFDQSxpQ0FBQTtBQzNCSjtBRDhCRTtFQUNFLFVBQUE7QUMzQko7QUQ2QkU7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDMUJKO0FEMkJJO0VBQ0ksV0FBQTtBQ3pCUjtBRDJCSTtFQUNJLHNCQUFBO0VBQ0EscUJBQUE7QUN6QlI7QUQyQkk7RUFDSSxzQ0FBQTtFQUNBLFdBQUE7RUFDQSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtBQ3pCUjtBRDBCUTtFQUNJLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLDBCQUFBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtFQUNBLHVCQUFBO0FDeEJaO0FEMkJJO0VBQ0ksc0NBQUE7RUFDQSxXQUFBO0VBQ0EsMEJBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0EsdUJBQUE7QUN6QlI7QUQyQkk7RUFDSSxtQkFBQTtBQ3pCUjtBRDBCUTtFQUNJLG1CQUFBO0FDeEJaO0FEMkJJO0VBQ0ksV0FBQTtBQ3pCUiIsImZpbGUiOiJ0YWIxLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG5cclxuICAgIGlvbi10b29sYmFyIHtcclxuXHJcbiAgICAgICAgLmhlYWRfYWxpZ24ge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblxyXG4gICAgICAgICAgICAuaGVhZF9hbGlnbl9sZWZ0IHtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgLy8gZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgICAgIC8vIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gICAgICAgICAgICAgICAgLy8gd2lkdGg6IDE4N3B4O1xyXG4gICAgICAgICAgICAgICAgLy8gYWxpZ24taXRlbXM6IGNlbnRlclxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuaGVhZF9hbGlnbl9yaWdodCB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLm15X2NsYXNzMXtcclxuICAgLS1iYWNrZ3JvdW5kOiBub25lO1xyXG4gICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBub25lO1xyXG4gfVxyXG4ubXlfY2xhc3Mye1xyXG4gICAtLWJhY2tncm91bmQ6IHdoaXRlO1xyXG4gICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiB9XHJcblxyXG5pb24tc2VnbWVudCB7XHJcbiAgICB3aWR0aDogMTg0cHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTJweCAtNnB4IHJnYigwIDAgMCAvIDY2JSk7XHJcbiAgICAtbW96LWJveC1zaGFkb3c6IDBweCAwcHggMTJweCAtNnB4IHJnYmEoMCwgMCwgMCwgMC42Nik7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMTdweDtcclxuICAgIGxlZnQ6IDcwcHg7XHJcbiAgICByaWdodDogNzBweDtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuXHJcbiAgICBpb24tc2VnbWVudC1idXR0b24ge1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbiAgICAgICAgLS1pbmRpY2F0b3ItY29sb3I6ICNGMjkxMEM7XHJcbiAgICAgICAgLS1jb2xvci1jaGVja2VkOiB3aGl0ZTtcclxuXHJcbiAgICB9XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgcGFkZGluZzogMDtcclxufVxyXG4ubWFwLWNvbnRhaW5lcntcclxuICBiYWNrZ3JvdW5kOiBub25lO1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IG5vbmU7XHJcbn1cclxuXHJcbmlvbi1yb3cge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDY4cHg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcblxyXG4gICAgaW9uLWNvbCB7XHJcbiAgICAgICAgbWF4LXdpZHRoOiAzODJweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IDk5cHg7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAgICAgICBhbGlnbi1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICBtYXJnaW46IDBweCA1cHggMjdweCA1cHg7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBib3gtc2hhZG93OiAycHggNHB4IDVweCAjMDAwMDAwMjk7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuXHJcbiAgICAgICAgLnVzZXJfaW1nIHtcclxuICAgICAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzE3QTUyNTtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDE0cHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDFweDtcclxuICAgICAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogNTBweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAxNXB4IDBweCAwcHggNXB4O1xyXG4gICAgICAgICAgICAudXNlcmltZ3tcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLm0tMSB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMy41cHggMHB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLm0tMiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMTVweCAwcHggMHB4IDVweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC50aXRsZSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnN1YnRpdGxlIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiA5cHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5zaG9ydF9kZXN7XHJcbiAgICAgICAgICAgIHdpZHRoOiAyMTVweDtcclxuICAgICAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgICAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICAgICAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5sb2NhdGlvbl9pbWcge1xyXG4gICAgICAgICAgICB3aWR0aDogODZweDtcclxuICAgICAgICAgICAgaGVpZ2h0OiA5OXB4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG5cclxuICAgICAgICAgICAgLmF7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICAgICAgICAgICAgb2JqZWN0LXBvc2l0aW9uOiAtNXB4IDBweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDBweCAxMHB4IDEwcHggMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbn1cclxuXHJcblxyXG5cclxuXHJcbi5pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgIG1hcmdpbi1yaWdodDogMjRweDtcclxufVxyXG5cclxuXHJcblxyXG4uaW1nIHtcclxuICAgIHdpZHRoOiAzNXB4O1xyXG4gICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQ7XHJcbiAgICBwYWRkaW5nOiAycHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG59XHJcbmNhcGFjaXRvci1nb29nbGUtbWFwczo6bmctZGVlcCB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGRpdltjbGFzcz1cImdtbm9wcmludFwiXSB7XHJcbiAgICAgICAgdG9wOiAtMjAwcHg7XHJcbiAgICB9XHJcbiAgICBidXR0b25bZHJhZ2dhYmxlPVwiZmFsc2VcIl0ge1xyXG4gICAgICAgIGhlaWdodDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgd2lkdGg6IDBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgZGl2W3JvbGU9XCJidXR0b25cIl0ge1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vLi4vLi4vYXNzZXRzL21hcC1pY29uL21hcmtlclRhZy5wbmdcIik7XHJcbiAgICAgICAgei1pbmRleDogMTA7XHJcbiAgICAgICAgYmFja2dyb3VuZC1zaXplOiA1OHB4IDcycHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgICAgICBoZWlnaHQ6IDExOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgd2lkdGg6IDMwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICBkaXZbcm9sZT1cImJ1dHRvblwiXS5pbWcge1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICB9XHJcbiAgICAuZ21ub3ByaW50IHtcclxuICAgICAgICB0b3A6IC01MThweDtcclxuICAgIH1cclxufVxyXG4vLyBIb3N0XHJcbjpob3N0IDo6bmctZGVlcCBjYXBhY2l0b3ItZ29vZ2xlLW1hcHMge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBkaXZbY2xhc3M9XCJnbW5vcHJpbnRcIl0ge1xyXG4gICAgICAgIHRvcDogLTIwMHB4O1xyXG4gICAgfVxyXG4gICAgYnV0dG9uW2RyYWdnYWJsZT1cImZhbHNlXCJdIHtcclxuICAgICAgICBoZWlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHdpZHRoOiAwcHggIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgIGRpdltyb2xlPVwiYnV0dG9uXCJdIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLy4uLy4uL2Fzc2V0cy9tYXAtaWNvbi9tYXJrZXJUYWcucG5nXCIpO1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogNThweCA3MnB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgaGVpZ2h0OiAxMThweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHdpZHRoOiAzMDBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgZGl2W3JvbGU9XCJidXR0b25cIl0uaW1nIHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgLmdtbm9wcmludCB7XHJcbiAgICAgICAgdG9wOiAtNTE4cHg7XHJcbiAgICB9XHJcbn1cclxuLy8gTWFwcyBDdXRvbXNcclxuLmdtbm9wcmludCB7XHJcbiAgICBtYXJnaW46IDEwcHg7XHJcbiAgICB6LWluZGV4OiAwO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgbGVmdDogMHB4O1xyXG4gICAgdG9wOiAtNjFweDtcclxufVxyXG4uaW1nMntcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgIGhlaWdodDogLXdlYmtpdC1maWxsLWF2YWlsYWJsZTtcclxufVxyXG4vL2lvbi1saXN0IHtcclxuLy8gICAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcclxuLy99XHJcblxyXG5cclxuLm1hcCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgb3BhY2l0eTogMDtcclxuICAgIHRyYW5zaXRpb246IG9wYWNpdHkgMTUwbXMgZWFzZS1pbjtcclxuICB9XHJcbiAgXHJcbiAgLm1hcC52aXNpYmxlIHtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgfVxyXG4gIC5tYXA6Om5nLWRlZXAge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBkaXZbY2xhc3M9XCJnbW5vcHJpbnRcIl0ge1xyXG4gICAgICAgIHRvcDogLTIwMHB4O1xyXG4gICAgfVxyXG4gICAgYnV0dG9uW2RyYWdnYWJsZT1cImZhbHNlXCJdIHtcclxuICAgICAgICBoZWlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHdpZHRoOiAwcHggIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgIGRpdltyb2xlPVwiYnV0dG9uXCJdIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLy4uLy4uL2Fzc2V0cy9tYXAtaWNvbi9tYXJrZXJUYWcucG5nXCIpO1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogNjhweCA5N3B4O1xyXG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgaGVpZ2h0OiAxMThweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHdpZHRoOiAzMDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGRpdlt0YWJpbmRleD1cIi0xXCJdIHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcclxuICAgICAgICAgICAgei1pbmRleDogMTA7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtc2l6ZTogNjhweCA5N3B4O1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDExOHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIHdpZHRoOiAzMDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGRpdlt0YWJpbmRleD1cIi0xXCJdIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLy4uLy4uL2Fzc2V0cy9tYXAtaWNvbi9tYXJrZXJUYWcucG5nXCIpO1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogNjhweCA5N3B4O1xyXG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgaGVpZ2h0OiAxMThweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHdpZHRoOiAzMDBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgZGl2W3JvbGU9XCJidXR0b25cIl0uaW1nIHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgICAgIGltZ1tkcmFnZ2FibGU9XCJmYWxzZVwiXSB7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmdtbm9wcmludCB7XHJcbiAgICAgICAgdG9wOiAtNTE4cHg7XHJcbiAgICB9XHJcbn0iLCJpb24taGVhZGVyIGlvbi10b29sYmFyIC5oZWFkX2FsaWduIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xufVxuaW9uLWhlYWRlciBpb24tdG9vbGJhciAuaGVhZF9hbGlnbiAuaGVhZF9hbGlnbl9sZWZ0IHtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG59XG5pb24taGVhZGVyIGlvbi10b29sYmFyIC5oZWFkX2FsaWduIC5oZWFkX2FsaWduX3JpZ2h0IHtcbiAgd2lkdGg6IDEwMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLm15X2NsYXNzMSB7XG4gIC0tYmFja2dyb3VuZDogbm9uZTtcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjogbm9uZTtcbn1cblxuLm15X2NsYXNzMiB7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbn1cblxuaW9uLXNlZ21lbnQge1xuICB3aWR0aDogMTg0cHg7XG4gIGhlaWdodDogNDBweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYm9yZGVyLXJhZGl1czogMTAwcHg7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xuICBib3gtc2hhZG93OiAwcHggMHB4IDEycHggLTZweCByZ2JhKDAsIDAsIDAsIDAuNjYpO1xuICAtbW96LWJveC1zaGFkb3c6IDBweCAwcHggMTJweCAtNnB4IHJnYmEoMCwgMCwgMCwgMC42Nik7XG4gIG1hcmdpbjogMCBhdXRvO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMTdweDtcbiAgbGVmdDogNzBweDtcbiAgcmlnaHQ6IDcwcHg7XG4gIHotaW5kZXg6IDE7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xufVxuaW9uLXNlZ21lbnQgaW9uLXNlZ21lbnQtYnV0dG9uIHtcbiAgLS1ib3JkZXItcmFkaXVzOiAxMDBweDtcbiAgLS1pbmRpY2F0b3ItY29sb3I6ICNGMjkxMEM7XG4gIC0tY29sb3ItY2hlY2tlZDogd2hpdGU7XG59XG5cbmlvbi1saXN0IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgcGFkZGluZzogMDtcbn1cblxuLm1hcC1jb250YWluZXIge1xuICBiYWNrZ3JvdW5kOiBub25lO1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBub25lO1xufVxuXG5pb24tcm93IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNjhweDtcbiAgcGFkZGluZzogNXB4O1xufVxuaW9uLXJvdyBpb24tY29sIHtcbiAgbWF4LXdpZHRoOiAzODJweCAhaW1wb3J0YW50O1xuICBtaW4taGVpZ2h0OiA5OXB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgYWxpZ24tY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBtYXJnaW46IDBweCA1cHggMjdweCA1cHg7XG4gIHBhZGRpbmc6IDA7XG4gIGJveC1zaGFkb3c6IDJweCA0cHggNXB4IHJnYmEoMCwgMCwgMCwgMC4xNjA3ODQzMTM3KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAudXNlcl9pbWcge1xuICBib3JkZXI6IDJweCBzb2xpZCAjMTdBNTI1O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMTRweDtcbiAgcGFkZGluZzogMXB4O1xuICB3aWR0aDogNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xuICBtYXJnaW46IDE1cHggMHB4IDBweCA1cHg7XG59XG5pb24tcm93IGlvbi1jb2wgLnVzZXJfaW1nIC51c2VyaW1nIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXJhZGl1czogMTRweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAubS0xIHtcbiAgbWFyZ2luOiAzLjVweCAwcHg7XG59XG5pb24tcm93IGlvbi1jb2wgLm0tMiB7XG4gIG1hcmdpbjogMTVweCAwcHggMHB4IDVweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAudGl0bGUge1xuICBmb250LXNpemU6IDEzcHg7XG59XG5pb24tcm93IGlvbi1jb2wgLnN1YnRpdGxlIHtcbiAgZm9udC1zaXplOiA5cHg7XG59XG5pb24tcm93IGlvbi1jb2wgLnNob3J0X2RlcyB7XG4gIHdpZHRoOiAyMTVweDtcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG59XG5pb24tcm93IGlvbi1jb2wgLmxvY2F0aW9uX2ltZyB7XG4gIHdpZHRoOiA4NnB4O1xuICBoZWlnaHQ6IDk5cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG5pb24tcm93IGlvbi1jb2wgLmxvY2F0aW9uX2ltZyAuYSB7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIG9iamVjdC1maXQ6IGNvdmVyO1xuICBvYmplY3QtcG9zaXRpb246IC01cHggMHB4O1xuICBib3JkZXItcmFkaXVzOiAwcHggMTBweCAxMHB4IDBweDtcbn1cblxuLmljb24ge1xuICBmb250LXNpemU6IDIycHg7XG4gIG1hcmdpbi1yaWdodDogMjRweDtcbn1cblxuLmltZyB7XG4gIHdpZHRoOiAzNXB4O1xuICBoZWlnaHQ6IDM1cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkO1xuICBwYWRkaW5nOiAycHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG59XG5cbmNhcGFjaXRvci1nb29nbGUtbWFwczo6bmctZGVlcCB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cbmNhcGFjaXRvci1nb29nbGUtbWFwczo6bmctZGVlcCBkaXZbY2xhc3M9Z21ub3ByaW50XSB7XG4gIHRvcDogLTIwMHB4O1xufVxuY2FwYWNpdG9yLWdvb2dsZS1tYXBzOjpuZy1kZWVwIGJ1dHRvbltkcmFnZ2FibGU9ZmFsc2VdIHtcbiAgaGVpZ2h0OiAwcHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuY2FwYWNpdG9yLWdvb2dsZS1tYXBzOjpuZy1kZWVwIGRpdltyb2xlPWJ1dHRvbl0ge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLy4uLy4uL2Fzc2V0cy9tYXAtaWNvbi9tYXJrZXJUYWcucG5nXCIpO1xuICB6LWluZGV4OiAxMDtcbiAgYmFja2dyb3VuZC1zaXplOiA1OHB4IDcycHg7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGhlaWdodDogMTE4cHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDMwMHB4ICFpbXBvcnRhbnQ7XG59XG5jYXBhY2l0b3ItZ29vZ2xlLW1hcHM6Om5nLWRlZXAgZGl2W3JvbGU9YnV0dG9uXS5pbWcge1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuY2FwYWNpdG9yLWdvb2dsZS1tYXBzOjpuZy1kZWVwIC5nbW5vcHJpbnQge1xuICB0b3A6IC01MThweDtcbn1cblxuOmhvc3QgOjpuZy1kZWVwIGNhcGFjaXRvci1nb29nbGUtbWFwcyB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbn1cbjpob3N0IDo6bmctZGVlcCBjYXBhY2l0b3ItZ29vZ2xlLW1hcHMgZGl2W2NsYXNzPWdtbm9wcmludF0ge1xuICB0b3A6IC0yMDBweDtcbn1cbjpob3N0IDo6bmctZGVlcCBjYXBhY2l0b3ItZ29vZ2xlLW1hcHMgYnV0dG9uW2RyYWdnYWJsZT1mYWxzZV0ge1xuICBoZWlnaHQ6IDBweCAhaW1wb3J0YW50O1xuICB3aWR0aDogMHB4ICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgY2FwYWNpdG9yLWdvb2dsZS1tYXBzIGRpdltyb2xlPWJ1dHRvbl0ge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLy4uLy4uL2Fzc2V0cy9tYXAtaWNvbi9tYXJrZXJUYWcucG5nXCIpO1xuICB6LWluZGV4OiAxMDtcbiAgYmFja2dyb3VuZC1zaXplOiA1OHB4IDcycHg7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGhlaWdodDogMTE4cHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDMwMHB4ICFpbXBvcnRhbnQ7XG59XG46aG9zdCA6Om5nLWRlZXAgY2FwYWNpdG9yLWdvb2dsZS1tYXBzIGRpdltyb2xlPWJ1dHRvbl0uaW1nIHtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbn1cbjpob3N0IDo6bmctZGVlcCBjYXBhY2l0b3ItZ29vZ2xlLW1hcHMgLmdtbm9wcmludCB7XG4gIHRvcDogLTUxOHB4O1xufVxuXG4uZ21ub3ByaW50IHtcbiAgbWFyZ2luOiAxMHB4O1xuICB6LWluZGV4OiAwO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgbGVmdDogMHB4O1xuICB0b3A6IC02MXB4O1xufVxuXG4uaW1nMiB7XG4gIHdpZHRoOiAxMDAlO1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xuICBoZWlnaHQ6IC13ZWJraXQtZmlsbC1hdmFpbGFibGU7XG59XG5cbi5tYXAge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGhlaWdodDogMTAwJTtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICBvcGFjaXR5OiAwO1xuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDE1MG1zIGVhc2UtaW47XG59XG5cbi5tYXAudmlzaWJsZSB7XG4gIG9wYWNpdHk6IDE7XG59XG5cbi5tYXA6Om5nLWRlZXAge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG59XG4ubWFwOjpuZy1kZWVwIGRpdltjbGFzcz1nbW5vcHJpbnRdIHtcbiAgdG9wOiAtMjAwcHg7XG59XG4ubWFwOjpuZy1kZWVwIGJ1dHRvbltkcmFnZ2FibGU9ZmFsc2VdIHtcbiAgaGVpZ2h0OiAwcHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDBweCAhaW1wb3J0YW50O1xufVxuLm1hcDo6bmctZGVlcCBkaXZbcm9sZT1idXR0b25dIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi8uLi8uLi9hc3NldHMvbWFwLWljb24vbWFya2VyVGFnLnBuZ1wiKTtcbiAgei1pbmRleDogMTA7XG4gIGJhY2tncm91bmQtc2l6ZTogNjhweCA5N3B4O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBoZWlnaHQ6IDExOHB4ICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAzMDBweCAhaW1wb3J0YW50O1xufVxuLm1hcDo6bmctZGVlcCBkaXZbcm9sZT1idXR0b25dIGRpdlt0YWJpbmRleD1cIi0xXCJdIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogbm9uZTtcbiAgei1pbmRleDogMTA7XG4gIGJhY2tncm91bmQtc2l6ZTogNjhweCA5N3B4O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBoZWlnaHQ6IDExOHB4ICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAzMDBweCAhaW1wb3J0YW50O1xufVxuLm1hcDo6bmctZGVlcCBkaXZbdGFiaW5kZXg9XCItMVwiXSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vLi4vLi4vYXNzZXRzL21hcC1pY29uL21hcmtlclRhZy5wbmdcIik7XG4gIHotaW5kZXg6IDEwO1xuICBiYWNrZ3JvdW5kLXNpemU6IDY4cHggOTdweDtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgaGVpZ2h0OiAxMThweCAhaW1wb3J0YW50O1xuICB3aWR0aDogMzAwcHggIWltcG9ydGFudDtcbn1cbi5tYXA6Om5nLWRlZXAgZGl2W3JvbGU9YnV0dG9uXS5pbWcge1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuLm1hcDo6bmctZGVlcCBkaXZbcm9sZT1idXR0b25dLmltZyBpbWdbZHJhZ2dhYmxlPWZhbHNlXSB7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG59XG4ubWFwOjpuZy1kZWVwIC5nbW5vcHJpbnQge1xuICB0b3A6IC01MThweDtcbn0iXX0= */";

/***/ }),

/***/ 3852:
/*!************************************************!*\
  !*** ./src/app/tab1/tab1.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<!-- Head -->\r\n<ion-header>\r\n  <ion-toolbar>\r\n\r\n    <div class=\"head_align\">\r\n      <div class=\"head_align_left\">\r\n\r\n        <img src=\"../../assets/WhatsApp_Image_2022-05-10_at_8.12 3.png\" alt=\"\">\r\n\r\n      </div>\r\n      <div class=\"head_align_right\">\r\n        <ion-icon (click)=\"notification()\" name=\"notifications-outline\" class=\"icon\"></ion-icon>\r\n        <div class=\"img\" (click)=\"profile()\" >\r\n          <img class=\"img2\" src=\"{{this.Profile}}\" alt=\"\">\r\n        </div>\r\n\r\n      </div>\r\n    </div>\r\n\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n<ion-content  [ngClass]=\"selectTabs == 'map' ? 'my_class1' : 'my_class2'\" >\r\n\r\n  <!-- Segment -->\r\n  <div style=\"background-color: white;\">\r\n    <ion-segment [ngClass]=\"selectTabs == 'list' ? 'my_class1' : 'my_class2'\" [(ngModel)]=\"selectTabs\" mode=\"ios\" value=\"map\" (ionChange)=\"createMap()\" style=\"background-color: white;\">\r\n      <ion-segment-button value=\"map\">\r\n        <ion-label>Map</ion-label>\r\n      </ion-segment-button>\r\n      <ion-segment-button value=\"list\">\r\n        <ion-label>List</ion-label>\r\n      </ion-segment-button>\r\n    </ion-segment>\r\n  </div>\r\n\r\n  <!-- Map Segment -->\r\n  <ion-list class=\"map-container\" >\r\n\r\n    <!-- Map -->\r\n    <div class=\"map\" #map></div>\r\n\r\n  </ion-list>\r\n\r\n  <!-- List Segment -->\r\n  <div *ngIf=\"selectTabs == 'list' \" style=\"background-color: white;\">\r\n\r\n    <!-- List data -->\r\n    <ion-row style=\"background-color: white;\">\r\n      <ion-col size=\"12\" size-md=\"5\" *ngFor=\"let data of notificationsActivity\" (click)=\"show_details(data)\">\r\n\r\n        <div class=\"user_img\">\r\n          <img class=\"userimg\" src=\"{{this.data.profile_img}}\" alt=\"\">\r\n        </div>\r\n\r\n        <div class=\"m-2\">\r\n          <p class=\"title m-1\"><b>{{this.data.activity_name}}</b></p>\r\n          <p class=\"subtitle m-1 short_des\">{{this.data.description}}</p>\r\n          <p class=\"subtitle m-1\" (click)=\"show_details(data)\"><b>view it</b></p>\r\n        </div>\r\n\r\n        <div class=\"location_img\">\r\n          <img class=\"a\" src=\"{{this.data.a_image}}\" alt=\"\">\r\n        </div>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </div>\r\n\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_tab1_tab1_module_ts.js.map