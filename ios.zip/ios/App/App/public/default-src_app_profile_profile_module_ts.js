"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_profile_profile_module_ts"],{

/***/ 6829:
/*!***************************************************!*\
  !*** ./src/app/profile/profile-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageRoutingModule": () => (/* binding */ ProfilePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile.page */ 2919);




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_0__.ProfilePage
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ 4523:
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePageModule": () => (/* binding */ ProfilePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./profile-routing.module */ 6829);
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page */ 2919);







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_0__.ProfilePageRoutingModule
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_1__.ProfilePage]
    })
], ProfilePageModule);



/***/ }),

/***/ 2919:
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ProfilePage": () => (/* binding */ ProfilePage)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./profile.page.html?ngResource */ 8907);
/* harmony import */ var _profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./profile.page.scss?ngResource */ 6611);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @capacitor/camera */ 4241);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Services/global.service */ 1307);









let ProfilePage = class ProfilePage {
  constructor(route, apiCall, router, global) {
    this.route = route;
    this.apiCall = apiCall;
    this.router = router;
    this.global = global;
    this.type = true;
    this.favourite = [{
      id: 1,
      user_img: '../../assets/Rectangle 142.png',
      fav_title: 'Beach Party',
      fav_des: 'Lets swimming together near a beach and play a volly ball with each other .',
      location_img: '../../assets/Rectangle 149.png'
    }, {
      id: 2,
      user_img: '../../assets/Rectangle 143.png',
      fav_title: 'Swimming Together',
      fav_des: 'Lets swimming together near a beach and play a volly ball with each other   .',
      location_img: '../../assets/Rectangle 149.png'
    }];
    this.profile_data = {
      u_id: '',
      name: '',
      img: '',
      bio: '',
      socialize_distance: ''
    };
  }

  ngOnInit() {
    this.getprofile();
  }

  getprofile() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this.global.Uid.subscribe(uid => {
        _this.apiCall.api_getprofile(uid);

        console.log(uid);
        _this.profile_data.u_id = uid;
      });

      _this.global.ProfileInfo.subscribe(res => {
        console.log(res);
        _this.profile_data = res[0];
        document.getElementById('cameraImage').setAttribute('src', _this.profile_data.img);
      });
    })();
  }

  ProfileUpdate() {
    console.log(this.profile_data);
    this.apiCall.api_updateprofile(this.profile_data);
  } //  switch between veiw and eidt profile


  allow() {
    this.type = !this.type;
  } // refer a friend


  refer() {
    console.log('refer');
  } // refer a friend


  log_out() {
    console.log('log out');
    const x = '';
    this.global.add_uid(x);
    console.log(x);
    this.route.navigate(['/login']);
  } // nav back to home  


  nav_back() {
    this.route.navigate(['/tabs/tab1']);
  } // get image


  capture_img() {
    var _this2 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const image = yield _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.Camera.getPhoto({
        quality: 90,
        resultType: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraResultType.Base64,
        source: _capacitor_camera__WEBPACK_IMPORTED_MODULE_3__.CameraSource.Prompt
      });
      document.getElementById('cameraImage').setAttribute('src', `data:image/${image.format};base64,` + image.base64String);
      console.log(image.base64String);
      _this2.profile_data.img = image.base64String;
    })();
  }

};

ProfilePage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_4__.ApicallService
}, {
  type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_5__.GlobalService
}];

ProfilePage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
  selector: 'app-profile',
  template: _profile_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_profile_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ProfilePage);


/***/ }),

/***/ 4830:
/*!****************************************************************!*\
  !*** ./node_modules/@capacitor/camera/dist/esm/definitions.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CameraDirection": () => (/* binding */ CameraDirection),
/* harmony export */   "CameraResultType": () => (/* binding */ CameraResultType),
/* harmony export */   "CameraSource": () => (/* binding */ CameraSource)
/* harmony export */ });
var CameraSource;

(function (CameraSource) {
  /**
   * Prompts the user to select either the photo album or take a photo.
   */
  CameraSource["Prompt"] = "PROMPT";
  /**
   * Take a new photo using the camera.
   */

  CameraSource["Camera"] = "CAMERA";
  /**
   * Pick an existing photo from the gallery or photo album.
   */

  CameraSource["Photos"] = "PHOTOS";
})(CameraSource || (CameraSource = {}));

var CameraDirection;

(function (CameraDirection) {
  CameraDirection["Rear"] = "REAR";
  CameraDirection["Front"] = "FRONT";
})(CameraDirection || (CameraDirection = {}));

var CameraResultType;

(function (CameraResultType) {
  CameraResultType["Uri"] = "uri";
  CameraResultType["Base64"] = "base64";
  CameraResultType["DataUrl"] = "dataUrl";
})(CameraResultType || (CameraResultType = {}));

/***/ }),

/***/ 4241:
/*!**********************************************************!*\
  !*** ./node_modules/@capacitor/camera/dist/esm/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Camera": () => (/* binding */ Camera),
/* harmony export */   "CameraDirection": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraDirection),
/* harmony export */   "CameraResultType": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraResultType),
/* harmony export */   "CameraSource": () => (/* reexport safe */ _definitions__WEBPACK_IMPORTED_MODULE_1__.CameraSource)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 4830);

const Camera = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Camera', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_camera_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 1327)).then(m => new m.CameraWeb())
});



/***/ }),

/***/ 6611:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = ".header {\n  margin-top: 35px;\n  display: flex;\n  align-items: center;\n}\n\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  margin-left: 10px;\n  height: 33px;\n  width: 33px;\n}\n\n.text {\n  margin: 0px;\n  text-align: center;\n  font-size: 18px;\n}\n\n.avatar {\n  height: 118px;\n  width: 118px;\n  margin: 35px auto 0px auto;\n}\n\n.name {\n  text-align: center;\n  font-size: 18px;\n  margin: 15px 0px 0px 0px;\n}\n\n.text2 {\n  text-align: center;\n  font-size: 15px;\n  margin: 8px 0px 0px 0px;\n}\n\n.range {\n  height: 64px;\n  max-width: 300px;\n  margin: auto;\n  margin-top: 33px;\n  border-radius: 10px;\n  box-shadow: 0px 1px 20px 19px whitesmoke;\n}\n\n.range p {\n  margin-left: 20px;\n}\n\n.activity {\n  max-width: 340px;\n  margin: auto;\n  margin-top: 25px;\n}\n\n.text3 {\n  margin: 0px;\n  font-size: 12px;\n}\n\n.text4 {\n  margin: 0px;\n  font-size: 9px;\n}\n\n.view {\n  margin: 34px 10px 0px 10px;\n  display: flex;\n  justify-content: center;\n  width: 100%;\n}\n\n.view ion-col {\n  max-width: 382px !important;\n  min-height: 99px;\n  display: flex;\n  align-items: flex-start;\n  align-content: space-between;\n  justify-content: space-between;\n  margin: 0px 5px 27px 5px;\n  padding: 0;\n  box-shadow: 2px 4px 5px rgba(0, 0, 0, 0.1607843137);\n  border-radius: 10px;\n}\n\n.view ion-col .user_img {\n  border: 2px solid #17A525;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 14px;\n}\n\n.view ion-col .m-1 {\n  margin: 3.5px 3px;\n}\n\n.view ion-col .m-2 {\n  margin: 15px 0px 0px 5px;\n}\n\n.view ion-col .title {\n  font-size: 13px;\n}\n\n.view ion-col .subtitle {\n  font-size: 9px;\n}\n\n.view ion-col .location_img {\n  height: 100%;\n  display: flex;\n}\n\n.refer_logut {\n  height: 60px;\n  max-width: 363px;\n  margin: 15px auto 23px auto;\n  border-radius: 10px;\n  box-shadow: 0px 1px 20px 19px whitesmoke;\n  display: flex;\n  align-items: center;\n  justify-content: space-around;\n}\n\n.refer_logut div {\n  text-align: left;\n  width: 65%;\n}\n\n.refer_logut div p {\n  font-size: 14px;\n  font-weight: 500;\n}\n\n.icon {\n  margin-top: 6px;\n}\n\nion-header ion-toolbar .w-1 {\n  width: 42px;\n}\n\nion-header ion-toolbar p {\n  margin: 0% auto;\n}\n\nion-input {\n  height: 55px;\n  max-width: 336px;\n  border: solid black 1px;\n  margin: auto;\n  border-radius: 50px;\n  font-size: 16px;\n  --padding-start: 20px;\n  --padding-end: 16px;\n  opacity: 1 !important;\n}\n\n.label {\n  font-size: 18px;\n  margin-bottom: 5px;\n  max-width: 324px;\n  border: solid black 1px;\n}\n\n.input1 {\n  font-size: 18px;\n  margin: 29px 0px 0px 0px;\n}\n\n.input2 {\n  font-size: 12px;\n  font-weight: bold;\n  margin: 10px;\n  opacity: 0.6;\n}\n\n.icon {\n  text-align: end;\n}\n\n.texxt {\n  margin: 0px;\n  opacity: 0.6;\n}\n\nion-button {\n  height: 60px;\n  max-width: 327px;\n  margin: auto;\n  color: white;\n  margin-bottom: 34px;\n  font-size: 18px;\n}\n\n.input_title {\n  max-width: 300px;\n  margin: auto auto 9px auto;\n}\n\n.capture_img {\n  width: 29px;\n  height: 29px;\n  transform: translate3d(84px, -35px, 10px);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInByb2ZpbGUucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcRml2ZXIlMjBPcmRlcnNcXEFjdGl2aXR5XFxhY3Rpdml0eS1hcHBcXHNyY1xcYXBwXFxwcm9maWxlXFxwcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNJLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FDQUo7O0FER0E7RUFDSSxtQkFBQTtFQUNBLHNDQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQ0FKOztBREdBO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQ0FKOztBREdBO0VBQ0ksYUFBQTtFQUNBLFlBQUE7RUFDQSwwQkFBQTtBQ0FKOztBREdBO0VBQ0ksa0JBQUE7RUFDQSxlQUFBO0VBQ0Esd0JBQUE7QUNBSjs7QURHQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0FDQUo7O0FESUE7RUFDSSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLHdDQUFBO0FDREo7O0FER0k7RUFDSSxpQkFBQTtBQ0RSOztBREtBO0VBQ0ksZ0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNGSjs7QURLQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0FDRko7O0FES0E7RUFDSSxXQUFBO0VBQ0EsY0FBQTtBQ0ZKOztBREtBO0VBQ0ksMEJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0FDRko7O0FETUk7RUFDSSwyQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsNEJBQUE7RUFDQSw4QkFBQTtFQUNBLHdCQUFBO0VBQ0EsVUFBQTtFQUNBLG1EQUFBO0VBQ0EsbUJBQUE7QUNKUjs7QURNUTtFQUNJLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQ0paOztBRE9RO0VBQ0ksaUJBQUE7QUNMWjs7QURRUTtFQUNJLHdCQUFBO0FDTlo7O0FEU1E7RUFFSSxlQUFBO0FDUlo7O0FEV1E7RUFDSSxjQUFBO0FDVFo7O0FEWVE7RUFDSSxZQUFBO0VBQ0EsYUFBQTtBQ1ZaOztBRGtCQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtFQUNBLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSx3Q0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0FDZko7O0FEaUJJO0VBQ0ksZ0JBQUE7RUFDQSxVQUFBO0FDZlI7O0FEaUJRO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0FDZlo7O0FEb0JBO0VBQ0ksZUFBQTtBQ2pCSjs7QUQ2QlE7RUFDSSxXQUFBO0FDMUJaOztBRDZCUTtFQUNJLGVBQUE7QUMzQlo7O0FEaUNBO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUVBLHFCQUFBO0FDL0JKOztBRG1DQTtFQUNJLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUNoQ0o7O0FEbUNBO0VBQ0ksZUFBQTtFQUNBLHdCQUFBO0FDaENKOztBRG9DQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FDakNKOztBRG9DQTtFQUNJLGVBQUE7QUNqQ0o7O0FEb0NBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNqQ0o7O0FEb0NBO0VBQ0ksWUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7QUNqQ0o7O0FEb0NBO0VBQ0ksZ0JBQUE7RUFDQSwwQkFBQTtBQ2pDSjs7QURvQ0E7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHlDQUFBO0FDakNKIiwiZmlsZSI6InByb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy92aWV3IHByb2ZpbGUgY3NzXHJcbi5oZWFkZXIge1xyXG4gICAgbWFyZ2luLXRvcDogMzVweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uYmFjay1idXR0b24ge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwJTtcclxuICAgIGJveC1zaGFkb3c6IDJweCAzcHggNXB4IDVweCB3aGl0ZXNtb2tlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICBoZWlnaHQ6IDMzcHg7XHJcbiAgICB3aWR0aDogMzNweDtcclxufVxyXG5cclxuLnRleHQge1xyXG4gICAgbWFyZ2luOiAwcHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuXHJcbi5hdmF0YXIge1xyXG4gICAgaGVpZ2h0OiAxMThweDtcclxuICAgIHdpZHRoOiAxMThweDtcclxuICAgIG1hcmdpbjogMzVweCBhdXRvIDBweCBhdXRvO1xyXG59XHJcblxyXG4ubmFtZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW46IDE1cHggMHB4IDBweCAwcHg7XHJcbn1cclxuXHJcbi50ZXh0MiB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBtYXJnaW46IDhweCAwcHggMHB4IDBweDtcclxuXHJcbn1cclxuXHJcbi5yYW5nZSB7XHJcbiAgICBoZWlnaHQ6IDY0cHg7XHJcbiAgICBtYXgtd2lkdGg6IDMwMHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDogMzNweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMXB4IDIwcHggMTlweCB3aGl0ZXNtb2tlO1xyXG5cclxuICAgIHAge1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgfVxyXG59XHJcblxyXG4uYWN0aXZpdHkge1xyXG4gICAgbWF4LXdpZHRoOiAzNDBweDtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIG1hcmdpbi10b3A6IDI1cHg7XHJcbn1cclxuXHJcbi50ZXh0MyB7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG5cclxuLnRleHQ0IHtcclxuICAgIG1hcmdpbjogMHB4O1xyXG4gICAgZm9udC1zaXplOiA5cHg7XHJcbn1cclxuXHJcbi52aWV3IHtcclxuICAgIG1hcmdpbjogMzRweCAxMHB4IDBweCAxMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcblxyXG5cclxuXHJcbiAgICBpb24tY29sIHtcclxuICAgICAgICBtYXgtd2lkdGg6IDM4MnB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgbWluLWhlaWdodDogOTlweDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgICAgIGFsaWduLWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIG1hcmdpbjogMHB4IDVweCAyN3B4IDVweDtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG4gICAgICAgIGJveC1zaGFkb3c6IDJweCA0cHggNXB4ICMwMDAwMDAyOTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5cclxuICAgICAgICAudXNlcl9pbWcge1xyXG4gICAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCAjMTdBNTI1O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTRweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5tLTEge1xyXG4gICAgICAgICAgICBtYXJnaW46IDMuNXB4IDNweDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5tLTIge1xyXG4gICAgICAgICAgICBtYXJnaW46IDE1cHggMHB4IDBweCA1cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAudGl0bGUge1xyXG5cclxuICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLnN1YnRpdGxlIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiA5cHg7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAubG9jYXRpb25faW1nIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG5cclxufVxyXG5cclxuLnJlZmVyX2xvZ3V0IHtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIG1heC13aWR0aDogMzYzcHg7XHJcbiAgICBtYXJnaW46IDE1cHggYXV0byAyM3B4IGF1dG87XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDFweCAyMHB4IDE5cHggd2hpdGVzbW9rZTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcblxyXG4gICAgZGl2IHtcclxuICAgICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gICAgICAgIHdpZHRoOiA2NSU7XHJcblxyXG4gICAgICAgIHAge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4uaWNvbiB7XHJcbiAgICBtYXJnaW4tdG9wOiA2cHg7XHJcbn1cclxuXHJcblxyXG5cclxuXHJcblxyXG4vLyBlZGl0IHByb2ZpbGUgY3NzXHJcbmlvbi1oZWFkZXIge1xyXG5cclxuICAgIGlvbi10b29sYmFyIHtcclxuXHJcbiAgICAgICAgLnctMSB7XHJcbiAgICAgICAgICAgIHdpZHRoOiA0MnB4O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcCB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMCUgYXV0bztcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5pb24taW5wdXQge1xyXG4gICAgaGVpZ2h0OiA1NXB4O1xyXG4gICAgbWF4LXdpZHRoOiAzMzZweDtcclxuICAgIGJvcmRlcjogc29saWQgYmxhY2sgMXB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMjBweDtcclxuICAgIC0tcGFkZGluZy1lbmQ6IDE2cHg7XHJcblxyXG4gICAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xyXG5cclxufVxyXG5cclxuLmxhYmVsIHtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuICAgIG1heC13aWR0aDogMzI0cHg7XHJcbiAgICBib3JkZXI6IHNvbGlkIGJsYWNrIDFweDtcclxufVxyXG5cclxuLmlucHV0MSB7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW46IDI5cHggMHB4IDBweCAwcHg7XHJcblxyXG59XHJcblxyXG4uaW5wdXQyIHtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgb3BhY2l0eTogMC42O1xyXG59XHJcblxyXG4uaWNvbiB7XHJcbiAgICB0ZXh0LWFsaWduOiBlbmQ7XHJcbn1cclxuXHJcbi50ZXh4dCB7XHJcbiAgICBtYXJnaW46IDBweDtcclxuICAgIG9wYWNpdHk6IDAuNjtcclxufVxyXG5cclxuaW9uLWJ1dHRvbiB7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgICBtYXgtd2lkdGg6IDMyN3B4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMzRweDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxufVxyXG5cclxuLmlucHV0X3RpdGxlIHtcclxuICAgIG1heC13aWR0aDogMzAwcHg7XHJcbiAgICBtYXJnaW46IGF1dG8gYXV0byA5cHggYXV0bztcclxufVxyXG5cclxuLmNhcHR1cmVfaW1nIHtcclxuICAgIHdpZHRoOiAyOXB4O1xyXG4gICAgaGVpZ2h0OiAyOXB4O1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCg4NHB4LCAtMzVweCwgMTBweCk7XHJcbn0iLCIuaGVhZGVyIHtcbiAgbWFyZ2luLXRvcDogMzVweDtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmJhY2stYnV0dG9uIHtcbiAgYm9yZGVyLXJhZGl1czogMTAwJTtcbiAgYm94LXNoYWRvdzogMnB4IDNweCA1cHggNXB4IHdoaXRlc21va2U7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBoZWlnaHQ6IDMzcHg7XG4gIHdpZHRoOiAzM3B4O1xufVxuXG4udGV4dCB7XG4gIG1hcmdpbjogMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLmF2YXRhciB7XG4gIGhlaWdodDogMTE4cHg7XG4gIHdpZHRoOiAxMThweDtcbiAgbWFyZ2luOiAzNXB4IGF1dG8gMHB4IGF1dG87XG59XG5cbi5uYW1lIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbjogMTVweCAwcHggMHB4IDBweDtcbn1cblxuLnRleHQyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXNpemU6IDE1cHg7XG4gIG1hcmdpbjogOHB4IDBweCAwcHggMHB4O1xufVxuXG4ucmFuZ2Uge1xuICBoZWlnaHQ6IDY0cHg7XG4gIG1heC13aWR0aDogMzAwcHg7XG4gIG1hcmdpbjogYXV0bztcbiAgbWFyZ2luLXRvcDogMzNweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYm94LXNoYWRvdzogMHB4IDFweCAyMHB4IDE5cHggd2hpdGVzbW9rZTtcbn1cbi5yYW5nZSBwIHtcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XG59XG5cbi5hY3Rpdml0eSB7XG4gIG1heC13aWR0aDogMzQwcHg7XG4gIG1hcmdpbjogYXV0bztcbiAgbWFyZ2luLXRvcDogMjVweDtcbn1cblxuLnRleHQzIHtcbiAgbWFyZ2luOiAwcHg7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cblxuLnRleHQ0IHtcbiAgbWFyZ2luOiAwcHg7XG4gIGZvbnQtc2l6ZTogOXB4O1xufVxuXG4udmlldyB7XG4gIG1hcmdpbjogMzRweCAxMHB4IDBweCAxMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG59XG4udmlldyBpb24tY29sIHtcbiAgbWF4LXdpZHRoOiAzODJweCAhaW1wb3J0YW50O1xuICBtaW4taGVpZ2h0OiA5OXB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgYWxpZ24tY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBtYXJnaW46IDBweCA1cHggMjdweCA1cHg7XG4gIHBhZGRpbmc6IDA7XG4gIGJveC1zaGFkb3c6IDJweCA0cHggNXB4IHJnYmEoMCwgMCwgMCwgMC4xNjA3ODQzMTM3KTtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi52aWV3IGlvbi1jb2wgLnVzZXJfaW1nIHtcbiAgYm9yZGVyOiAycHggc29saWQgIzE3QTUyNTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDE0cHg7XG59XG4udmlldyBpb24tY29sIC5tLTEge1xuICBtYXJnaW46IDMuNXB4IDNweDtcbn1cbi52aWV3IGlvbi1jb2wgLm0tMiB7XG4gIG1hcmdpbjogMTVweCAwcHggMHB4IDVweDtcbn1cbi52aWV3IGlvbi1jb2wgLnRpdGxlIHtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuLnZpZXcgaW9uLWNvbCAuc3VidGl0bGUge1xuICBmb250LXNpemU6IDlweDtcbn1cbi52aWV3IGlvbi1jb2wgLmxvY2F0aW9uX2ltZyB7XG4gIGhlaWdodDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbn1cblxuLnJlZmVyX2xvZ3V0IHtcbiAgaGVpZ2h0OiA2MHB4O1xuICBtYXgtd2lkdGg6IDM2M3B4O1xuICBtYXJnaW46IDE1cHggYXV0byAyM3B4IGF1dG87XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGJveC1zaGFkb3c6IDBweCAxcHggMjBweCAxOXB4IHdoaXRlc21va2U7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xufVxuLnJlZmVyX2xvZ3V0IGRpdiB7XG4gIHRleHQtYWxpZ246IGxlZnQ7XG4gIHdpZHRoOiA2NSU7XG59XG4ucmVmZXJfbG9ndXQgZGl2IHAge1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5pY29uIHtcbiAgbWFyZ2luLXRvcDogNnB4O1xufVxuXG5pb24taGVhZGVyIGlvbi10b29sYmFyIC53LTEge1xuICB3aWR0aDogNDJweDtcbn1cbmlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgcCB7XG4gIG1hcmdpbjogMCUgYXV0bztcbn1cblxuaW9uLWlucHV0IHtcbiAgaGVpZ2h0OiA1NXB4O1xuICBtYXgtd2lkdGg6IDMzNnB4O1xuICBib3JkZXI6IHNvbGlkIGJsYWNrIDFweDtcbiAgbWFyZ2luOiBhdXRvO1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIC0tcGFkZGluZy1zdGFydDogMjBweDtcbiAgLS1wYWRkaW5nLWVuZDogMTZweDtcbiAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xufVxuXG4ubGFiZWwge1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi1ib3R0b206IDVweDtcbiAgbWF4LXdpZHRoOiAzMjRweDtcbiAgYm9yZGVyOiBzb2xpZCBibGFjayAxcHg7XG59XG5cbi5pbnB1dDEge1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbjogMjlweCAwcHggMHB4IDBweDtcbn1cblxuLmlucHV0MiB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIG1hcmdpbjogMTBweDtcbiAgb3BhY2l0eTogMC42O1xufVxuXG4uaWNvbiB7XG4gIHRleHQtYWxpZ246IGVuZDtcbn1cblxuLnRleHh0IHtcbiAgbWFyZ2luOiAwcHg7XG4gIG9wYWNpdHk6IDAuNjtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIGhlaWdodDogNjBweDtcbiAgbWF4LXdpZHRoOiAzMjdweDtcbiAgbWFyZ2luOiBhdXRvO1xuICBjb2xvcjogd2hpdGU7XG4gIG1hcmdpbi1ib3R0b206IDM0cHg7XG4gIGZvbnQtc2l6ZTogMThweDtcbn1cblxuLmlucHV0X3RpdGxlIHtcbiAgbWF4LXdpZHRoOiAzMDBweDtcbiAgbWFyZ2luOiBhdXRvIGF1dG8gOXB4IGF1dG87XG59XG5cbi5jYXB0dXJlX2ltZyB7XG4gIHdpZHRoOiAyOXB4O1xuICBoZWlnaHQ6IDI5cHg7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoODRweCwgLTM1cHgsIDEwcHgpO1xufSJdfQ== */";

/***/ }),

/***/ 8907:
/*!******************************************************!*\
  !*** ./src/app/profile/profile.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n\r\n  <!-- see -->\r\n  <div *ngIf=\"this.type === true \">\r\n\r\n    <ion-row class=\"header\">\r\n      <ion-col size=\"1.8\">\r\n        <div class=\"back-button\" (click)=\"nav_back()\"> \r\n          <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n        </div>\r\n      </ion-col>\r\n      <ion-col size=\"8.4\">\r\n        <p class=\"text\"><b>Profile</b></p>\r\n      </ion-col>\r\n      <ion-col size=\"1.8\">\r\n        <p class=\"text\" (click)=\"allow()\"><b>Edit</b></p>\r\n      </ion-col>\r\n    </ion-row>\r\n \r\n     <!-- user image -->\r\n    <ion-avatar class=\"avatar\">\r\n      <img src=\"{{profile_data.img}}\" alt=\"\">\r\n    </ion-avatar>\r\n\r\n\r\n    <!-- user name and Bio -->\r\n    <h1 class=\"name\"><b>{{profile_data.name}}</b></h1>\r\n    <p class=\"text2\">{{profile_data.bio}}</p>\r\n\r\n    <!-- social range -->\r\n    <ion-row class=\"range\">\r\n      <ion-col size=\"8\">\r\n        <p>Social range</p>\r\n      </ion-col>\r\n      <ion-col size=\"4\" class=\"col2\">\r\n        <!-- social range value -->\r\n        <p><b>{{profile_data.socialize_distance}}</b></p>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"activity\">\r\n      <ion-col size=\"9\">\r\n        <p><b>Favourite activities</b></p>\r\n      </ion-col>\r\n      <ion-col size=\"3\">\r\n        <p>See All</p>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- favorite activities -->\r\n    <ion-row class=\"view\">\r\n      <ion-col size=\"12\" size-md=\"4\" *ngFor=\"let data of favourite\">\r\n\r\n        <div class=\"user_img m-2\">\r\n          <img src=\"{{this.data.user_img}}\" alt=\"\">\r\n        </div>\r\n\r\n        <div class=\"m-2\">\r\n          <p class=\"title m-1\"><b>{{this.data.fav_title}}</b></p>\r\n          <p class=\"subtitle m-1\">{{this.data.fav_des}}</p>\r\n          <p class=\"subtitle m-1\"><b>view it</b></p>\r\n        </div>\r\n\r\n        <div class=\"location_img\">\r\n          <img src=\"{{this.data.location_img}}\" alt=\"\">\r\n        </div>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <!-- Log out -->\r\n    <ion-row class=\"refer_logut\" (click)=\"log_out()\">\r\n      <ion-icon class=\"icon\" name=\"log-out\" size=\"large\"></ion-icon>\r\n      <div>\r\n        <p>Log out</p>\r\n      </div>\r\n      <ion-icon class=\"icon\" name=\"chevron-forward\" size=\"large\"></ion-icon>\r\n    </ion-row>\r\n\r\n\r\n  </div>\r\n\r\n\r\n  <!-- Edit -->\r\n  <div *ngIf=\"this.type === false \">\r\n    <ion-header class=\"ion-no-border\">\r\n      <ion-toolbar>\r\n  \r\n          <div slot=\"start\" class=\"back-button\" (click)=\"allow()\">\r\n            <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n          </div>\r\n          <div>\r\n            <p class=\"text\"><b>Edit Profile</b></p>\r\n          </div>\r\n\r\n          <div slot=\"end\" class=\"w-1\"></div>\r\n\r\n      </ion-toolbar>\r\n\r\n    </ion-header>\r\n\r\n    <!-- get  -->\r\n    <ion-avatar class=\"avatar\">\r\n      <img id=\"cameraImage\" alt=\"\">\r\n      <!-- get img buttton  -->\r\n      <div class=\"capture_img\" (click)=\"capture_img()\" >\r\n        <img src=\"./../../assets/edit_img.png\" alt=\"\">\r\n      </div>\r\n    </ion-avatar>\r\n    <!-- Name -->\r\n    <ion-row class=\"input_title\">\r\n      <p class=\"input1\"><b>Name</b></p>\r\n    </ion-row>\r\n    <!-- Enter Name -->\r\n    <ion-input type=\"text\" placeholder=\"William\" [(ngModel)]=\"profile_data.name\"></ion-input>\r\n\r\n    <!-- Bio -->\r\n    <ion-row class=\"input_title\">\r\n      <p class=\"input1\"><b>Bio</b></p>\r\n    </ion-row>\r\n    <!-- enter Bio -->\r\n    <ion-input type=\"text\" placeholder=\"Keep enjoying more!\" [(ngModel)]=\"profile_data.bio\"></ion-input>\r\n\r\n    <!-- distance -->\r\n    <ion-row class=\"input_title\">\r\n      <p  class=\"input1\"><b>Socialize Range</b></p>\r\n    </ion-row>\r\n    <!-- enter distance -->\r\n    <ion-input type=\"text\" placeholder=\"200m\" [(ngModel)]=\"profile_data.socialize_distance\" ></ion-input>\r\n\r\n    <!-- range -->\r\n    <ion-row class=\"input_title\">\r\n      <div style=\"    display: flex;\r\n      align-items: center;\">\r\n        <img src=\"./../../assets/Vector.png\" alt=\"\" srcset=\"\">\r\n      </div>\r\n      <p class=\"input2 m-1\">Set between 100m and 30km</p>\r\n    </ion-row>\r\n\r\n    <!-- Submit button -->\r\n    <ion-button shape=\"round\" expand=\"full\" (click)=\"ProfileUpdate()\">\r\n      <b>Save</b>\r\n    </ion-button>\r\n\r\n  </div>\r\n\r\n\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_profile_profile_module_ts.js.map