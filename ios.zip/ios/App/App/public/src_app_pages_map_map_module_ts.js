"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_map_map_module_ts"],{

/***/ 1419:
/*!******************************************!*\
  !*** ./src/app/Services/gmap.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GmapsService": () => (/* binding */ GmapsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 2340);



let GmapsService = class GmapsService {
  constructor() {}

  loadGoogleMaps() {
    const win = window;
    const gModule = win.google;

    if (gModule && gModule.maps) {
      return Promise.resolve(gModule.maps);
    }

    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://maps.googleapis.com/maps/api/js?key=' + src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.mapsKey;
      script.async = true;
      script.defer = true;
      document.body.appendChild(script);

      script.onload = () => {
        const loadedGoogleModule = win.google;

        if (loadedGoogleModule && loadedGoogleModule.maps) {
          resolve(loadedGoogleModule.maps);
        } else {
          reject('Google Map SDK is not Available');
        }
      };
    });
  }

};

GmapsService.ctorParameters = () => [];

GmapsService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
  providedIn: 'root'
})], GmapsService);


/***/ }),

/***/ 6770:
/*!*************************************************!*\
  !*** ./src/app/pages/map/map-routing.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MapPageRoutingModule": () => (/* binding */ MapPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _map_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./map.page */ 9763);




const routes = [
    {
        path: '',
        component: _map_page__WEBPACK_IMPORTED_MODULE_0__.MapPage
    }
];
let MapPageRoutingModule = class MapPageRoutingModule {
};
MapPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MapPageRoutingModule);



/***/ }),

/***/ 6016:
/*!*****************************************!*\
  !*** ./src/app/pages/map/map.module.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MapPageModule": () => (/* binding */ MapPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _map_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./map-routing.module */ 6770);
/* harmony import */ var _map_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./map.page */ 9763);







let MapPageModule = class MapPageModule {
};
MapPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _map_routing_module__WEBPACK_IMPORTED_MODULE_0__.MapPageRoutingModule
        ],
        declarations: [_map_page__WEBPACK_IMPORTED_MODULE_1__.MapPage]
    })
], MapPageModule);



/***/ }),

/***/ 9763:
/*!***************************************!*\
  !*** ./src/app/pages/map/map.page.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MapPage": () => (/* binding */ MapPage)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _map_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./map.page.html?ngResource */ 512);
/* harmony import */ var _map_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./map.page.scss?ngResource */ 9055);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var src_app_Services_gmap_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/Services/gmap.service */ 1419);
/* harmony import */ var _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor/geolocation */ 7621);








let MapPage = class MapPage {
  constructor(gmaps, renderer, actionSheetCtrl) {
    this.gmaps = gmaps;
    this.renderer = renderer;
    this.actionSheetCtrl = actionSheetCtrl;
    this.center = {
      lat: '',
      lng: ''
    };
    this.markers = [];
  }

  ngOnInit() {}

  ngAfterViewInit() {
    this.loadMap();
  }

  loadMap() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const coordinates = yield _capacitor_geolocation__WEBPACK_IMPORTED_MODULE_4__.Geolocation.getCurrentPosition();

      try {
        let googleMaps = yield _this.gmaps.loadGoogleMaps();
        _this.googleMaps = googleMaps;
        const mapEl = _this.mapElementRef.nativeElement;
        const location = new googleMaps.LatLng(coordinates.coords.latitude, coordinates.coords.longitude);
        _this.map = new googleMaps.Map(mapEl, {
          center: location,
          zoom: 16
        });

        _this.renderer.addClass(mapEl, 'visible'); // this.addMarker(location);


        _this.onMapClick();
      } catch (e) {
        console.log(e);
      }
    })();
  }

  onMapClick() {
    this.mapClickListener = this.googleMaps.event.addListener(this.map, "click", mapsMouseEvent => {
      console.log(mapsMouseEvent.latLng.toJSON());
      this.addMarker(mapsMouseEvent.latLng); // this.checkAndRemoveMarker(x)

      for (var i = 0; i < this.markers.length; i++) {
        this.markers[i].setMap(this.map);
      }
    });
  }

  addMarker(location) {
    let googleMaps = this.googleMaps;
    const icon = {
      url: 'https://turbonowpk.com/activity/images/2211011667330422.8122.jpg',
      scaledSize: new googleMaps.Size(50, 50)
    };
    const marker = new googleMaps.Marker({
      position: location,
      map: this.map,
      icon: icon // draggable: true,
      // animation: googleMaps.Animation.DROP

    });
    this.markers.push(marker);
    this.markerClickListener = this.googleMaps.event.addListener(marker, 'click', () => {
      console.log('markerclick', marker);
      this.checkAndRemoveMarker(marker);
      console.log('markers: ', this.markers);
    });
    return marker;
  }

  placeMarker(location) {
    let marker;

    if (marker) {
      marker.setPosition(location);
    } else {
      marker = new google.maps.Marker({
        position: location,
        map: this.map
      });
    }
  }

  checkAndRemoveMarker(marker) {
    marker.setMap(null);
  }

  presentActionSheet() {
    var _this2 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const actionSheet = yield _this2.actionSheetCtrl.create({
        header: 'Added Marker',
        subHeader: '',
        buttons: [{
          text: 'Remove',
          role: 'destructive',
          data: {
            action: 'delete'
          }
        }, {
          text: 'Save',
          data: {
            action: 'share'
          }
        }, {
          text: 'Cancel',
          role: 'cancel',
          data: {
            action: 'cancel'
          }
        }]
      });
      yield actionSheet.present();
    })();
  }

  ngOnDestroy() {
    // this.googleMaps.event.removeAllListeners();
    if (this.mapClickListener) this.googleMaps.event.removeListener(this.mapClickListener);
    if (this.markerClickListener) this.googleMaps.event.removeListener(this.markerClickListener);
  }

};

MapPage.ctorParameters = () => [{
  type: src_app_Services_gmap_service__WEBPACK_IMPORTED_MODULE_3__.GmapsService
}, {
  type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Renderer2
}, {
  type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController
}];

MapPage.propDecorators = {
  mapElementRef: [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ViewChild,
    args: ['map', {
      static: true
    }]
  }]
};
MapPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
  selector: 'app-map',
  template: _map_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_map_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], MapPage);


/***/ }),

/***/ 591:
/*!*********************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/definitions.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);


/***/ }),

/***/ 7621:
/*!***************************************************************!*\
  !*** ./node_modules/@capacitor/geolocation/dist/esm/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Geolocation": () => (/* binding */ Geolocation)
/* harmony export */ });
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @capacitor/core */ 5099);
/* harmony import */ var _definitions__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./definitions */ 591);

const Geolocation = (0,_capacitor_core__WEBPACK_IMPORTED_MODULE_0__.registerPlugin)('Geolocation', {
  web: () => __webpack_require__.e(/*! import() */ "node_modules_capacitor_geolocation_dist_esm_web_js").then(__webpack_require__.bind(__webpack_require__, /*! ./web */ 8391)).then(m => new m.GeolocationWeb())
});



/***/ }),

/***/ 9055:
/*!****************************************************!*\
  !*** ./src/app/pages/map/map.page.scss?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = ".map {\n  position: absolute;\n  height: 100%;\n  width: 100%;\n  background-color: transparent;\n  opacity: 0;\n  transition: opacity 150ms ease-in;\n}\n\n.map.visible {\n  opacity: 1;\n}\n\n.map::ng-deep {\n  display: inline-block;\n  width: 100%;\n  height: 100%;\n}\n\n.map::ng-deep div[class=gmnoprint] {\n  top: -200px;\n}\n\n.map::ng-deep button[draggable=false] {\n  height: 0px !important;\n  width: 0px !important;\n}\n\n.map::ng-deep div[role=button] {\n  background-image: url('markerTag.png');\n  z-index: 10;\n  background-size: 68px 97px;\n  background-repeat: no-repeat;\n  height: 118px !important;\n  width: 300px !important;\n}\n\n.map::ng-deep div[role=button].img {\n  border-radius: 100%;\n}\n\n.map::ng-deep .gmnoprint {\n  top: -518px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1hcC5wYWdlLnNjc3MiLCIuLlxcLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcRml2ZXIlMjBPcmRlcnNcXEFjdGl2aXR5XFxhY3Rpdml0eS1hcHBcXHNyY1xcYXBwXFxwYWdlc1xcbWFwXFxtYXAucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtFQUNBLGlDQUFBO0FDQ0o7O0FERUU7RUFDRSxVQUFBO0FDQ0o7O0FEQ0U7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDRUo7O0FEREk7RUFDSSxXQUFBO0FDR1I7O0FEREk7RUFDSSxzQkFBQTtFQUNBLHFCQUFBO0FDR1I7O0FEREk7RUFDSSxzQ0FBQTtFQUNBLFdBQUE7RUFDQSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtBQ0dSOztBRERJO0VBQ0ksbUJBQUE7QUNHUjs7QURESTtFQUNJLFdBQUE7QUNHUiIsImZpbGUiOiJtYXAucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hcCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgb3BhY2l0eTogMDtcclxuICAgIHRyYW5zaXRpb246IG9wYWNpdHkgMTUwbXMgZWFzZS1pbjtcclxuICB9XHJcbiAgXHJcbiAgLm1hcC52aXNpYmxlIHtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgfVxyXG4gIC5tYXA6Om5nLWRlZXAge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBkaXZbY2xhc3M9XCJnbW5vcHJpbnRcIl0ge1xyXG4gICAgICAgIHRvcDogLTIwMHB4O1xyXG4gICAgfVxyXG4gICAgYnV0dG9uW2RyYWdnYWJsZT1cImZhbHNlXCJdIHtcclxuICAgICAgICBoZWlnaHQ6IDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHdpZHRoOiAwcHggIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgIGRpdltyb2xlPVwiYnV0dG9uXCJdIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLy4uLy4uLy4uL2Fzc2V0cy9tYXAtaWNvbi9tYXJrZXJUYWcucG5nXCIpO1xyXG4gICAgICAgIHotaW5kZXg6IDEwO1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogNjhweCA5N3B4O1xyXG4gICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgaGVpZ2h0OiAxMThweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHdpZHRoOiAzMDBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgZGl2W3JvbGU9XCJidXR0b25cIl0uaW1nIHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgLmdtbm9wcmludCB7XHJcbiAgICAgICAgdG9wOiAtNTE4cHg7XHJcbiAgICB9XHJcbn0iLCIubWFwIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgb3BhY2l0eTogMDtcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAxNTBtcyBlYXNlLWluO1xufVxuXG4ubWFwLnZpc2libGUge1xuICBvcGFjaXR5OiAxO1xufVxuXG4ubWFwOjpuZy1kZWVwIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuLm1hcDo6bmctZGVlcCBkaXZbY2xhc3M9Z21ub3ByaW50XSB7XG4gIHRvcDogLTIwMHB4O1xufVxuLm1hcDo6bmctZGVlcCBidXR0b25bZHJhZ2dhYmxlPWZhbHNlXSB7XG4gIGhlaWdodDogMHB4ICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAwcHggIWltcG9ydGFudDtcbn1cbi5tYXA6Om5nLWRlZXAgZGl2W3JvbGU9YnV0dG9uXSB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4vLi4vLi4vLi4vYXNzZXRzL21hcC1pY29uL21hcmtlclRhZy5wbmdcIik7XG4gIHotaW5kZXg6IDEwO1xuICBiYWNrZ3JvdW5kLXNpemU6IDY4cHggOTdweDtcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgaGVpZ2h0OiAxMThweCAhaW1wb3J0YW50O1xuICB3aWR0aDogMzAwcHggIWltcG9ydGFudDtcbn1cbi5tYXA6Om5nLWRlZXAgZGl2W3JvbGU9YnV0dG9uXS5pbWcge1xuICBib3JkZXItcmFkaXVzOiAxMDAlO1xufVxuLm1hcDo6bmctZGVlcCAuZ21ub3ByaW50IHtcbiAgdG9wOiAtNTE4cHg7XG59Il19 */";

/***/ }),

/***/ 512:
/*!****************************************************!*\
  !*** ./src/app/pages/map/map.page.html?ngResource ***!
  \****************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-title>\n      Google Maps\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"map\" #map></div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_map_map_module_ts.js.map