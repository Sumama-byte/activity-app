"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["default-src_app_activity-details_activity-details_module_ts"],{

/***/ 3987:
/*!*********************************************************************!*\
  !*** ./src/app/activity-details/activity-details-routing.module.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActivityDetailsPageRoutingModule": () => (/* binding */ ActivityDetailsPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _activity_details_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./activity-details.page */ 8480);




const routes = [
    {
        path: '',
        component: _activity_details_page__WEBPACK_IMPORTED_MODULE_0__.ActivityDetailsPage
    }
];
let ActivityDetailsPageRoutingModule = class ActivityDetailsPageRoutingModule {
};
ActivityDetailsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ActivityDetailsPageRoutingModule);



/***/ }),

/***/ 5550:
/*!*************************************************************!*\
  !*** ./src/app/activity-details/activity-details.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActivityDetailsPageModule": () => (/* binding */ ActivityDetailsPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 4666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _activity_details_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./activity-details-routing.module */ 3987);
/* harmony import */ var _activity_details_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./activity-details.page */ 8480);







let ActivityDetailsPageModule = class ActivityDetailsPageModule {
};
ActivityDetailsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _activity_details_routing_module__WEBPACK_IMPORTED_MODULE_0__.ActivityDetailsPageRoutingModule
        ],
        declarations: [_activity_details_page__WEBPACK_IMPORTED_MODULE_1__.ActivityDetailsPage]
    })
], ActivityDetailsPageModule);



/***/ }),

/***/ 8480:
/*!***********************************************************!*\
  !*** ./src/app/activity-details/activity-details.page.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActivityDetailsPage": () => (/* binding */ ActivityDetailsPage)
/* harmony export */ });
/* harmony import */ var E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js */ 1670);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _activity_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./activity-details.page.html?ngResource */ 5295);
/* harmony import */ var _activity_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./activity-details.page.scss?ngResource */ 9030);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 2560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 124);
/* harmony import */ var _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Services/apicall.service */ 3742);
/* harmony import */ var _Services_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Services/global.service */ 1307);








let ActivityDetailsPage = class ActivityDetailsPage {
  constructor(route, global, apicall) {
    this.route = route;
    this.global = global;
    this.apicall = apicall;
    this.postStatus = {
      a_id: '',
      u_id: '',
      status: ''
    };
    this.YourActivity = {
      u_id: ''
    };
  }

  ngOnInit() {
    this.data = history.state.data;
    this.postStatus.a_id = this.data.a_id;
    this.global.Uid.subscribe(uid => {
      console.log(uid);
      this.postStatus.u_id = uid;
      this.YourActivity.u_id = uid;
    });
  } //navigation


  nav_back() {
    this.route.navigate(['/tabs/tab1']);
  } //data to going 


  going() {
    var _this = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('going');
      _this.postStatus.status = "g";
      console.log(_this.postStatus);
      yield _this.apicall.api_postStatus(_this.postStatus);

      _this.getDataactivity();
    })();
  } //data to may_be_going 


  may_be_going() {
    var _this2 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      console.log('may_be_going');
      _this2.postStatus.status = "m";
      console.log(_this2.postStatus);
      yield _this2.apicall.api_postStatus(_this2.postStatus);

      _this2.getDataactivity();
    })();
  }

  getDataactivity() {
    var _this3 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      yield _this3.apicall.api_getActivity(_this3.YourActivity.u_id);
      yield _this3.apicall.api_myparticipantActivity(_this3.YourActivity.u_id);
      yield _this3.apicall.api_getallActivitybylocation();
      yield _this3.apicall.api_getallfilterActivity();
      yield _this3.apicall.api_getpeopleForChat();
    })();
  }

  checkAttendees() {
    var _this4 = this;

    return (0,E_Fiver_Orders_Activity_activity_app_node_modules_babel_runtime_helpers_esm_asyncToGenerator_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function* () {
      const x = _this4.data.a_id;
      console.log(x);
      yield _this4.apicall.api_ActivityStatus(x);

      _this4.route.navigate(['/tabs/canidates']);
    })();
  }

};

ActivityDetailsPage.ctorParameters = () => [{
  type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
}, {
  type: _Services_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
}, {
  type: _Services_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
}];

ActivityDetailsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([(0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
  selector: 'app-activity-details',
  template: _activity_details_page_html_ngResource__WEBPACK_IMPORTED_MODULE_1__,
  styles: [_activity_details_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
})], ActivityDetailsPage);


/***/ }),

/***/ 9030:
/*!************************************************************************!*\
  !*** ./src/app/activity-details/activity-details.page.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "ion-header {\n  background: white;\n  --background: white;\n}\nion-header ion-toolbar {\n  background: white;\n  --background: white;\n}\n.back-button {\n  border-radius: 100%;\n  box-shadow: 2px 3px 5px 5px whitesmoke;\n  height: 33px;\n  width: 33px;\n}\n.txt {\n  font-size: 18px;\n  margin: auto;\n}\n.image {\n  width: 100%;\n  height: 230px;\n  margin: 30px auto 0px auto;\n  box-shadow: 2px 2px 37px rgba(0, 0, 0, 0.215);\n}\n.algin_left {\n  display: flex;\n}\n.div2 {\n  width: 90%;\n  margin-left: auto;\n  margin-right: auto;\n}\n.div2 .para {\n  margin-left: auto;\n  margin-right: auto;\n  font-size: small;\n}\n.div2 .div3 {\n  font-size: smaller;\n  font-weight: bold;\n  padding: 0;\n}\n.div2 .coltime {\n  display: flex;\n}\n.div2 .div4 {\n  display: flex;\n  width: 37px;\n  height: 46px;\n  background-color: #F2910C;\n  color: white;\n  border-radius: 8px;\n  font-size: 21px;\n  font-weight: bolder;\n  background-image: url('div_ouline.png');\n  justify-content: center;\n  align-items: center;\n  margin: 8px;\n}\nion-button {\n  --background: #F2910C;\n  --border-radius: 100px;\n  height: 60px;\n  width: 150px;\n  padding-top: 20px;\n  color: white;\n  text-transform: none;\n  margin: 0px auto 25px auto;\n}\n.fs-0 {\n  width: 100%;\n  font-size: 12px;\n}\n.col {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  flex-direction: column;\n}\nion-item {\n  --background: transparent;\n}\n.center {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjdGl2aXR5LWRldGFpbHMucGFnZS5zY3NzIiwiLi5cXC4uXFwuLlxcLi5cXC4uXFwuLlxcRml2ZXIlMjBPcmRlcnNcXEFjdGl2aXR5XFxhY3Rpdml0eS1hcHBcXHNyY1xcYXBwXFxhY3Rpdml0eS1kZXRhaWxzXFxhY3Rpdml0eS1kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGlCQUFBO0VBQ0EsbUJBQUE7QUNDRjtBREFFO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtBQ0VKO0FEQ0E7RUFDSSxtQkFBQTtFQUNBLHNDQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QUNFSjtBREFBO0VBQ0ksZUFBQTtFQUNBLFlBQUE7QUNHSjtBRERBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSwwQkFBQTtFQUNBLDZDQUFBO0FDSUo7QURESTtFQUNJLGFBQUE7QUNJUjtBREZBO0VBQ0ksVUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNLSjtBREhJO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDS1I7QURISTtFQUNJLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0FDS1I7QURIRTtFQUNFLGFBQUE7QUNLSjtBREhNO0VBQ0MsYUFBQTtFQUdFLFdBQUE7RUFDRCxZQUFBO0VBRUEseUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFHQSx1Q0FBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxXQUFBO0FDQVI7QURPQTtFQUNJLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLG9CQUFBO0VBQ0EsMEJBQUE7QUNKSjtBRE9BO0VBQ0ksV0FBQTtFQUNBLGVBQUE7QUNKSjtBRE1BO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQ0hKO0FES0E7RUFDSSx5QkFBQTtBQ0ZKO0FESUE7RUFDSSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtBQ0RKIiwiZmlsZSI6ImFjdGl2aXR5LWRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlcntcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAtLWJhY2tncm91bmQ6IHdoaXRlO1xyXG4gIGlvbi10b29sYmFye1xyXG4gICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAtLWJhY2tncm91bmQ6IHdoaXRlO1xyXG4gIH1cclxufVxyXG4uYmFjay1idXR0b257XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMDAlO1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDNweCA1cHggNXB4IHdoaXRlc21va2U7XHJcbiAgICBoZWlnaHQ6IDMzcHg7XHJcbiAgICB3aWR0aDogMzNweDtcclxufVxyXG4udHh0e1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcbi5pbWFnZXtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAyMzBweDtcclxuICAgIG1hcmdpbjogMzBweCBhdXRvIDBweCBhdXRvO1xyXG4gICAgYm94LXNoYWRvdzogMnB4IDJweCAzN3B4IHJnYmEoMCwgMCwgMCwgMC4yMTUpO1xyXG59XHJcblxyXG4gICAgLmFsZ2luX2xlZnR7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgIH1cclxuLmRpdjJ7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcblxyXG4gICAgLnBhcmF7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbiAgICB9XHJcbiAgICAuZGl2M3tcclxuICAgICAgICBmb250LXNpemU6IHNtYWxsZXI7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgIH1cclxuICAuY29sdGltZXtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgfVxyXG4gICAgICAuZGl2NHtcclxuICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgLy8gd2lkdGg6IDM3cHg7XHJcbiAgICAgICAgLy8gaGVpZ2h0OiA0M3B4O1xyXG4gICAgICAgICB3aWR0aDogMzdweDtcclxuICAgICAgICBoZWlnaHQ6IDQ2cHg7XHJcblxyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNGMjkxMEM7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICAgICAgICBmb250LXNpemU6IDIxcHg7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcclxuICAgICAgICAvLyBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCJkYXRhOmltYWdlL3N2Zyt4bWwsJTNjc3ZnIHdpZHRoPScxMDAlMjUnIGhlaWdodD0nMTAwJTI1JyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnJTNlJTNjcmVjdCB3aWR0aD0nMTAwJTI1JyBoZWlnaHQ9JzEwMCUyNScgZmlsbD0nbm9uZScgcng9JzEwJyByeT0nMTAnIHN0cm9rZT0nYmxhY2snIHN0cm9rZS13aWR0aD0nNicgc3Ryb2tlLWRhc2hhcnJheT0nMTAwJTJjNDUnIHN0cm9rZS1kYXNob2Zmc2V0PSc5Micgc3Ryb2tlLWxpbmVjYXA9J3NxdWFyZScvJTNlJTNjL3N2ZyUzZVwiKTtcclxuICAgICAgICAvLyBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLy4uLy4uL2Fzc2V0cy9kaXZfb3VsaW5lLnBuZyk7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBtYXJnaW46IDhweDtcclxuICAgIH1cclxuXHJcblxyXG5cclxuXHJcbn1cclxuaW9uLWJ1dHRvbiB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNGMjkxMEM7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IDEwMHB4O1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgcGFkZGluZy10b3A6IDIwcHg7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcclxuICAgIG1hcmdpbjowcHggYXV0byAyNXB4IGF1dG87XHJcbn1cclxuXHJcbi5mcy0we1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBmb250LXNpemU6IDEycHg7XHJcbn1cclxuLmNvbHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcbmlvbi1pdGVte1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxufVxyXG4uY2VudGVye1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxufVxyXG4iLCJpb24taGVhZGVyIHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5pb24taGVhZGVyIGlvbi10b29sYmFyIHtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIC0tYmFja2dyb3VuZDogd2hpdGU7XG59XG5cbi5iYWNrLWJ1dHRvbiB7XG4gIGJvcmRlci1yYWRpdXM6IDEwMCU7XG4gIGJveC1zaGFkb3c6IDJweCAzcHggNXB4IDVweCB3aGl0ZXNtb2tlO1xuICBoZWlnaHQ6IDMzcHg7XG4gIHdpZHRoOiAzM3B4O1xufVxuXG4udHh0IHtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBtYXJnaW46IGF1dG87XG59XG5cbi5pbWFnZSB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDIzMHB4O1xuICBtYXJnaW46IDMwcHggYXV0byAwcHggYXV0bztcbiAgYm94LXNoYWRvdzogMnB4IDJweCAzN3B4IHJnYmEoMCwgMCwgMCwgMC4yMTUpO1xufVxuXG4uYWxnaW5fbGVmdCB7XG4gIGRpc3BsYXk6IGZsZXg7XG59XG5cbi5kaXYyIHtcbiAgd2lkdGg6IDkwJTtcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbn1cbi5kaXYyIC5wYXJhIHtcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bztcbiAgZm9udC1zaXplOiBzbWFsbDtcbn1cbi5kaXYyIC5kaXYzIHtcbiAgZm9udC1zaXplOiBzbWFsbGVyO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgcGFkZGluZzogMDtcbn1cbi5kaXYyIC5jb2x0aW1lIHtcbiAgZGlzcGxheTogZmxleDtcbn1cbi5kaXYyIC5kaXY0IHtcbiAgZGlzcGxheTogZmxleDtcbiAgd2lkdGg6IDM3cHg7XG4gIGhlaWdodDogNDZweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0YyOTEwQztcbiAgY29sb3I6IHdoaXRlO1xuICBib3JkZXItcmFkaXVzOiA4cHg7XG4gIGZvbnQtc2l6ZTogMjFweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGRlcjtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4vLi4vLi4vYXNzZXRzL2Rpdl9vdWxpbmUucG5nKTtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbjogOHB4O1xufVxuXG5pb24tYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjRjI5MTBDO1xuICAtLWJvcmRlci1yYWRpdXM6IDEwMHB4O1xuICBoZWlnaHQ6IDYwcHg7XG4gIHdpZHRoOiAxNTBweDtcbiAgcGFkZGluZy10b3A6IDIwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIG1hcmdpbjogMHB4IGF1dG8gMjVweCBhdXRvO1xufVxuXG4uZnMtMCB7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDEycHg7XG59XG5cbi5jb2wge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuXG4uY2VudGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59Il19 */";

/***/ }),

/***/ 5295:
/*!************************************************************************!*\
  !*** ./src/app/activity-details/activity-details.page.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-header class=\"ion-no-border\">\r\n  <ion-item lines=\"none\" class=\"ion-text-center\">\r\n\r\n    <div slot=\"start\" class=\"back-button\" (click)=\"nav_back()\">\r\n      <ion-icon name=\"chevron-back-outline\" size=\"large\"></ion-icon>\r\n    </div>\r\n    <!-- Activtiy title -->\r\n    <p class=\"txt\">{{data.activity_name}}</p>\r\n\r\n    <ion-icon slot=\"end\" name=\"heart-outline\"></ion-icon>\r\n  </ion-item>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"col\">\r\n      <!-- location image  -->\r\n       \r\n        <img class=\"image\" src=\"{{data.a_image}}\" alt=\"\">\r\n \r\n\r\n      <ion-item lines=\"none\" class=\"fs-0\">\r\n        <div slot=\"start\" class=\"algin_left\">\r\n\r\n          <ion-icon name=\"location-outline\" size=\"large\"></ion-icon>\r\n\r\n          <!-- activity location -->\r\n          <p> {{data.location}}</p>\r\n\r\n        </div>\r\n        <!-- Avtivity range -->\r\n        <div slot=\"end\">\r\n          <p> Within {{data.social_range}} Km</p>\r\n        </div>\r\n      </ion-item>\r\n\r\n\r\n    </ion-col>\r\n    <ion-col size=\"12\" size-md=\"12\" size-lg=\"6\" class=\"center\">\r\n\r\n      <div class=\"div2\">\r\n        <!-- activity description -->\r\n        <p class=\"para\">\r\n          {{data.description}}\r\n        </p>\r\n        <!-- attendies title -->\r\n        <p><b>Number Of Atendees Allowed</b></p>\r\n        <!-- canidaties nunber -->\r\n        <h5><b>{{data.max_atendes}} </b></h5>\r\n        <ion-row>\r\n          <ion-col size=\"6\" class=\"div3\">Start Time</ion-col>\r\n          <ion-col size=\"6\" class=\"div3\">End Time</ion-col>\r\n        </ion-row>\r\n        <ion-row>\r\n\r\n          <!-- Activity Start time  -->\r\n          <ion-col size=\"6\" class=\"coltime\">\r\n            <div class=\"div4\">\r\n                {{data.start_time}}\r\n            </div>\r\n            <div class=\"div4\">00</div>\r\n          </ion-col>\r\n          <!-- Activity end time  -->\r\n          <ion-col size=\"6\" class=\"coltime\">\r\n            <div class=\"div4\">{{data.end_time}}</div>\r\n            <div class=\"div4\">00</div>\r\n          </ion-col>\r\n        </ion-row>\r\n      </div>\r\n      <ion-item lines=\"none\">\r\n        <!-- Going button -->\r\n        <ion-button   (click)=\"going()\">I am Going</ion-button>\r\n        <!--May be Going button -->\r\n        <ion-button   (click)=\"may_be_going()\">Maybe Going</ion-button>\r\n      </ion-item>\r\n\r\n      <ion-button   (click)=\"checkAttendees()\">Attendees</ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=default-src_app_activity-details_activity-details_module_ts.js.map